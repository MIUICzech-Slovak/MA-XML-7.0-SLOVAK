(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function (global){
"use strict";

require("core-js/shim");

require("regenerator/runtime");

if (global._babelPolyfill) {
  throw new Error("only one instance of babel/polyfill is allowed");
}
global._babelPolyfill = true;
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"core-js/shim":181,"regenerator/runtime":182}],2:[function(require,module,exports){
module.exports = function(it){
  if(typeof it != 'function')throw TypeError(it + ' is not a function!');
  return it;
};
},{}],3:[function(require,module,exports){
var isObject = require('./$.is-object');
module.exports = function(it){
  if(!isObject(it))throw TypeError(it + ' is not an object!');
  return it;
};
},{"./$.is-object":33}],4:[function(require,module,exports){
// false -> Array#indexOf
// true  -> Array#includes
var toIObject = require('./$.to-iobject')
  , toLength  = require('./$.to-length')
  , toIndex   = require('./$.to-index');
module.exports = function(IS_INCLUDES){
  return function($this, el, fromIndex){
    var O      = toIObject($this)
      , length = toLength(O.length)
      , index  = toIndex(fromIndex, length)
      , value;
    // Array#includes uses SameValueZero equality algorithm
    if(IS_INCLUDES && el != el)while(length > index){
      value = O[index++];
      if(value != value)return true;
    // Array#toIndex ignores holes, Array#includes - not
    } else for(;length > index; index++)if(IS_INCLUDES || index in O){
      if(O[index] === el)return IS_INCLUDES || index;
    } return !IS_INCLUDES && -1;
  };
};
},{"./$.to-index":69,"./$.to-iobject":71,"./$.to-length":72}],5:[function(require,module,exports){
// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx      = require('./$.ctx')
  , IObject  = require('./$.iobject')
  , toObject = require('./$.to-object')
  , toLength = require('./$.to-length');
module.exports = function(TYPE){
  var IS_MAP        = TYPE == 1
    , IS_FILTER     = TYPE == 2
    , IS_SOME       = TYPE == 3
    , IS_EVERY      = TYPE == 4
    , IS_FIND_INDEX = TYPE == 6
    , NO_HOLES      = TYPE == 5 || IS_FIND_INDEX;
  return function($this, callbackfn, that){
    var O      = toObject($this)
      , self   = IObject(O)
      , f      = ctx(callbackfn, that, 3)
      , length = toLength(self.length)
      , index  = 0
      , result = IS_MAP ? Array(length) : IS_FILTER ? [] : undefined
      , val, res;
    for(;length > index; index++)if(NO_HOLES || index in self){
      val = self[index];
      res = f(val, index, O);
      if(TYPE){
        if(IS_MAP)result[index] = res;            // map
        else if(res)switch(TYPE){
          case 3: return true;                    // some
          case 5: return val;                     // find
          case 6: return index;                   // findIndex
          case 2: result.push(val);               // filter
        } else if(IS_EVERY)return false;          // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};
},{"./$.ctx":14,"./$.iobject":30,"./$.to-length":72,"./$.to-object":73}],6:[function(require,module,exports){
// 19.1.2.1 Object.assign(target, source, ...)
var toObject = require('./$.to-object')
  , IObject  = require('./$.iobject')
  , enumKeys = require('./$.enum-keys');
/* eslint-disable no-unused-vars */
module.exports = Object.assign || function assign(target, source){
/* eslint-enable no-unused-vars */
  var T = toObject(target)
    , l = arguments.length
    , i = 1;
  while(l > i){
    var S      = IObject(arguments[i++])
      , keys   = enumKeys(S)
      , length = keys.length
      , j      = 0
      , key;
    while(length > j)T[key = keys[j++]] = S[key];
  }
  return T;
};
},{"./$.enum-keys":18,"./$.iobject":30,"./$.to-object":73}],7:[function(require,module,exports){
// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = require('./$.cof')
  , TAG = require('./$.wks')('toStringTag')
  // ES3 wrong here
  , ARG = cof(function(){ return arguments; }()) == 'Arguments';

module.exports = function(it){
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = (O = Object(it))[TAG]) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};
},{"./$.cof":8,"./$.wks":76}],8:[function(require,module,exports){
var toString = {}.toString;

module.exports = function(it){
  return toString.call(it).slice(8, -1);
};
},{}],9:[function(require,module,exports){
'use strict';
var $            = require('./$')
  , hide         = require('./$.hide')
  , ctx          = require('./$.ctx')
  , species      = require('./$.species')
  , strictNew    = require('./$.strict-new')
  , defined      = require('./$.defined')
  , forOf        = require('./$.for-of')
  , step         = require('./$.iter-step')
  , ID           = require('./$.uid')('id')
  , $has         = require('./$.has')
  , isObject     = require('./$.is-object')
  , isExtensible = Object.isExtensible || isObject
  , SUPPORT_DESC = require('./$.support-desc')
  , SIZE         = SUPPORT_DESC ? '_s' : 'size'
  , id           = 0;

var fastKey = function(it, create){
  // return primitive with prefix
  if(!isObject(it))return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if(!$has(it, ID)){
    // can't set id to frozen object
    if(!isExtensible(it))return 'F';
    // not necessary to add id
    if(!create)return 'E';
    // add missing object id
    hide(it, ID, ++id);
  // return object id with prefix
  } return 'O' + it[ID];
};

var getEntry = function(that, key){
  // fast case
  var index = fastKey(key), entry;
  if(index !== 'F')return that._i[index];
  // frozen object case
  for(entry = that._f; entry; entry = entry.n){
    if(entry.k == key)return entry;
  }
};

module.exports = {
  getConstructor: function(wrapper, NAME, IS_MAP, ADDER){
    var C = wrapper(function(that, iterable){
      strictNew(that, C, NAME);
      that._i = $.create(null); // index
      that._f = undefined;      // first entry
      that._l = undefined;      // last entry
      that[SIZE] = 0;           // size
      if(iterable != undefined)forOf(iterable, IS_MAP, that[ADDER], that);
    });
    require('./$.mix')(C.prototype, {
      // 23.1.3.1 Map.prototype.clear()
      // 23.2.3.2 Set.prototype.clear()
      clear: function clear(){
        for(var that = this, data = that._i, entry = that._f; entry; entry = entry.n){
          entry.r = true;
          if(entry.p)entry.p = entry.p.n = undefined;
          delete data[entry.i];
        }
        that._f = that._l = undefined;
        that[SIZE] = 0;
      },
      // 23.1.3.3 Map.prototype.delete(key)
      // 23.2.3.4 Set.prototype.delete(value)
      'delete': function(key){
        var that  = this
          , entry = getEntry(that, key);
        if(entry){
          var next = entry.n
            , prev = entry.p;
          delete that._i[entry.i];
          entry.r = true;
          if(prev)prev.n = next;
          if(next)next.p = prev;
          if(that._f == entry)that._f = next;
          if(that._l == entry)that._l = prev;
          that[SIZE]--;
        } return !!entry;
      },
      // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
      // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
      forEach: function forEach(callbackfn /*, that = undefined */){
        var f = ctx(callbackfn, arguments[1], 3)
          , entry;
        while(entry = entry ? entry.n : this._f){
          f(entry.v, entry.k, this);
          // revert to the last existing entry
          while(entry && entry.r)entry = entry.p;
        }
      },
      // 23.1.3.7 Map.prototype.has(key)
      // 23.2.3.7 Set.prototype.has(value)
      has: function has(key){
        return !!getEntry(this, key);
      }
    });
    if(SUPPORT_DESC)$.setDesc(C.prototype, 'size', {
      get: function(){
        return defined(this[SIZE]);
      }
    });
    return C;
  },
  def: function(that, key, value){
    var entry = getEntry(that, key)
      , prev, index;
    // change existing entry
    if(entry){
      entry.v = value;
    // create new entry
    } else {
      that._l = entry = {
        i: index = fastKey(key, true), // <- index
        k: key,                        // <- key
        v: value,                      // <- value
        p: prev = that._l,             // <- previous entry
        n: undefined,                  // <- next entry
        r: false                       // <- removed
      };
      if(!that._f)that._f = entry;
      if(prev)prev.n = entry;
      that[SIZE]++;
      // add to index
      if(index !== 'F')that._i[index] = entry;
    } return that;
  },
  getEntry: getEntry,
  setStrong: function(C, NAME, IS_MAP){
    // add .keys, .values, .entries, [@@iterator]
    // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
    require('./$.iter-define')(C, NAME, function(iterated, kind){
      this._t = iterated;  // target
      this._k = kind;      // kind
      this._l = undefined; // previous
    }, function(){
      var that  = this
        , kind  = that._k
        , entry = that._l;
      // revert to the last existing entry
      while(entry && entry.r)entry = entry.p;
      // get next entry
      if(!that._t || !(that._l = entry = entry ? entry.n : that._t._f)){
        // or finish the iteration
        that._t = undefined;
        return step(1);
      }
      // return step by kind
      if(kind == 'keys'  )return step(0, entry.k);
      if(kind == 'values')return step(0, entry.v);
      return step(0, [entry.k, entry.v]);
    }, IS_MAP ? 'entries' : 'values' , !IS_MAP, true);

    // add [@@species], 23.1.2.2, 23.2.2.2
    species(C);
    species(require('./$.core')[NAME]); // for wrapper
  }
};
},{"./$":41,"./$.core":13,"./$.ctx":14,"./$.defined":16,"./$.for-of":23,"./$.has":26,"./$.hide":27,"./$.is-object":33,"./$.iter-define":37,"./$.iter-step":39,"./$.mix":46,"./$.species":59,"./$.strict-new":60,"./$.support-desc":66,"./$.uid":74}],10:[function(require,module,exports){
// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var forOf   = require('./$.for-of')
  , classof = require('./$.classof');
module.exports = function(NAME){
  return function toJSON(){
    if(classof(this) != NAME)throw TypeError(NAME + "#toJSON isn't generic");
    var arr = [];
    forOf(this, false, arr.push, arr);
    return arr;
  };
};
},{"./$.classof":7,"./$.for-of":23}],11:[function(require,module,exports){
'use strict';
var hide         = require('./$.hide')
  , anObject     = require('./$.an-object')
  , strictNew    = require('./$.strict-new')
  , forOf        = require('./$.for-of')
  , method       = require('./$.array-methods')
  , WEAK         = require('./$.uid')('weak')
  , isObject     = require('./$.is-object')
  , $has         = require('./$.has')
  , isExtensible = Object.isExtensible || isObject
  , find         = method(5)
  , findIndex    = method(6)
  , id           = 0;

// fallback for frozen keys
var frozenStore = function(that){
  return that._l || (that._l = new FrozenStore);
};
var FrozenStore = function(){
  this.a = [];
};
var findFrozen = function(store, key){
  return find(store.a, function(it){
    return it[0] === key;
  });
};
FrozenStore.prototype = {
  get: function(key){
    var entry = findFrozen(this, key);
    if(entry)return entry[1];
  },
  has: function(key){
    return !!findFrozen(this, key);
  },
  set: function(key, value){
    var entry = findFrozen(this, key);
    if(entry)entry[1] = value;
    else this.a.push([key, value]);
  },
  'delete': function(key){
    var index = findIndex(this.a, function(it){
      return it[0] === key;
    });
    if(~index)this.a.splice(index, 1);
    return !!~index;
  }
};

module.exports = {
  getConstructor: function(wrapper, NAME, IS_MAP, ADDER){
    var C = wrapper(function(that, iterable){
      strictNew(that, C, NAME);
      that._i = id++;      // collection id
      that._l = undefined; // leak store for frozen objects
      if(iterable != undefined)forOf(iterable, IS_MAP, that[ADDER], that);
    });
    require('./$.mix')(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function(key){
        if(!isObject(key))return false;
        if(!isExtensible(key))return frozenStore(this)['delete'](key);
        return $has(key, WEAK) && $has(key[WEAK], this._i) && delete key[WEAK][this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key){
        if(!isObject(key))return false;
        if(!isExtensible(key))return frozenStore(this).has(key);
        return $has(key, WEAK) && $has(key[WEAK], this._i);
      }
    });
    return C;
  },
  def: function(that, key, value){
    if(!isExtensible(anObject(key))){
      frozenStore(that).set(key, value);
    } else {
      $has(key, WEAK) || hide(key, WEAK, {});
      key[WEAK][that._i] = value;
    } return that;
  },
  frozenStore: frozenStore,
  WEAK: WEAK
};
},{"./$.an-object":3,"./$.array-methods":5,"./$.for-of":23,"./$.has":26,"./$.hide":27,"./$.is-object":33,"./$.mix":46,"./$.strict-new":60,"./$.uid":74}],12:[function(require,module,exports){
'use strict';
var global     = require('./$.global')
  , $def       = require('./$.def')
  , BUGGY      = require('./$.iter-buggy')
  , forOf      = require('./$.for-of')
  , strictNew  = require('./$.strict-new');

module.exports = function(NAME, wrapper, methods, common, IS_MAP, IS_WEAK){
  var Base  = global[NAME]
    , C     = Base
    , ADDER = IS_MAP ? 'set' : 'add'
    , proto = C && C.prototype
    , O     = {};
  var fixMethod = function(KEY){
    var fn = proto[KEY];
    require('./$.redef')(proto, KEY,
      KEY == 'delete' ? function(a){ return fn.call(this, a === 0 ? 0 : a); }
      : KEY == 'has' ? function has(a){ return fn.call(this, a === 0 ? 0 : a); }
      : KEY == 'get' ? function get(a){ return fn.call(this, a === 0 ? 0 : a); }
      : KEY == 'add' ? function add(a){ fn.call(this, a === 0 ? 0 : a); return this; }
      : function set(a, b){ fn.call(this, a === 0 ? 0 : a, b); return this; }
    );
  };
  if(typeof C != 'function' || !(IS_WEAK || !BUGGY && proto.forEach && proto.entries)){
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    require('./$.mix')(C.prototype, methods);
  } else {
    var inst  = new C
      , chain = inst[ADDER](IS_WEAK ? {} : -0, 1)
      , buggyZero;
    // wrap for init collections from iterable
    if(!require('./$.iter-detect')(function(iter){ new C(iter); })){ // eslint-disable-line no-new
      C = wrapper(function(target, iterable){
        strictNew(target, C, NAME);
        var that = new Base;
        if(iterable != undefined)forOf(iterable, IS_MAP, that[ADDER], that);
        return that;
      });
      C.prototype = proto;
      proto.constructor = C;
    }
    IS_WEAK || inst.forEach(function(val, key){
      buggyZero = 1 / key === -Infinity;
    });
    // fix converting -0 key to +0
    if(buggyZero){
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }
    // + fix .add & .set for chaining
    if(buggyZero || chain !== inst)fixMethod(ADDER);
    // weak collections should not contains .clear method
    if(IS_WEAK && proto.clear)delete proto.clear;
  }

  require('./$.tag')(C, NAME);

  O[NAME] = C;
  $def($def.G + $def.W + $def.F * (C != Base), O);

  if(!IS_WEAK)common.setStrong(C, NAME, IS_MAP);

  return C;
};
},{"./$.def":15,"./$.for-of":23,"./$.global":25,"./$.iter-buggy":34,"./$.iter-detect":38,"./$.mix":46,"./$.redef":53,"./$.strict-new":60,"./$.tag":67}],13:[function(require,module,exports){
var core = module.exports = {};
if(typeof __e == 'number')__e = core; // eslint-disable-line no-undef
},{}],14:[function(require,module,exports){
// optional / simple context binding
var aFunction = require('./$.a-function');
module.exports = function(fn, that, length){
  aFunction(fn);
  if(that === undefined)return fn;
  switch(length){
    case 1: return function(a){
      return fn.call(that, a);
    };
    case 2: return function(a, b){
      return fn.call(that, a, b);
    };
    case 3: return function(a, b, c){
      return fn.call(that, a, b, c);
    };
  } return function(/* ...args */){
      return fn.apply(that, arguments);
    };
};
},{"./$.a-function":2}],15:[function(require,module,exports){
var global     = require('./$.global')
  , core       = require('./$.core')
  , hide       = require('./$.hide')
  , $redef     = require('./$.redef')
  , PROTOTYPE  = 'prototype';
var ctx = function(fn, that){
  return function(){
    return fn.apply(that, arguments);
  };
};
var $def = function(type, name, source){
  var key, own, out, exp
    , isGlobal = type & $def.G
    , isProto  = type & $def.P
    , target   = isGlobal ? global : type & $def.S
        ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE]
    , exports  = isGlobal ? core : core[name] || (core[name] = {});
  if(isGlobal)source = name;
  for(key in source){
    // contains in native
    own = !(type & $def.F) && target && key in target;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    if(type & $def.B && own)exp = ctx(out, global);
    else exp = isProto && typeof out == 'function' ? ctx(Function.call, out) : out;
    // extend global
    if(target && !own)$redef(target, key, out);
    // export
    if(exports[key] != out)hide(exports, key, exp);
    if(isProto)(exports[PROTOTYPE] || (exports[PROTOTYPE] = {}))[key] = out;
  }
};
global.core = core;
// type bitmap
$def.F = 1;  // forced
$def.G = 2;  // global
$def.S = 4;  // static
$def.P = 8;  // proto
$def.B = 16; // bind
$def.W = 32; // wrap
module.exports = $def;
},{"./$.core":13,"./$.global":25,"./$.hide":27,"./$.redef":53}],16:[function(require,module,exports){
// 7.2.1 RequireObjectCoercible(argument)
module.exports = function(it){
  if(it == undefined)throw TypeError("Can't call method on  " + it);
  return it;
};
},{}],17:[function(require,module,exports){
var isObject = require('./$.is-object')
  , document = require('./$.global').document
  // in old IE typeof document.createElement is 'object'
  , is = isObject(document) && isObject(document.createElement);
module.exports = function(it){
  return is ? document.createElement(it) : {};
};
},{"./$.global":25,"./$.is-object":33}],18:[function(require,module,exports){
// all enumerable object keys, includes symbols
var $ = require('./$');
module.exports = function(it){
  var keys       = $.getKeys(it)
    , getSymbols = $.getSymbols;
  if(getSymbols){
    var symbols = getSymbols(it)
      , isEnum  = $.isEnum
      , i       = 0
      , key;
    while(symbols.length > i)if(isEnum.call(it, key = symbols[i++]))keys.push(key);
  }
  return keys;
};
},{"./$":41}],19:[function(require,module,exports){
// 20.2.2.14 Math.expm1(x)
module.exports = Math.expm1 || function expm1(x){
  return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
};
},{}],20:[function(require,module,exports){
module.exports = function(exec){
  try {
    return !!exec();
  } catch(e){
    return true;
  }
};
},{}],21:[function(require,module,exports){
'use strict';
module.exports = function(KEY, length, exec){
  var defined  = require('./$.defined')
    , SYMBOL   = require('./$.wks')(KEY)
    , original = ''[KEY];
  if(require('./$.fails')(function(){
    var O = {};
    O[SYMBOL] = function(){ return 7; };
    return ''[KEY](O) != 7;
  })){
    require('./$.redef')(String.prototype, KEY, exec(defined, SYMBOL, original));
    require('./$.hide')(RegExp.prototype, SYMBOL, length == 2
      // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
      // 21.2.5.11 RegExp.prototype[@@split](string, limit)
      ? function(string, arg){ return original.call(string, this, arg); }
      // 21.2.5.6 RegExp.prototype[@@match](string)
      // 21.2.5.9 RegExp.prototype[@@search](string)
      : function(string){ return original.call(string, this); }
    );
  }
};
},{"./$.defined":16,"./$.fails":20,"./$.hide":27,"./$.redef":53,"./$.wks":76}],22:[function(require,module,exports){
'use strict';
// 21.2.5.3 get RegExp.prototype.flags
var anObject = require('./$.an-object');
module.exports = function(){
  var that   = anObject(this)
    , result = '';
  if(that.global)result += 'g';
  if(that.ignoreCase)result += 'i';
  if(that.multiline)result += 'm';
  if(that.unicode)result += 'u';
  if(that.sticky)result += 'y';
  return result;
};
},{"./$.an-object":3}],23:[function(require,module,exports){
var ctx         = require('./$.ctx')
  , call        = require('./$.iter-call')
  , isArrayIter = require('./$.is-array-iter')
  , anObject    = require('./$.an-object')
  , toLength    = require('./$.to-length')
  , getIterFn   = require('./core.get-iterator-method');
module.exports = function(iterable, entries, fn, that){
  var iterFn = getIterFn(iterable)
    , f      = ctx(fn, that, entries ? 2 : 1)
    , index  = 0
    , length, step, iterator;
  if(typeof iterFn != 'function')throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if(isArrayIter(iterFn))for(length = toLength(iterable.length); length > index; index++){
    entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
  } else for(iterator = iterFn.call(iterable); !(step = iterator.next()).done; ){
    call(iterator, f, step.value, entries);
  }
};
},{"./$.an-object":3,"./$.ctx":14,"./$.is-array-iter":31,"./$.iter-call":35,"./$.to-length":72,"./core.get-iterator-method":77}],24:[function(require,module,exports){
// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toString  = {}.toString
  , toIObject = require('./$.to-iobject')
  , getNames  = require('./$').getNames;

var windowNames = typeof window == 'object' && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function(it){
  try {
    return getNames(it);
  } catch(e){
    return windowNames.slice();
  }
};

module.exports.get = function getOwnPropertyNames(it){
  if(windowNames && toString.call(it) == '[object Window]')return getWindowNames(it);
  return getNames(toIObject(it));
};
},{"./$":41,"./$.to-iobject":71}],25:[function(require,module,exports){
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var UNDEFINED = 'undefined';
var global = module.exports = typeof window != UNDEFINED && window.Math == Math
  ? window : typeof self != UNDEFINED && self.Math == Math ? self : Function('return this')();
if(typeof __g == 'number')__g = global; // eslint-disable-line no-undef
},{}],26:[function(require,module,exports){
var hasOwnProperty = {}.hasOwnProperty;
module.exports = function(it, key){
  return hasOwnProperty.call(it, key);
};
},{}],27:[function(require,module,exports){
var $          = require('./$')
  , createDesc = require('./$.property-desc');
module.exports = require('./$.support-desc') ? function(object, key, value){
  return $.setDesc(object, key, createDesc(1, value));
} : function(object, key, value){
  object[key] = value;
  return object;
};
},{"./$":41,"./$.property-desc":52,"./$.support-desc":66}],28:[function(require,module,exports){
module.exports = require('./$.global').document && document.documentElement;
},{"./$.global":25}],29:[function(require,module,exports){
// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function(fn, args, that){
  var un = that === undefined;
  switch(args.length){
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return              fn.apply(that, args);
};
},{}],30:[function(require,module,exports){
// indexed object, fallback for non-array-like ES3 strings
var cof = require('./$.cof');
module.exports = 0 in Object('z') ? Object : function(it){
  return cof(it) == 'String' ? it.split('') : Object(it);
};
},{"./$.cof":8}],31:[function(require,module,exports){
// check on default Array iterator
var Iterators = require('./$.iterators')
  , ITERATOR  = require('./$.wks')('iterator');
module.exports = function(it){
  return (Iterators.Array || Array.prototype[ITERATOR]) === it;
};
},{"./$.iterators":40,"./$.wks":76}],32:[function(require,module,exports){
// 20.1.2.3 Number.isInteger(number)
var isObject = require('./$.is-object')
  , floor    = Math.floor;
module.exports = function isInteger(it){
  return !isObject(it) && isFinite(it) && floor(it) === it;
};
},{"./$.is-object":33}],33:[function(require,module,exports){
// http://jsperf.com/core-js-isobject
module.exports = function(it){
  return it !== null && (typeof it == 'object' || typeof it == 'function');
};
},{}],34:[function(require,module,exports){
// Safari has buggy iterators w/o `next`
module.exports = 'keys' in [] && !('next' in [].keys());
},{}],35:[function(require,module,exports){
// call something on iterator step with safe closing on error
var anObject = require('./$.an-object');
module.exports = function(iterator, fn, value, entries){
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch(e){
    var ret = iterator['return'];
    if(ret !== undefined)anObject(ret.call(iterator));
    throw e;
  }
};
},{"./$.an-object":3}],36:[function(require,module,exports){
'use strict';
var $ = require('./$')
  , IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
require('./$.hide')(IteratorPrototype, require('./$.wks')('iterator'), function(){ return this; });

module.exports = function(Constructor, NAME, next){
  Constructor.prototype = $.create(IteratorPrototype, {next: require('./$.property-desc')(1,next)});
  require('./$.tag')(Constructor, NAME + ' Iterator');
};
},{"./$":41,"./$.hide":27,"./$.property-desc":52,"./$.tag":67,"./$.wks":76}],37:[function(require,module,exports){
'use strict';
var LIBRARY         = require('./$.library')
  , $def            = require('./$.def')
  , $redef          = require('./$.redef')
  , hide            = require('./$.hide')
  , has             = require('./$.has')
  , SYMBOL_ITERATOR = require('./$.wks')('iterator')
  , Iterators       = require('./$.iterators')
  , FF_ITERATOR     = '@@iterator'
  , KEYS            = 'keys'
  , VALUES          = 'values';
var returnThis = function(){ return this; };
module.exports = function(Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCE){
  require('./$.iter-create')(Constructor, NAME, next);
  var createMethod = function(kind){
    switch(kind){
      case KEYS: return function keys(){ return new Constructor(this, kind); };
      case VALUES: return function values(){ return new Constructor(this, kind); };
    } return function entries(){ return new Constructor(this, kind); };
  };
  var TAG      = NAME + ' Iterator'
    , proto    = Base.prototype
    , _native  = proto[SYMBOL_ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT]
    , _default = _native || createMethod(DEFAULT)
    , methods, key;
  // Fix native
  if(_native){
    var IteratorPrototype = require('./$').getProto(_default.call(new Base));
    // Set @@toStringTag to native iterators
    require('./$.tag')(IteratorPrototype, TAG, true);
    // FF fix
    if(!LIBRARY && has(proto, FF_ITERATOR))hide(IteratorPrototype, SYMBOL_ITERATOR, returnThis);
  }
  // Define iterator
  if(!LIBRARY || FORCE)hide(proto, SYMBOL_ITERATOR, _default);
  // Plug for library
  Iterators[NAME] = _default;
  Iterators[TAG]  = returnThis;
  if(DEFAULT){
    methods = {
      keys:    IS_SET            ? _default : createMethod(KEYS),
      values:  DEFAULT == VALUES ? _default : createMethod(VALUES),
      entries: DEFAULT != VALUES ? _default : createMethod('entries')
    };
    if(FORCE)for(key in methods){
      if(!(key in proto))$redef(proto, key, methods[key]);
    } else $def($def.P + $def.F * require('./$.iter-buggy'), NAME, methods);
  }
};
},{"./$":41,"./$.def":15,"./$.has":26,"./$.hide":27,"./$.iter-buggy":34,"./$.iter-create":36,"./$.iterators":40,"./$.library":43,"./$.redef":53,"./$.tag":67,"./$.wks":76}],38:[function(require,module,exports){
var SYMBOL_ITERATOR = require('./$.wks')('iterator')
  , SAFE_CLOSING    = false;
try {
  var riter = [7][SYMBOL_ITERATOR]();
  riter['return'] = function(){ SAFE_CLOSING = true; };
  Array.from(riter, function(){ throw 2; });
} catch(e){ /* empty */ }
module.exports = function(exec){
  if(!SAFE_CLOSING)return false;
  var safe = false;
  try {
    var arr  = [7]
      , iter = arr[SYMBOL_ITERATOR]();
    iter.next = function(){ safe = true; };
    arr[SYMBOL_ITERATOR] = function(){ return iter; };
    exec(arr);
  } catch(e){ /* empty */ }
  return safe;
};
},{"./$.wks":76}],39:[function(require,module,exports){
module.exports = function(done, value){
  return {value: value, done: !!done};
};
},{}],40:[function(require,module,exports){
module.exports = {};
},{}],41:[function(require,module,exports){
var $Object = Object;
module.exports = {
  create:     $Object.create,
  getProto:   $Object.getPrototypeOf,
  isEnum:     {}.propertyIsEnumerable,
  getDesc:    $Object.getOwnPropertyDescriptor,
  setDesc:    $Object.defineProperty,
  setDescs:   $Object.defineProperties,
  getKeys:    $Object.keys,
  getNames:   $Object.getOwnPropertyNames,
  getSymbols: $Object.getOwnPropertySymbols,
  each:       [].forEach
};
},{}],42:[function(require,module,exports){
var $         = require('./$')
  , toIObject = require('./$.to-iobject');
module.exports = function(object, el){
  var O      = toIObject(object)
    , keys   = $.getKeys(O)
    , length = keys.length
    , index  = 0
    , key;
  while(length > index)if(O[key = keys[index++]] === el)return key;
};
},{"./$":41,"./$.to-iobject":71}],43:[function(require,module,exports){
module.exports = false;
},{}],44:[function(require,module,exports){
// 20.2.2.20 Math.log1p(x)
module.exports = Math.log1p || function log1p(x){
  return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
};
},{}],45:[function(require,module,exports){
var global    = require('./$.global')
  , macrotask = require('./$.task').set
  , Observer  = global.MutationObserver || global.WebKitMutationObserver
  , process   = global.process
  , isNode    = require('./$.cof')(process) == 'process'
  , head, last, notify;

var flush = function(){
  var parent, domain;
  if(isNode && (parent = process.domain)){
    process.domain = null;
    parent.exit();
  }
  while(head){
    domain = head.domain;
    if(domain)domain.enter();
    head.fn.call(); // <- currently we use it only for Promise - try / catch not required
    if(domain)domain.exit();
    head = head.next;
  } last = undefined;
  if(parent)parent.enter();
}

// Node.js
if(isNode){
  notify = function(){
    process.nextTick(flush);
  };
// browsers with MutationObserver
} else if(Observer){
  var toggle = 1
    , node   = document.createTextNode('');
  new Observer(flush).observe(node, {characterData: true}); // eslint-disable-line no-new
  notify = function(){
    node.data = toggle = -toggle;
  };
// for other environments - macrotask based on:
// - setImmediate
// - MessageChannel
// - window.postMessag
// - onreadystatechange
// - setTimeout
} else {
  notify = function(){
    // strange IE + webpack dev server bug - use .call(global)
    macrotask.call(global, flush);
  };
}

module.exports = function asap(fn){
  var task = {fn: fn, next: undefined, domain: isNode && process.domain};
  if(last)last.next = task;
  if(!head){
    head = task;
    notify();
  } last = task;
};
},{"./$.cof":8,"./$.global":25,"./$.task":68}],46:[function(require,module,exports){
var $redef = require('./$.redef');
module.exports = function(target, src){
  for(var key in src)$redef(target, key, src[key]);
  return target;
};
},{"./$.redef":53}],47:[function(require,module,exports){
// most Object methods by ES6 should accept primitives
module.exports = function(KEY, exec){
  var $def = require('./$.def')
    , fn   = (require('./$.core').Object || {})[KEY] || Object[KEY]
    , exp  = {};
  exp[KEY] = exec(fn);
  $def($def.S + $def.F * require('./$.fails')(function(){ fn(1); }), 'Object', exp);
};
},{"./$.core":13,"./$.def":15,"./$.fails":20}],48:[function(require,module,exports){
var $         = require('./$')
  , toIObject = require('./$.to-iobject');
module.exports = function(isEntries){
  return function(it){
    var O      = toIObject(it)
      , keys   = $.getKeys(O)
      , length = keys.length
      , i      = 0
      , result = Array(length)
      , key;
    if(isEntries)while(length > i)result[i] = [key = keys[i++], O[key]];
    else while(length > i)result[i] = O[keys[i++]];
    return result;
  };
};
},{"./$":41,"./$.to-iobject":71}],49:[function(require,module,exports){
// all object keys, includes non-enumerable and symbols
var $        = require('./$')
  , anObject = require('./$.an-object')
  , Reflect  = require('./$.global').Reflect;
module.exports = Reflect && Reflect.ownKeys || function ownKeys(it){
  var keys       = $.getNames(anObject(it))
    , getSymbols = $.getSymbols;
  return getSymbols ? keys.concat(getSymbols(it)) : keys;
};
},{"./$":41,"./$.an-object":3,"./$.global":25}],50:[function(require,module,exports){
'use strict';
var path      = require('./$.path')
  , invoke    = require('./$.invoke')
  , aFunction = require('./$.a-function');
module.exports = function(/* ...pargs */){
  var fn     = aFunction(this)
    , length = arguments.length
    , pargs  = Array(length)
    , i      = 0
    , _      = path._
    , holder = false;
  while(length > i)if((pargs[i] = arguments[i++]) === _)holder = true;
  return function(/* ...args */){
    var that    = this
      , _length = arguments.length
      , j = 0, k = 0, args;
    if(!holder && !_length)return invoke(fn, pargs, that);
    args = pargs.slice();
    if(holder)for(;length > j; j++)if(args[j] === _)args[j] = arguments[k++];
    while(_length > k)args.push(arguments[k++]);
    return invoke(fn, args, that);
  };
};
},{"./$.a-function":2,"./$.invoke":29,"./$.path":51}],51:[function(require,module,exports){
module.exports = require('./$.global');
},{"./$.global":25}],52:[function(require,module,exports){
module.exports = function(bitmap, value){
  return {
    enumerable  : !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable    : !(bitmap & 4),
    value       : value
  };
};
},{}],53:[function(require,module,exports){
// add fake Function#toString
// for correct work wrapped methods / constructors with methods like LoDash isNative
var global    = require('./$.global')
  , hide      = require('./$.hide')
  , SRC       = require('./$.uid')('src')
  , TO_STRING = 'toString'
  , $toString = Function[TO_STRING]
  , TPL       = ('' + $toString).split(TO_STRING);

require('./$.core').inspectSource = function(it){
  return $toString.call(it);
};

(module.exports = function(O, key, val, safe){
  if(typeof val == 'function'){
    hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
    if(!('name' in val))val.name = key;
  }
  if(O === global){
    O[key] = val;
  } else {
    if(!safe)delete O[key];
    hide(O, key, val);
  }
})(Function.prototype, TO_STRING, function toString(){
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});
},{"./$.core":13,"./$.global":25,"./$.hide":27,"./$.uid":74}],54:[function(require,module,exports){
module.exports = function(regExp, replace){
  var replacer = replace === Object(replace) ? function(part){
    return replace[part];
  } : replace;
  return function(it){
    return String(it).replace(regExp, replacer);
  };
};
},{}],55:[function(require,module,exports){
module.exports = Object.is || function is(x, y){
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};
},{}],56:[function(require,module,exports){
// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var getDesc  = require('./$').getDesc
  , isObject = require('./$.is-object')
  , anObject = require('./$.an-object');
var check = function(O, proto){
  anObject(O);
  if(!isObject(proto) && proto !== null)throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} // eslint-disable-line
    ? function(buggy, set){
        try {
          set = require('./$.ctx')(Function.call, getDesc(Object.prototype, '__proto__').set, 2);
          set({}, []);
        } catch(e){ buggy = true; }
        return function setPrototypeOf(O, proto){
          check(O, proto);
          if(buggy)O.__proto__ = proto;
          else set(O, proto);
          return O;
        };
      }()
    : undefined),
  check: check
};
},{"./$":41,"./$.an-object":3,"./$.ctx":14,"./$.is-object":33}],57:[function(require,module,exports){
var global = require('./$.global')
  , SHARED = '__core-js_shared__'
  , store  = global[SHARED] || (global[SHARED] = {});
module.exports = function(key){
  return store[key] || (store[key] = {});
};
},{"./$.global":25}],58:[function(require,module,exports){
// 20.2.2.28 Math.sign(x)
module.exports = Math.sign || function sign(x){
  return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
};
},{}],59:[function(require,module,exports){
'use strict';
var $       = require('./$')
  , SPECIES = require('./$.wks')('species');
module.exports = function(C){
  if(require('./$.support-desc') && !(SPECIES in C))$.setDesc(C, SPECIES, {
    configurable: true,
    get: function(){ return this; }
  });
};
},{"./$":41,"./$.support-desc":66,"./$.wks":76}],60:[function(require,module,exports){
module.exports = function(it, Constructor, name){
  if(!(it instanceof Constructor))throw TypeError(name + ": use the 'new' operator!");
  return it;
};
},{}],61:[function(require,module,exports){
// true  -> String#at
// false -> String#codePointAt
var toInteger = require('./$.to-integer')
  , defined   = require('./$.defined');
module.exports = function(TO_STRING){
  return function(that, pos){
    var s = String(defined(that))
      , i = toInteger(pos)
      , l = s.length
      , a, b;
    if(i < 0 || i >= l)return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l
      || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
        ? TO_STRING ? s.charAt(i) : a
        : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};
},{"./$.defined":16,"./$.to-integer":70}],62:[function(require,module,exports){
// helper for String#{startsWith, endsWith, includes}
var defined = require('./$.defined')
  , cof     = require('./$.cof');

module.exports = function(that, searchString, NAME){
  if(cof(searchString) == 'RegExp')throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(defined(that));
};
},{"./$.cof":8,"./$.defined":16}],63:[function(require,module,exports){
// https://github.com/ljharb/proposal-string-pad-left-right
var toLength = require('./$.to-length')
  , repeat   = require('./$.string-repeat')
  , defined  = require('./$.defined');

module.exports = function(that, maxLength, fillString, left){
  var S            = String(defined(that))
    , stringLength = S.length
    , fillStr      = fillString === undefined ? ' ' : String(fillString)
    , intMaxLength = toLength(maxLength);
  if(intMaxLength <= stringLength)return S;
  if(fillStr == '')fillStr = ' ';
  var fillLen = intMaxLength - stringLength
    , stringFiller = repeat.call(fillStr, Math.ceil(fillLen / fillStr.length));
  if(stringFiller.length > fillLen)stringFiller = left
    ? stringFiller.slice(stringFiller.length - fillLen)
    : stringFiller.slice(0, fillLen);
  return left ? stringFiller + S : S + stringFiller;
};
},{"./$.defined":16,"./$.string-repeat":64,"./$.to-length":72}],64:[function(require,module,exports){
'use strict';
var toInteger = require('./$.to-integer')
  , defined   = require('./$.defined');

module.exports = function repeat(count){
  var str = String(defined(this))
    , res = ''
    , n   = toInteger(count);
  if(n < 0 || n == Infinity)throw RangeError("Count can't be negative");
  for(;n > 0; (n >>>= 1) && (str += str))if(n & 1)res += str;
  return res;
};
},{"./$.defined":16,"./$.to-integer":70}],65:[function(require,module,exports){
// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = function(string, TYPE){
  string = String(defined(string));
  if(TYPE & 1)string = string.replace(ltrim, '');
  if(TYPE & 2)string = string.replace(rtrim, '');
  return string;
};

var $def    = require('./$.def')
  , defined = require('./$.defined')
  , spaces  = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
      '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF'
  , space   = '[' + spaces + ']'
  , non     = '\u200b\u0085'
  , ltrim   = RegExp('^' + space + space + '*')
  , rtrim   = RegExp(space + space + '*$');

module.exports = function(KEY, exec){
  var exp  = {};
  exp[KEY] = exec(trim);
  $def($def.P + $def.F * require('./$.fails')(function(){
    return !!spaces[KEY]() || non[KEY]() != non;
  }), 'String', exp);
};
},{"./$.def":15,"./$.defined":16,"./$.fails":20}],66:[function(require,module,exports){
// Thank's IE8 for his funny defineProperty
module.exports = !require('./$.fails')(function(){
  return Object.defineProperty({}, 'a', {get: function(){ return 7; }}).a != 7;
});
},{"./$.fails":20}],67:[function(require,module,exports){
var has  = require('./$.has')
  , hide = require('./$.hide')
  , TAG  = require('./$.wks')('toStringTag');

module.exports = function(it, tag, stat){
  if(it && !has(it = stat ? it : it.prototype, TAG))hide(it, TAG, tag);
};
},{"./$.has":26,"./$.hide":27,"./$.wks":76}],68:[function(require,module,exports){
'use strict';
var ctx                = require('./$.ctx')
  , invoke             = require('./$.invoke')
  , html               = require('./$.html')
  , cel                = require('./$.dom-create')
  , global             = require('./$.global')
  , process            = global.process
  , setTask            = global.setImmediate
  , clearTask          = global.clearImmediate
  , MessageChannel     = global.MessageChannel
  , counter            = 0
  , queue              = {}
  , ONREADYSTATECHANGE = 'onreadystatechange'
  , defer, channel, port;
var run = function(){
  var id = +this;
  if(queue.hasOwnProperty(id)){
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listner = function(event){
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if(!setTask || !clearTask){
  setTask = function setImmediate(fn){
    var args = [], i = 1;
    while(arguments.length > i)args.push(arguments[i++]);
    queue[++counter] = function(){
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id){
    delete queue[id];
  };
  // Node.js 0.8-
  if(require('./$.cof')(process) == 'process'){
    defer = function(id){
      process.nextTick(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if(MessageChannel){
    channel = new MessageChannel;
    port    = channel.port2;
    channel.port1.onmessage = listner;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if(global.addEventListener && typeof postMessage == 'function' && !global.importScript){
    defer = function(id){
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listner, false);
  // IE8-
  } else if(ONREADYSTATECHANGE in cel('script')){
    defer = function(id){
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function(){
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function(id){
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set:   setTask,
  clear: clearTask
};
},{"./$.cof":8,"./$.ctx":14,"./$.dom-create":17,"./$.global":25,"./$.html":28,"./$.invoke":29}],69:[function(require,module,exports){
var toInteger = require('./$.to-integer')
  , max       = Math.max
  , min       = Math.min;
module.exports = function(index, length){
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};
},{"./$.to-integer":70}],70:[function(require,module,exports){
// 7.1.4 ToInteger
var ceil  = Math.ceil
  , floor = Math.floor;
module.exports = function(it){
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};
},{}],71:[function(require,module,exports){
// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = require('./$.iobject')
  , defined = require('./$.defined');
module.exports = function(it){
  return IObject(defined(it));
};
},{"./$.defined":16,"./$.iobject":30}],72:[function(require,module,exports){
// 7.1.15 ToLength
var toInteger = require('./$.to-integer')
  , min       = Math.min;
module.exports = function(it){
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};
},{"./$.to-integer":70}],73:[function(require,module,exports){
// 7.1.13 ToObject(argument)
var defined = require('./$.defined');
module.exports = function(it){
  return Object(defined(it));
};
},{"./$.defined":16}],74:[function(require,module,exports){
var id = 0
  , px = Math.random();
module.exports = function(key){
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};
},{}],75:[function(require,module,exports){
// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = require('./$.wks')('unscopables');
if(!(UNSCOPABLES in []))require('./$.hide')(Array.prototype, UNSCOPABLES, {});
module.exports = function(key){
  [][UNSCOPABLES][key] = true;
};
},{"./$.hide":27,"./$.wks":76}],76:[function(require,module,exports){
var store  = require('./$.shared')('wks')
  , Symbol = require('./$.global').Symbol;
module.exports = function(name){
  return store[name] || (store[name] =
    Symbol && Symbol[name] || (Symbol || require('./$.uid'))('Symbol.' + name));
};
},{"./$.global":25,"./$.shared":57,"./$.uid":74}],77:[function(require,module,exports){
var classof   = require('./$.classof')
  , ITERATOR  = require('./$.wks')('iterator')
  , Iterators = require('./$.iterators');
module.exports = require('./$.core').getIteratorMethod = function(it){
  if(it != undefined)return it[ITERATOR] || it['@@iterator'] || Iterators[classof(it)];
};
},{"./$.classof":7,"./$.core":13,"./$.iterators":40,"./$.wks":76}],78:[function(require,module,exports){
'use strict';
var $                = require('./$')
  , SUPPORT_DESC     = require('./$.support-desc')
  , createDesc       = require('./$.property-desc')
  , html             = require('./$.html')
  , cel              = require('./$.dom-create')
  , has              = require('./$.has')
  , cof              = require('./$.cof')
  , $def             = require('./$.def')
  , invoke           = require('./$.invoke')
  , arrayMethod      = require('./$.array-methods')
  , IE_PROTO         = require('./$.uid')('__proto__')
  , isObject         = require('./$.is-object')
  , anObject         = require('./$.an-object')
  , aFunction        = require('./$.a-function')
  , toObject         = require('./$.to-object')
  , toIObject        = require('./$.to-iobject')
  , toInteger        = require('./$.to-integer')
  , toIndex          = require('./$.to-index')
  , toLength         = require('./$.to-length')
  , IObject          = require('./$.iobject')
  , fails            = require('./$.fails')
  , ObjectProto      = Object.prototype
  , A                = []
  , _slice           = A.slice
  , _join            = A.join
  , defineProperty   = $.setDesc
  , getOwnDescriptor = $.getDesc
  , defineProperties = $.setDescs
  , $indexOf         = require('./$.array-includes')(false)
  , factories        = {}
  , IE8_DOM_DEFINE;

if(!SUPPORT_DESC){
  IE8_DOM_DEFINE = !fails(function(){
    return defineProperty(cel('div'), 'a', {get: function(){ return 7; }}).a != 7;
  });
  $.setDesc = function(O, P, Attributes){
    if(IE8_DOM_DEFINE)try {
      return defineProperty(O, P, Attributes);
    } catch(e){ /* empty */ }
    if('get' in Attributes || 'set' in Attributes)throw TypeError('Accessors not supported!');
    if('value' in Attributes)anObject(O)[P] = Attributes.value;
    return O;
  };
  $.getDesc = function(O, P){
    if(IE8_DOM_DEFINE)try {
      return getOwnDescriptor(O, P);
    } catch(e){ /* empty */ }
    if(has(O, P))return createDesc(!ObjectProto.propertyIsEnumerable.call(O, P), O[P]);
  };
  $.setDescs = defineProperties = function(O, Properties){
    anObject(O);
    var keys   = $.getKeys(Properties)
      , length = keys.length
      , i = 0
      , P;
    while(length > i)$.setDesc(O, P = keys[i++], Properties[P]);
    return O;
  };
}
$def($def.S + $def.F * !SUPPORT_DESC, 'Object', {
  // 19.1.2.6 / 15.2.3.3 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $.getDesc,
  // 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
  defineProperty: $.setDesc,
  // 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
  defineProperties: defineProperties
});

  // IE 8- don't enum bug keys
var keys1 = ('constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,' +
            'toLocaleString,toString,valueOf').split(',')
  // Additional keys for getOwnPropertyNames
  , keys2 = keys1.concat('length', 'prototype')
  , keysLen1 = keys1.length;

// Create object with `null` prototype: use iframe Object with cleared prototype
var createDict = function(){
  // Thrash, waste and sodomy: IE GC bug
  var iframe = cel('iframe')
    , i      = keysLen1
    , gt     = '>'
    , iframeDocument;
  iframe.style.display = 'none';
  html.appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write('<script>document.F=Object</script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while(i--)delete createDict.prototype[keys1[i]];
  return createDict();
};
var createGetKeys = function(names, length){
  return function(object){
    var O      = toIObject(object)
      , i      = 0
      , result = []
      , key;
    for(key in O)if(key != IE_PROTO)has(O, key) && result.push(key);
    // Don't enum bug & hidden keys
    while(length > i)if(has(O, key = names[i++])){
      ~$indexOf(result, key) || result.push(key);
    }
    return result;
  };
};
var Empty = function(){};
$def($def.S, 'Object', {
  // 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
  getPrototypeOf: $.getProto = $.getProto || function(O){
    O = toObject(O);
    if(has(O, IE_PROTO))return O[IE_PROTO];
    if(typeof O.constructor == 'function' && O instanceof O.constructor){
      return O.constructor.prototype;
    } return O instanceof Object ? ObjectProto : null;
  },
  // 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $.getNames = $.getNames || createGetKeys(keys2, keys2.length, true),
  // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
  create: $.create = $.create || function(O, /*?*/Properties){
    var result;
    if(O !== null){
      Empty.prototype = anObject(O);
      result = new Empty();
      Empty.prototype = null;
      // add "__proto__" for Object.getPrototypeOf shim
      result[IE_PROTO] = O;
    } else result = createDict();
    return Properties === undefined ? result : defineProperties(result, Properties);
  },
  // 19.1.2.14 / 15.2.3.14 Object.keys(O)
  keys: $.getKeys = $.getKeys || createGetKeys(keys1, keysLen1, false)
});

var construct = function(F, len, args){
  if(!(len in factories)){
    for(var n = [], i = 0; i < len; i++)n[i] = 'a[' + i + ']';
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  }
  return factories[len](F, args);
};

// 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
$def($def.P, 'Function', {
  bind: function bind(that /*, args... */){
    var fn       = aFunction(this)
      , partArgs = _slice.call(arguments, 1);
    var bound = function(/* args... */){
      var args = partArgs.concat(_slice.call(arguments));
      return this instanceof bound ? construct(fn, args.length, args) : invoke(fn, args, that);
    };
    if(isObject(fn.prototype))bound.prototype = fn.prototype;
    return bound;
  }
});

// fallback for not array-like ES3 strings and DOM objects
var buggySlice = fails(function(){
  if(html)_slice.call(html);
});

$def($def.P + $def.F * buggySlice, 'Array', {
  slice: function(begin, end){
    var len   = toLength(this.length)
      , klass = cof(this);
    end = end === undefined ? len : end;
    if(klass == 'Array')return _slice.call(this, begin, end);
    var start  = toIndex(begin, len)
      , upTo   = toIndex(end, len)
      , size   = toLength(upTo - start)
      , cloned = Array(size)
      , i      = 0;
    for(; i < size; i++)cloned[i] = klass == 'String'
      ? this.charAt(start + i)
      : this[start + i];
    return cloned;
  }
});
$def($def.P + $def.F * (IObject != Object), 'Array', {
  join: function(){
    return _join.apply(IObject(this), arguments);
  }
});

// 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
$def($def.S, 'Array', {isArray: function(arg){ return cof(arg) == 'Array'; }});

var createArrayReduce = function(isRight){
  return function(callbackfn, memo){
    aFunction(callbackfn);
    var O      = IObject(this)
      , length = toLength(O.length)
      , index  = isRight ? length - 1 : 0
      , i      = isRight ? -1 : 1;
    if(arguments.length < 2)for(;;){
      if(index in O){
        memo = O[index];
        index += i;
        break;
      }
      index += i;
      if(isRight ? index < 0 : length <= index){
        throw TypeError('Reduce of empty array with no initial value');
      }
    }
    for(;isRight ? index >= 0 : length > index; index += i)if(index in O){
      memo = callbackfn(memo, O[index], index, this);
    }
    return memo;
  };
};
var methodize = function($fn){
  return function(arg1/*, arg2 = undefined */){
    return $fn(this, arg1, arguments[1]);
  };
};
$def($def.P, 'Array', {
  // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
  forEach: $.each = $.each || methodize(arrayMethod(0)),
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: methodize(arrayMethod(1)),
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: methodize(arrayMethod(2)),
  // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
  some: methodize(arrayMethod(3)),
  // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
  every: methodize(arrayMethod(4)),
  // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
  reduce: createArrayReduce(false),
  // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
  reduceRight: createArrayReduce(true),
  // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
  indexOf: methodize($indexOf),
  // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
  lastIndexOf: function(el, fromIndex /* = @[*-1] */){
    var O      = toIObject(this)
      , length = toLength(O.length)
      , index  = length - 1;
    if(arguments.length > 1)index = Math.min(index, toInteger(fromIndex));
    if(index < 0)index = toLength(length + index);
    for(;index >= 0; index--)if(index in O)if(O[index] === el)return index;
    return -1;
  }
});

// 20.3.3.1 / 15.9.4.4 Date.now()
$def($def.S, 'Date', {now: function(){ return +new Date; }});

var lz = function(num){
  return num > 9 ? num : '0' + num;
};

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
// PhantomJS and old webkit had a broken Date implementation.
var date       = new Date(-5e13 - 1)
  , brokenDate = !(date.toISOString && date.toISOString() == '0385-07-25T07:06:39.999Z'
      && fails(function(){ new Date(NaN).toISOString(); }));
$def($def.P + $def.F * brokenDate, 'Date', {
  toISOString: function toISOString(){
    if(!isFinite(this))throw RangeError('Invalid time value');
    var d = this
      , y = d.getUTCFullYear()
      , m = d.getUTCMilliseconds()
      , s = y < 0 ? '-' : y > 9999 ? '+' : '';
    return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) +
      '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) +
      'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) +
      ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
  }
});
},{"./$":41,"./$.a-function":2,"./$.an-object":3,"./$.array-includes":4,"./$.array-methods":5,"./$.cof":8,"./$.def":15,"./$.dom-create":17,"./$.fails":20,"./$.has":26,"./$.html":28,"./$.invoke":29,"./$.iobject":30,"./$.is-object":33,"./$.property-desc":52,"./$.support-desc":66,"./$.to-index":69,"./$.to-integer":70,"./$.to-iobject":71,"./$.to-length":72,"./$.to-object":73,"./$.uid":74}],79:[function(require,module,exports){
'use strict';
var $def     = require('./$.def')
  , toObject = require('./$.to-object')
  , toIndex  = require('./$.to-index')
  , toLength = require('./$.to-length');
$def($def.P, 'Array', {
  // 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
  copyWithin: function copyWithin(target/* = 0 */, start /* = 0, end = @length */){
    var O     = toObject(this)
      , len   = toLength(O.length)
      , to    = toIndex(target, len)
      , from  = toIndex(start, len)
      , end   = arguments[2]
      , fin   = end === undefined ? len : toIndex(end, len)
      , count = Math.min(fin - from, len - to)
      , inc   = 1;
    if(from < to && to < from + count){
      inc  = -1;
      from = from + count - 1;
      to   = to   + count - 1;
    }
    while(count-- > 0){
      if(from in O)O[to] = O[from];
      else delete O[to];
      to   += inc;
      from += inc;
    } return O;
  }
});
require('./$.unscope')('copyWithin');
},{"./$.def":15,"./$.to-index":69,"./$.to-length":72,"./$.to-object":73,"./$.unscope":75}],80:[function(require,module,exports){
'use strict';
var $def     = require('./$.def')
  , toObject = require('./$.to-object')
  , toIndex  = require('./$.to-index')
  , toLength = require('./$.to-length');
$def($def.P, 'Array', {
  // 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
  fill: function fill(value /*, start = 0, end = @length */){
    var O      = toObject(this, true)
      , length = toLength(O.length)
      , index  = toIndex(arguments[1], length)
      , end    = arguments[2]
      , endPos = end === undefined ? length : toIndex(end, length);
    while(endPos > index)O[index++] = value;
    return O;
  }
});
require('./$.unscope')('fill');
},{"./$.def":15,"./$.to-index":69,"./$.to-length":72,"./$.to-object":73,"./$.unscope":75}],81:[function(require,module,exports){
'use strict';
// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)
var KEY    = 'findIndex'
  , $def   = require('./$.def')
  , forced = true
  , $find  = require('./$.array-methods')(6);
// Shouldn't skip holes
if(KEY in [])Array(1)[KEY](function(){ forced = false; });
$def($def.P + $def.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn/*, that = undefined */){
    return $find(this, callbackfn, arguments[1]);
  }
});
require('./$.unscope')(KEY);
},{"./$.array-methods":5,"./$.def":15,"./$.unscope":75}],82:[function(require,module,exports){
'use strict';
// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)
var KEY    = 'find'
  , $def   = require('./$.def')
  , forced = true
  , $find  = require('./$.array-methods')(5);
// Shouldn't skip holes
if(KEY in [])Array(1)[KEY](function(){ forced = false; });
$def($def.P + $def.F * forced, 'Array', {
  find: function find(callbackfn/*, that = undefined */){
    return $find(this, callbackfn, arguments[1]);
  }
});
require('./$.unscope')(KEY);
},{"./$.array-methods":5,"./$.def":15,"./$.unscope":75}],83:[function(require,module,exports){
'use strict';
var ctx         = require('./$.ctx')
  , $def        = require('./$.def')
  , toObject    = require('./$.to-object')
  , call        = require('./$.iter-call')
  , isArrayIter = require('./$.is-array-iter')
  , toLength    = require('./$.to-length')
  , getIterFn   = require('./core.get-iterator-method');
$def($def.S + $def.F * !require('./$.iter-detect')(function(iter){ Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike/*, mapfn = undefined, thisArg = undefined*/){
    var O       = toObject(arrayLike)
      , C       = typeof this == 'function' ? this : Array
      , mapfn   = arguments[1]
      , mapping = mapfn !== undefined
      , index   = 0
      , iterFn  = getIterFn(O)
      , length, result, step, iterator;
    if(mapping)mapfn = ctx(mapfn, arguments[2], 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if(iterFn != undefined && !(C == Array && isArrayIter(iterFn))){
      for(iterator = iterFn.call(O), result = new C; !(step = iterator.next()).done; index++){
        result[index] = mapping ? call(iterator, mapfn, [step.value, index], true) : step.value;
      }
    } else {
      for(result = new C(length = toLength(O.length)); length > index; index++){
        result[index] = mapping ? mapfn(O[index], index) : O[index];
      }
    }
    result.length = index;
    return result;
  }
});
},{"./$.ctx":14,"./$.def":15,"./$.is-array-iter":31,"./$.iter-call":35,"./$.iter-detect":38,"./$.to-length":72,"./$.to-object":73,"./core.get-iterator-method":77}],84:[function(require,module,exports){
'use strict';
var setUnscope = require('./$.unscope')
  , step       = require('./$.iter-step')
  , Iterators  = require('./$.iterators')
  , toIObject  = require('./$.to-iobject');

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
require('./$.iter-define')(Array, 'Array', function(iterated, kind){
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function(){
  var O     = this._t
    , kind  = this._k
    , index = this._i++;
  if(!O || index >= O.length){
    this._t = undefined;
    return step(1);
  }
  if(kind == 'keys'  )return step(0, index);
  if(kind == 'values')return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

setUnscope('keys');
setUnscope('values');
setUnscope('entries');
},{"./$.iter-define":37,"./$.iter-step":39,"./$.iterators":40,"./$.to-iobject":71,"./$.unscope":75}],85:[function(require,module,exports){
'use strict';
var $def = require('./$.def');
$def($def.S, 'Array', {
  // 22.1.2.3 Array.of( ...items)
  of: function of(/* ...args */){
    var index  = 0
      , length = arguments.length
      , result = new (typeof this == 'function' ? this : Array)(length);
    while(length > index)result[index] = arguments[index++];
    result.length = length;
    return result;
  }
});
},{"./$.def":15}],86:[function(require,module,exports){
require('./$.species')(Array);
},{"./$.species":59}],87:[function(require,module,exports){
'use strict';
var $             = require('./$')
  , isObject      = require('./$.is-object')
  , HAS_INSTANCE  = require('./$.wks')('hasInstance')
  , FunctionProto = Function.prototype;
// 19.2.3.6 Function.prototype[@@hasInstance](V)
if(!(HAS_INSTANCE in FunctionProto))$.setDesc(FunctionProto, HAS_INSTANCE, {value: function(O){
  if(typeof this != 'function' || !isObject(O))return false;
  if(!isObject(this.prototype))return O instanceof this;
  // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
  while(O = $.getProto(O))if(this.prototype === O)return true;
  return false;
}});
},{"./$":41,"./$.is-object":33,"./$.wks":76}],88:[function(require,module,exports){
var setDesc    = require('./$').setDesc
  , createDesc = require('./$.property-desc')
  , has        = require('./$.has')
  , FProto     = Function.prototype
  , nameRE     = /^\s*function ([^ (]*)/
  , NAME       = 'name';
// 19.2.4.2 name
NAME in FProto || require('./$.support-desc') && setDesc(FProto, NAME, {
  configurable: true,
  get: function(){
    var match = ('' + this).match(nameRE)
      , name  = match ? match[1] : '';
    has(this, NAME) || setDesc(this, NAME, createDesc(5, name));
    return name;
  }
});
},{"./$":41,"./$.has":26,"./$.property-desc":52,"./$.support-desc":66}],89:[function(require,module,exports){
'use strict';
var strong = require('./$.collection-strong');

// 23.1 Map Objects
require('./$.collection')('Map', function(get){
  return function Map(){ return get(this, arguments[0]); };
}, {
  // 23.1.3.6 Map.prototype.get(key)
  get: function get(key){
    var entry = strong.getEntry(this, key);
    return entry && entry.v;
  },
  // 23.1.3.9 Map.prototype.set(key, value)
  set: function set(key, value){
    return strong.def(this, key === 0 ? 0 : key, value);
  }
}, strong, true);
},{"./$.collection":12,"./$.collection-strong":9}],90:[function(require,module,exports){
// 20.2.2.3 Math.acosh(x)
var $def   = require('./$.def')
  , log1p  = require('./$.log1p')
  , sqrt   = Math.sqrt
  , $acosh = Math.acosh;

// V8 bug https://code.google.com/p/v8/issues/detail?id=3509 
$def($def.S + $def.F * !($acosh && Math.floor($acosh(Number.MAX_VALUE)) == 710), 'Math', {
  acosh: function acosh(x){
    return (x = +x) < 1 ? NaN : x > 94906265.62425156
      ? Math.log(x) + Math.LN2
      : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
  }
});
},{"./$.def":15,"./$.log1p":44}],91:[function(require,module,exports){
// 20.2.2.5 Math.asinh(x)
var $def = require('./$.def');

function asinh(x){
  return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
}

$def($def.S, 'Math', {asinh: asinh});
},{"./$.def":15}],92:[function(require,module,exports){
// 20.2.2.7 Math.atanh(x)
var $def = require('./$.def');

$def($def.S, 'Math', {
  atanh: function atanh(x){
    return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
  }
});
},{"./$.def":15}],93:[function(require,module,exports){
// 20.2.2.9 Math.cbrt(x)
var $def = require('./$.def')
  , sign = require('./$.sign');

$def($def.S, 'Math', {
  cbrt: function cbrt(x){
    return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
  }
});
},{"./$.def":15,"./$.sign":58}],94:[function(require,module,exports){
// 20.2.2.11 Math.clz32(x)
var $def = require('./$.def');

$def($def.S, 'Math', {
  clz32: function clz32(x){
    return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
  }
});
},{"./$.def":15}],95:[function(require,module,exports){
// 20.2.2.12 Math.cosh(x)
var $def = require('./$.def')
  , exp  = Math.exp;

$def($def.S, 'Math', {
  cosh: function cosh(x){
    return (exp(x = +x) + exp(-x)) / 2;
  }
});
},{"./$.def":15}],96:[function(require,module,exports){
// 20.2.2.14 Math.expm1(x)
var $def = require('./$.def');

$def($def.S, 'Math', {expm1: require('./$.expm1')});
},{"./$.def":15,"./$.expm1":19}],97:[function(require,module,exports){
// 20.2.2.16 Math.fround(x)
var $def  = require('./$.def')
  , sign  = require('./$.sign')
  , pow   = Math.pow
  , EPSILON   = pow(2, -52)
  , EPSILON32 = pow(2, -23)
  , MAX32     = pow(2, 127) * (2 - EPSILON32)
  , MIN32     = pow(2, -126);

var roundTiesToEven = function(n){
  return n + 1 / EPSILON - 1 / EPSILON;
};


$def($def.S, 'Math', {
  fround: function fround(x){
    var $abs  = Math.abs(x)
      , $sign = sign(x)
      , a, result;
    if($abs < MIN32)return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
    a = (1 + EPSILON32 / EPSILON) * $abs;
    result = a - (a - $abs);
    if(result > MAX32 || result != result)return $sign * Infinity;
    return $sign * result;
  }
});
},{"./$.def":15,"./$.sign":58}],98:[function(require,module,exports){
// 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
var $def = require('./$.def')
  , abs  = Math.abs;

$def($def.S, 'Math', {
  hypot: function hypot(value1, value2){ // eslint-disable-line no-unused-vars
    var sum  = 0
      , i    = 0
      , len  = arguments.length
      , larg = 0
      , arg, div;
    while(i < len){
      arg = abs(arguments[i++]);
      if(larg < arg){
        div  = larg / arg;
        sum  = sum * div * div + 1;
        larg = arg;
      } else if(arg > 0){
        div  = arg / larg;
        sum += div * div;
      } else sum += arg;
    }
    return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
  }
});
},{"./$.def":15}],99:[function(require,module,exports){
// 20.2.2.18 Math.imul(x, y)
var $def = require('./$.def');

// WebKit fails with big numbers
$def($def.S + $def.F * require('./$.fails')(function(){
  return Math.imul(0xffffffff, 5) != -5;
}), 'Math', {
  imul: function imul(x, y){
    var UINT16 = 0xffff
      , xn = +x
      , yn = +y
      , xl = UINT16 & xn
      , yl = UINT16 & yn;
    return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
  }
});
},{"./$.def":15,"./$.fails":20}],100:[function(require,module,exports){
// 20.2.2.21 Math.log10(x)
var $def = require('./$.def');

$def($def.S, 'Math', {
  log10: function log10(x){
    return Math.log(x) / Math.LN10;
  }
});
},{"./$.def":15}],101:[function(require,module,exports){
// 20.2.2.20 Math.log1p(x)
var $def = require('./$.def');

$def($def.S, 'Math', {log1p: require('./$.log1p')});
},{"./$.def":15,"./$.log1p":44}],102:[function(require,module,exports){
// 20.2.2.22 Math.log2(x)
var $def = require('./$.def');

$def($def.S, 'Math', {
  log2: function log2(x){
    return Math.log(x) / Math.LN2;
  }
});
},{"./$.def":15}],103:[function(require,module,exports){
// 20.2.2.28 Math.sign(x)
var $def = require('./$.def');

$def($def.S, 'Math', {sign: require('./$.sign')});
},{"./$.def":15,"./$.sign":58}],104:[function(require,module,exports){
// 20.2.2.30 Math.sinh(x)
var $def  = require('./$.def')
  , expm1 = require('./$.expm1')
  , exp   = Math.exp;

$def($def.S, 'Math', {
  sinh: function sinh(x){
    return Math.abs(x = +x) < 1
      ? (expm1(x) - expm1(-x)) / 2
      : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
  }
});
},{"./$.def":15,"./$.expm1":19}],105:[function(require,module,exports){
// 20.2.2.33 Math.tanh(x)
var $def  = require('./$.def')
  , expm1 = require('./$.expm1')
  , exp   = Math.exp;

$def($def.S, 'Math', {
  tanh: function tanh(x){
    var a = expm1(x = +x)
      , b = expm1(-x);
    return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
  }
});
},{"./$.def":15,"./$.expm1":19}],106:[function(require,module,exports){
// 20.2.2.34 Math.trunc(x)
var $def = require('./$.def');

$def($def.S, 'Math', {
  trunc: function trunc(it){
    return (it > 0 ? Math.floor : Math.ceil)(it);
  }
});
},{"./$.def":15}],107:[function(require,module,exports){
'use strict';
var $          = require('./$')
  , global     = require('./$.global')
  , has        = require('./$.has')
  , cof        = require('./$.cof')
  , isObject   = require('./$.is-object')
  , fails      = require('./$.fails')
  , NUMBER     = 'Number'
  , $Number    = global[NUMBER]
  , Base       = $Number
  , proto      = $Number.prototype
  // Opera ~12 has broken Object#toString
  , BROKEN_COF = cof($.create(proto)) == NUMBER;
var toPrimitive = function(it){
  var fn, val;
  if(typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it)))return val;
  if(typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it)))return val;
  throw TypeError("Can't convert object to number");
};
var toNumber = function(it){
  if(isObject(it))it = toPrimitive(it);
  if(typeof it == 'string' && it.length > 2 && it.charCodeAt(0) == 48){
    var binary = false;
    switch(it.charCodeAt(1)){
      case 66 : case 98  : binary = true;
      case 79 : case 111 : return parseInt(it.slice(2), binary ? 2 : 8);
    }
  } return +it;
};
if(!($Number('0o1') && $Number('0b1'))){
  $Number = function Number(it){
    var that = this;
    return that instanceof $Number
      // check on 1..constructor(foo) case
      && (BROKEN_COF ? fails(function(){ proto.valueOf.call(that); }) : cof(that) != NUMBER)
        ? new Base(toNumber(it)) : toNumber(it);
  };
  $.each.call(require('./$.support-desc') ? $.getNames(Base) : (
      // ES3:
      'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
      // ES6 (in case, if modules with ES6 Number statics required before):
      'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' +
      'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger'
    ).split(','), function(key){
      if(has(Base, key) && !has($Number, key)){
        $.setDesc($Number, key, $.getDesc(Base, key));
      }
    }
  );
  $Number.prototype = proto;
  proto.constructor = $Number;
  require('./$.redef')(global, NUMBER, $Number);
}
},{"./$":41,"./$.cof":8,"./$.fails":20,"./$.global":25,"./$.has":26,"./$.is-object":33,"./$.redef":53,"./$.support-desc":66}],108:[function(require,module,exports){
// 20.1.2.1 Number.EPSILON
var $def = require('./$.def');

$def($def.S, 'Number', {EPSILON: Math.pow(2, -52)});
},{"./$.def":15}],109:[function(require,module,exports){
// 20.1.2.2 Number.isFinite(number)
var $def      = require('./$.def')
  , _isFinite = require('./$.global').isFinite;

$def($def.S, 'Number', {
  isFinite: function isFinite(it){
    return typeof it == 'number' && _isFinite(it);
  }
});
},{"./$.def":15,"./$.global":25}],110:[function(require,module,exports){
// 20.1.2.3 Number.isInteger(number)
var $def = require('./$.def');

$def($def.S, 'Number', {isInteger: require('./$.is-integer')});
},{"./$.def":15,"./$.is-integer":32}],111:[function(require,module,exports){
// 20.1.2.4 Number.isNaN(number)
var $def = require('./$.def');

$def($def.S, 'Number', {
  isNaN: function isNaN(number){
    return number != number;
  }
});
},{"./$.def":15}],112:[function(require,module,exports){
// 20.1.2.5 Number.isSafeInteger(number)
var $def      = require('./$.def')
  , isInteger = require('./$.is-integer')
  , abs       = Math.abs;

$def($def.S, 'Number', {
  isSafeInteger: function isSafeInteger(number){
    return isInteger(number) && abs(number) <= 0x1fffffffffffff;
  }
});
},{"./$.def":15,"./$.is-integer":32}],113:[function(require,module,exports){
// 20.1.2.6 Number.MAX_SAFE_INTEGER
var $def = require('./$.def');

$def($def.S, 'Number', {MAX_SAFE_INTEGER: 0x1fffffffffffff});
},{"./$.def":15}],114:[function(require,module,exports){
// 20.1.2.10 Number.MIN_SAFE_INTEGER
var $def = require('./$.def');

$def($def.S, 'Number', {MIN_SAFE_INTEGER: -0x1fffffffffffff});
},{"./$.def":15}],115:[function(require,module,exports){
// 20.1.2.12 Number.parseFloat(string)
var $def = require('./$.def');

$def($def.S, 'Number', {parseFloat: parseFloat});
},{"./$.def":15}],116:[function(require,module,exports){
// 20.1.2.13 Number.parseInt(string, radix)
var $def = require('./$.def');

$def($def.S, 'Number', {parseInt: parseInt});
},{"./$.def":15}],117:[function(require,module,exports){
// 19.1.3.1 Object.assign(target, source)
var $def = require('./$.def');
$def($def.S, 'Object', {assign: require('./$.assign')});
},{"./$.assign":6,"./$.def":15}],118:[function(require,module,exports){
// 19.1.2.5 Object.freeze(O)
var isObject = require('./$.is-object');

require('./$.object-sap')('freeze', function($freeze){
  return function freeze(it){
    return $freeze && isObject(it) ? $freeze(it) : it;
  };
});
},{"./$.is-object":33,"./$.object-sap":47}],119:[function(require,module,exports){
// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = require('./$.to-iobject');

require('./$.object-sap')('getOwnPropertyDescriptor', function($getOwnPropertyDescriptor){
  return function getOwnPropertyDescriptor(it, key){
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});
},{"./$.object-sap":47,"./$.to-iobject":71}],120:[function(require,module,exports){
// 19.1.2.7 Object.getOwnPropertyNames(O)
require('./$.object-sap')('getOwnPropertyNames', function(){
  return require('./$.get-names').get;
});
},{"./$.get-names":24,"./$.object-sap":47}],121:[function(require,module,exports){
// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = require('./$.to-object');

require('./$.object-sap')('getPrototypeOf', function($getPrototypeOf){
  return function getPrototypeOf(it){
    return $getPrototypeOf(toObject(it));
  };
});
},{"./$.object-sap":47,"./$.to-object":73}],122:[function(require,module,exports){
// 19.1.2.11 Object.isExtensible(O)
var isObject = require('./$.is-object');

require('./$.object-sap')('isExtensible', function($isExtensible){
  return function isExtensible(it){
    return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
  };
});
},{"./$.is-object":33,"./$.object-sap":47}],123:[function(require,module,exports){
// 19.1.2.12 Object.isFrozen(O)
var isObject = require('./$.is-object');

require('./$.object-sap')('isFrozen', function($isFrozen){
  return function isFrozen(it){
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});
},{"./$.is-object":33,"./$.object-sap":47}],124:[function(require,module,exports){
// 19.1.2.13 Object.isSealed(O)
var isObject = require('./$.is-object');

require('./$.object-sap')('isSealed', function($isSealed){
  return function isSealed(it){
    return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
  };
});
},{"./$.is-object":33,"./$.object-sap":47}],125:[function(require,module,exports){
// 19.1.3.10 Object.is(value1, value2)
var $def = require('./$.def');
$def($def.S, 'Object', {
  is: require('./$.same')
});
},{"./$.def":15,"./$.same":55}],126:[function(require,module,exports){
// 19.1.2.14 Object.keys(O)
var toObject = require('./$.to-object');

require('./$.object-sap')('keys', function($keys){
  return function keys(it){
    return $keys(toObject(it));
  };
});
},{"./$.object-sap":47,"./$.to-object":73}],127:[function(require,module,exports){
// 19.1.2.15 Object.preventExtensions(O)
var isObject = require('./$.is-object');

require('./$.object-sap')('preventExtensions', function($preventExtensions){
  return function preventExtensions(it){
    return $preventExtensions && isObject(it) ? $preventExtensions(it) : it;
  };
});
},{"./$.is-object":33,"./$.object-sap":47}],128:[function(require,module,exports){
// 19.1.2.17 Object.seal(O)
var isObject = require('./$.is-object');

require('./$.object-sap')('seal', function($seal){
  return function seal(it){
    return $seal && isObject(it) ? $seal(it) : it;
  };
});
},{"./$.is-object":33,"./$.object-sap":47}],129:[function(require,module,exports){
// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $def = require('./$.def');
$def($def.S, 'Object', {setPrototypeOf: require('./$.set-proto').set});
},{"./$.def":15,"./$.set-proto":56}],130:[function(require,module,exports){
'use strict';
// 19.1.3.6 Object.prototype.toString()
var classof = require('./$.classof')
  , test    = {};
test[require('./$.wks')('toStringTag')] = 'z';
if(test + '' != '[object z]'){
  require('./$.redef')(Object.prototype, 'toString', function toString(){
    return '[object ' + classof(this) + ']';
  }, true);
}
},{"./$.classof":7,"./$.redef":53,"./$.wks":76}],131:[function(require,module,exports){
'use strict';
var $          = require('./$')
  , LIBRARY    = require('./$.library')
  , global     = require('./$.global')
  , ctx        = require('./$.ctx')
  , classof    = require('./$.classof')
  , $def       = require('./$.def')
  , isObject   = require('./$.is-object')
  , anObject   = require('./$.an-object')
  , aFunction  = require('./$.a-function')
  , strictNew  = require('./$.strict-new')
  , forOf      = require('./$.for-of')
  , setProto   = require('./$.set-proto').set
  , same       = require('./$.same')
  , species    = require('./$.species')
  , SPECIES    = require('./$.wks')('species')
  , RECORD     = require('./$.uid')('record')
  , asap       = require('./$.microtask')
  , PROMISE    = 'Promise'
  , process    = global.process
  , isNode     = classof(process) == 'process'
  , P          = global[PROMISE]
  , Wrapper;

var testResolve = function(sub){
  var test = new P(function(){});
  if(sub)test.constructor = Object;
  return P.resolve(test) === test;
};

var useNative = function(){
  var works = false;
  function P2(x){
    var self = new P(x);
    setProto(self, P2.prototype);
    return self;
  }
  try {
    works = P && P.resolve && testResolve();
    setProto(P2, P);
    P2.prototype = $.create(P.prototype, {constructor: {value: P2}});
    // actual Firefox has broken subclass support, test that
    if(!(P2.resolve(5).then(function(){}) instanceof P2)){
      works = false;
    }
    // actual V8 bug, https://code.google.com/p/v8/issues/detail?id=4162
    if(works && require('./$.support-desc')){
      var thenableThenGotten = false;
      P.resolve($.setDesc({}, 'then', {
        get: function(){ thenableThenGotten = true; }
      }));
      works = thenableThenGotten;
    }
  } catch(e){ works = false; }
  return works;
}();

// helpers
var isPromise = function(it){
  return isObject(it) && (useNative ? classof(it) == 'Promise' : RECORD in it);
};
var sameConstructor = function(a, b){
  // library wrapper special case
  if(LIBRARY && a === P && b === Wrapper)return true;
  return same(a, b);
};
var getConstructor = function(C){
  var S = anObject(C)[SPECIES];
  return S != undefined ? S : C;
};
var isThenable = function(it){
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function(record, isReject){
  if(record.n)return;
  record.n = true;
  var chain = record.c;
  asap(function(){
    var value = record.v
      , ok    = record.s == 1
      , i     = 0;
    var run = function(react){
      var cb = ok ? react.ok : react.fail
        , ret, then;
      try {
        if(cb){
          if(!ok)record.h = true;
          ret = cb === true ? value : cb(value);
          if(ret === react.P){
            react.rej(TypeError('Promise-chain cycle'));
          } else if(then = isThenable(ret)){
            then.call(ret, react.res, react.rej);
          } else react.res(ret);
        } else react.rej(value);
      } catch(err){
        react.rej(err);
      }
    };
    while(chain.length > i)run(chain[i++]); // variable length - can't use forEach
    chain.length = 0;
    record.n = false;
    if(isReject)setTimeout(function(){
      asap(function(){
        if(isUnhandled(record.p)){
          if(isNode){
            process.emit('unhandledRejection', value, record.p);
          } else if(global.console && console.error){
            console.error('Unhandled promise rejection', value);
          }
        }
        record.a = undefined;
      });
    }, 1);
  });
};
var isUnhandled = function(promise){
  var record = promise[RECORD]
    , chain  = record.a || record.c
    , i      = 0
    , react;
  if(record.h)return false;
  while(chain.length > i){
    react = chain[i++];
    if(react.fail || !isUnhandled(react.P))return false;
  } return true;
};
var $reject = function(value){
  var record = this;
  if(record.d)return;
  record.d = true;
  record = record.r || record; // unwrap
  record.v = value;
  record.s = 2;
  record.a = record.c.slice();
  notify(record, true);
};
var $resolve = function(value){
  var record = this
    , then;
  if(record.d)return;
  record.d = true;
  record = record.r || record; // unwrap
  try {
    if(then = isThenable(value)){
      asap(function(){
        var wrapper = {r: record, d: false}; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch(e){
          $reject.call(wrapper, e);
        }
      });
    } else {
      record.v = value;
      record.s = 1;
      notify(record, false);
    }
  } catch(e){
    $reject.call({r: record, d: false}, e); // wrap
  }
};

// constructor polyfill
if(!useNative){
  // 25.4.3.1 Promise(executor)
  P = function Promise(executor){
    aFunction(executor);
    var record = {
      p: strictNew(this, P, PROMISE),         // <- promise
      c: [],                                  // <- awaiting reactions
      a: undefined,                           // <- checked in isUnhandled reactions
      s: 0,                                   // <- state
      d: false,                               // <- done
      v: undefined,                           // <- value
      h: false,                               // <- handled rejection
      n: false                                // <- notify
    };
    this[RECORD] = record;
    try {
      executor(ctx($resolve, record, 1), ctx($reject, record, 1));
    } catch(err){
      $reject.call(record, err);
    }
  };
  require('./$.mix')(P.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected){
      var S = anObject(anObject(this).constructor)[SPECIES];
      var react = {
        ok:   typeof onFulfilled == 'function' ? onFulfilled : true,
        fail: typeof onRejected == 'function'  ? onRejected  : false
      };
      var promise = react.P = new (S != undefined ? S : P)(function(res, rej){
        react.res = aFunction(res);
        react.rej = aFunction(rej);
      });
      var record = this[RECORD];
      record.c.push(react);
      if(record.a)record.a.push(react);
      if(record.s)notify(record, false);
      return promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function(onRejected){
      return this.then(undefined, onRejected);
    }
  });
}

// export
$def($def.G + $def.W + $def.F * !useNative, {Promise: P});
require('./$.tag')(P, PROMISE);
species(P);
species(Wrapper = require('./$.core')[PROMISE]);

// statics
$def($def.S + $def.F * !useNative, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r){
    return new this(function(res, rej){ rej(r); });
  }
});
$def($def.S + $def.F * (!useNative || testResolve(true)), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x){
    return isPromise(x) && sameConstructor(x.constructor, this)
      ? x : new this(function(res){ res(x); });
  }
});
$def($def.S + $def.F * !(useNative && require('./$.iter-detect')(function(iter){
  P.all(iter)['catch'](function(){});
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable){
    var C      = getConstructor(this)
      , values = [];
    return new C(function(res, rej){
      forOf(iterable, false, values.push, values);
      var remaining = values.length
        , results   = Array(remaining);
      if(remaining)$.each.call(values, function(promise, index){
        C.resolve(promise).then(function(value){
          results[index] = value;
          --remaining || res(results);
        }, rej);
      });
      else res(results);
    });
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable){
    var C = getConstructor(this);
    return new C(function(res, rej){
      forOf(iterable, false, function(promise){
        C.resolve(promise).then(res, rej);
      });
    });
  }
});
},{"./$":41,"./$.a-function":2,"./$.an-object":3,"./$.classof":7,"./$.core":13,"./$.ctx":14,"./$.def":15,"./$.for-of":23,"./$.global":25,"./$.is-object":33,"./$.iter-detect":38,"./$.library":43,"./$.microtask":45,"./$.mix":46,"./$.same":55,"./$.set-proto":56,"./$.species":59,"./$.strict-new":60,"./$.support-desc":66,"./$.tag":67,"./$.uid":74,"./$.wks":76}],132:[function(require,module,exports){
// 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
var $def   = require('./$.def')
  , _apply = Function.apply;

$def($def.S, 'Reflect', {
  apply: function apply(target, thisArgument, argumentsList){
    return _apply.call(target, thisArgument, argumentsList);
  }
});
},{"./$.def":15}],133:[function(require,module,exports){
// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
var $         = require('./$')
  , $def      = require('./$.def')
  , aFunction = require('./$.a-function')
  , anObject  = require('./$.an-object')
  , isObject  = require('./$.is-object')
  , bind      = Function.bind || require('./$.core').Function.prototype.bind;

// MS Edge supports only 2 arguments
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
$def($def.S + $def.F * require('./$.fails')(function(){
  function F(){}
  return !(Reflect.construct(function(){}, [], F) instanceof F);
}), 'Reflect', {
  construct: function construct(Target, args /*, newTarget*/){
    aFunction(Target);
    if(arguments.length < 3){
      // w/o newTarget, optimization for 0-4 arguments
      if(args != undefined)switch(anObject(args).length){
        case 0: return new Target;
        case 1: return new Target(args[0]);
        case 2: return new Target(args[0], args[1]);
        case 3: return new Target(args[0], args[1], args[2]);
        case 4: return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args));
    }
    // with newTarget, not support built-in constructors
    var proto    = aFunction(arguments[2]).prototype
      , instance = $.create(isObject(proto) ? proto : Object.prototype)
      , result   = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});
},{"./$":41,"./$.a-function":2,"./$.an-object":3,"./$.core":13,"./$.def":15,"./$.fails":20,"./$.is-object":33}],134:[function(require,module,exports){
// 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
var $        = require('./$')
  , $def     = require('./$.def')
  , anObject = require('./$.an-object');

// MS Edge has broken Reflect.defineProperty - throwing instead of returning false
$def($def.S + $def.F * require('./$.fails')(function(){
  Reflect.defineProperty($.setDesc({}, 1, {value: 1}), 1, {value: 2});
}), 'Reflect', {
  defineProperty: function defineProperty(target, propertyKey, attributes){
    anObject(target);
    try {
      $.setDesc(target, propertyKey, attributes);
      return true;
    } catch(e){
      return false;
    }
  }
});
},{"./$":41,"./$.an-object":3,"./$.def":15,"./$.fails":20}],135:[function(require,module,exports){
// 26.1.4 Reflect.deleteProperty(target, propertyKey)
var $def     = require('./$.def')
  , getDesc  = require('./$').getDesc
  , anObject = require('./$.an-object');

$def($def.S, 'Reflect', {
  deleteProperty: function deleteProperty(target, propertyKey){
    var desc = getDesc(anObject(target), propertyKey);
    return desc && !desc.configurable ? false : delete target[propertyKey];
  }
});
},{"./$":41,"./$.an-object":3,"./$.def":15}],136:[function(require,module,exports){
'use strict';
// 26.1.5 Reflect.enumerate(target)
var $def     = require('./$.def')
  , anObject = require('./$.an-object');
var Enumerate = function(iterated){
  this._t = anObject(iterated); // target
  this._i = 0;                  // next index
  var keys = this._k = []       // keys
    , key;
  for(key in iterated)keys.push(key);
};
require('./$.iter-create')(Enumerate, 'Object', function(){
  var that = this
    , keys = that._k
    , key;
  do {
    if(that._i >= keys.length)return {value: undefined, done: true};
  } while(!((key = keys[that._i++]) in that._t));
  return {value: key, done: false};
});

$def($def.S, 'Reflect', {
  enumerate: function enumerate(target){
    return new Enumerate(target);
  }
});
},{"./$.an-object":3,"./$.def":15,"./$.iter-create":36}],137:[function(require,module,exports){
// 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
var $        = require('./$')
  , $def     = require('./$.def')
  , anObject = require('./$.an-object');

$def($def.S, 'Reflect', {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey){
    return $.getDesc(anObject(target), propertyKey);
  }
});
},{"./$":41,"./$.an-object":3,"./$.def":15}],138:[function(require,module,exports){
// 26.1.8 Reflect.getPrototypeOf(target)
var $def     = require('./$.def')
  , getProto = require('./$').getProto
  , anObject = require('./$.an-object');

$def($def.S, 'Reflect', {
  getPrototypeOf: function getPrototypeOf(target){
    return getProto(anObject(target));
  }
});
},{"./$":41,"./$.an-object":3,"./$.def":15}],139:[function(require,module,exports){
// 26.1.6 Reflect.get(target, propertyKey [, receiver])
var $        = require('./$')
  , has      = require('./$.has')
  , $def     = require('./$.def')
  , isObject = require('./$.is-object')
  , anObject = require('./$.an-object');

function get(target, propertyKey/*, receiver*/){
  var receiver = arguments.length < 3 ? target : arguments[2]
    , desc, proto;
  if(anObject(target) === receiver)return target[propertyKey];
  if(desc = $.getDesc(target, propertyKey))return has(desc, 'value')
    ? desc.value
    : desc.get !== undefined
      ? desc.get.call(receiver)
      : undefined;
  if(isObject(proto = $.getProto(target)))return get(proto, propertyKey, receiver);
}

$def($def.S, 'Reflect', {get: get});
},{"./$":41,"./$.an-object":3,"./$.def":15,"./$.has":26,"./$.is-object":33}],140:[function(require,module,exports){
// 26.1.9 Reflect.has(target, propertyKey)
var $def = require('./$.def');

$def($def.S, 'Reflect', {
  has: function has(target, propertyKey){
    return propertyKey in target;
  }
});
},{"./$.def":15}],141:[function(require,module,exports){
// 26.1.10 Reflect.isExtensible(target)
var $def          = require('./$.def')
  , anObject      = require('./$.an-object')
  , $isExtensible = Object.isExtensible;

$def($def.S, 'Reflect', {
  isExtensible: function isExtensible(target){
    anObject(target);
    return $isExtensible ? $isExtensible(target) : true;
  }
});
},{"./$.an-object":3,"./$.def":15}],142:[function(require,module,exports){
// 26.1.11 Reflect.ownKeys(target)
var $def = require('./$.def');

$def($def.S, 'Reflect', {ownKeys: require('./$.own-keys')});
},{"./$.def":15,"./$.own-keys":49}],143:[function(require,module,exports){
// 26.1.12 Reflect.preventExtensions(target)
var $def               = require('./$.def')
  , anObject           = require('./$.an-object')
  , $preventExtensions = Object.preventExtensions;

$def($def.S, 'Reflect', {
  preventExtensions: function preventExtensions(target){
    anObject(target);
    try {
      if($preventExtensions)$preventExtensions(target);
      return true;
    } catch(e){
      return false;
    }
  }
});
},{"./$.an-object":3,"./$.def":15}],144:[function(require,module,exports){
// 26.1.14 Reflect.setPrototypeOf(target, proto)
var $def     = require('./$.def')
  , setProto = require('./$.set-proto');

if(setProto)$def($def.S, 'Reflect', {
  setPrototypeOf: function setPrototypeOf(target, proto){
    setProto.check(target, proto);
    try {
      setProto.set(target, proto);
      return true;
    } catch(e){
      return false;
    }
  }
});
},{"./$.def":15,"./$.set-proto":56}],145:[function(require,module,exports){
// 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
var $          = require('./$')
  , has        = require('./$.has')
  , $def       = require('./$.def')
  , createDesc = require('./$.property-desc')
  , anObject   = require('./$.an-object')
  , isObject   = require('./$.is-object');

function set(target, propertyKey, V/*, receiver*/){
  var receiver = arguments.length < 4 ? target : arguments[3]
    , ownDesc  = $.getDesc(anObject(target), propertyKey)
    , existingDescriptor, proto;
  if(!ownDesc){
    if(isObject(proto = $.getProto(target))){
      return set(proto, propertyKey, V, receiver);
    }
    ownDesc = createDesc(0);
  }
  if(has(ownDesc, 'value')){
    if(ownDesc.writable === false || !isObject(receiver))return false;
    existingDescriptor = $.getDesc(receiver, propertyKey) || createDesc(0);
    existingDescriptor.value = V;
    $.setDesc(receiver, propertyKey, existingDescriptor);
    return true;
  }
  return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
}

$def($def.S, 'Reflect', {set: set});
},{"./$":41,"./$.an-object":3,"./$.def":15,"./$.has":26,"./$.is-object":33,"./$.property-desc":52}],146:[function(require,module,exports){
var $       = require('./$')
  , global  = require('./$.global')
  , cof     = require('./$.cof')
  , $flags  = require('./$.flags')
  , $RegExp = global.RegExp
  , Base    = $RegExp
  , proto   = $RegExp.prototype
  , re      = /a/g
  // "new" creates a new object
  , CORRECT_NEW = new $RegExp(re) !== re
  // RegExp allows a regex with flags as the pattern
  , ALLOWS_RE_WITH_FLAGS = function(){
    try {
      return $RegExp(re, 'i') == '/a/i';
    } catch(e){ /* empty */ }
  }();

if(require('./$.support-desc')){
  if(!CORRECT_NEW || !ALLOWS_RE_WITH_FLAGS){
    $RegExp = function RegExp(pattern, flags){
      var patternIsRegExp  = cof(pattern) == 'RegExp'
        , flagsIsUndefined = flags === undefined;
      if(!(this instanceof $RegExp) && patternIsRegExp && flagsIsUndefined)return pattern;
      return CORRECT_NEW
        ? new Base(patternIsRegExp && !flagsIsUndefined ? pattern.source : pattern, flags)
        : new Base(patternIsRegExp ? pattern.source : pattern
          , patternIsRegExp && flagsIsUndefined ? $flags.call(pattern) : flags);
    };
    $.each.call($.getNames(Base), function(key){
      key in $RegExp || $.setDesc($RegExp, key, {
        configurable: true,
        get: function(){ return Base[key]; },
        set: function(it){ Base[key] = it; }
      });
    });
    proto.constructor = $RegExp;
    $RegExp.prototype = proto;
    require('./$.redef')(global, 'RegExp', $RegExp);
  }
}

require('./$.species')($RegExp);
},{"./$":41,"./$.cof":8,"./$.flags":22,"./$.global":25,"./$.redef":53,"./$.species":59,"./$.support-desc":66}],147:[function(require,module,exports){
// 21.2.5.3 get RegExp.prototype.flags()
var $ = require('./$');
if(require('./$.support-desc') && /./g.flags != 'g')$.setDesc(RegExp.prototype, 'flags', {
  configurable: true,
  get: require('./$.flags')
});
},{"./$":41,"./$.flags":22,"./$.support-desc":66}],148:[function(require,module,exports){
// @@match logic
require('./$.fix-re-wks')('match', 1, function(defined, MATCH){
  // 21.1.3.11 String.prototype.match(regexp)
  return function match(regexp){
    'use strict';
    var O  = defined(this)
      , fn = regexp == undefined ? undefined : regexp[MATCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
  };
});
},{"./$.fix-re-wks":21}],149:[function(require,module,exports){
// @@replace logic
require('./$.fix-re-wks')('replace', 2, function(defined, REPLACE, $replace){
  // 21.1.3.14 String.prototype.replace(searchValue, replaceValue)
  return function replace(searchValue, replaceValue){
    'use strict';
    var O  = defined(this)
      , fn = searchValue == undefined ? undefined : searchValue[REPLACE];
    return fn !== undefined
      ? fn.call(searchValue, O, replaceValue)
      : $replace.call(String(O), searchValue, replaceValue);
  };
});
},{"./$.fix-re-wks":21}],150:[function(require,module,exports){
// @@search logic
require('./$.fix-re-wks')('search', 1, function(defined, SEARCH){
  // 21.1.3.15 String.prototype.search(regexp)
  return function search(regexp){
    'use strict';
    var O  = defined(this)
      , fn = regexp == undefined ? undefined : regexp[SEARCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
  };
});
},{"./$.fix-re-wks":21}],151:[function(require,module,exports){
// @@split logic
require('./$.fix-re-wks')('split', 2, function(defined, SPLIT, $split){
  // 21.1.3.17 String.prototype.split(separator, limit)
  return function split(separator, limit){
    'use strict';
    var O  = defined(this)
      , fn = separator == undefined ? undefined : separator[SPLIT];
    return fn !== undefined
      ? fn.call(separator, O, limit)
      : $split.call(String(O), separator, limit);
  };
});
},{"./$.fix-re-wks":21}],152:[function(require,module,exports){
'use strict';
var strong = require('./$.collection-strong');

// 23.2 Set Objects
require('./$.collection')('Set', function(get){
  return function Set(){ return get(this, arguments[0]); };
}, {
  // 23.2.3.1 Set.prototype.add(value)
  add: function add(value){
    return strong.def(this, value = value === 0 ? 0 : value, value);
  }
}, strong);
},{"./$.collection":12,"./$.collection-strong":9}],153:[function(require,module,exports){
'use strict';
var $def = require('./$.def')
  , $at  = require('./$.string-at')(false);
$def($def.P, 'String', {
  // 21.1.3.3 String.prototype.codePointAt(pos)
  codePointAt: function codePointAt(pos){
    return $at(this, pos);
  }
});
},{"./$.def":15,"./$.string-at":61}],154:[function(require,module,exports){
'use strict';
var $def     = require('./$.def')
  , toLength = require('./$.to-length')
  , context  = require('./$.string-context');

// should throw error on regex
$def($def.P + $def.F * !require('./$.fails')(function(){ 'q'.endsWith(/./); }), 'String', {
  // 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])
  endsWith: function endsWith(searchString /*, endPosition = @length */){
    var that = context(this, searchString, 'endsWith')
      , endPosition = arguments[1]
      , len    = toLength(that.length)
      , end    = endPosition === undefined ? len : Math.min(toLength(endPosition), len)
      , search = String(searchString);
    return that.slice(end - search.length, end) === search;
  }
});
},{"./$.def":15,"./$.fails":20,"./$.string-context":62,"./$.to-length":72}],155:[function(require,module,exports){
var $def    = require('./$.def')
  , toIndex = require('./$.to-index')
  , fromCharCode = String.fromCharCode
  , $fromCodePoint = String.fromCodePoint;

// length should be 1, old FF problem
$def($def.S + $def.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
  // 21.1.2.2 String.fromCodePoint(...codePoints)
  fromCodePoint: function fromCodePoint(x){ // eslint-disable-line no-unused-vars
    var res = []
      , len = arguments.length
      , i   = 0
      , code;
    while(len > i){
      code = +arguments[i++];
      if(toIndex(code, 0x10ffff) !== code)throw RangeError(code + ' is not a valid code point');
      res.push(code < 0x10000
        ? fromCharCode(code)
        : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00)
      );
    } return res.join('');
  }
});
},{"./$.def":15,"./$.to-index":69}],156:[function(require,module,exports){
'use strict';
var $def    = require('./$.def')
  , context = require('./$.string-context');

$def($def.P, 'String', {
  // 21.1.3.7 String.prototype.includes(searchString, position = 0)
  includes: function includes(searchString /*, position = 0 */){
    return !!~context(this, searchString, 'includes').indexOf(searchString, arguments[1]);
  }
});
},{"./$.def":15,"./$.string-context":62}],157:[function(require,module,exports){
'use strict';
var $at  = require('./$.string-at')(true);

// 21.1.3.27 String.prototype[@@iterator]()
require('./$.iter-define')(String, 'String', function(iterated){
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function(){
  var O     = this._t
    , index = this._i
    , point;
  if(index >= O.length)return {value: undefined, done: true};
  point = $at(O, index);
  this._i += point.length;
  return {value: point, done: false};
});
},{"./$.iter-define":37,"./$.string-at":61}],158:[function(require,module,exports){
var $def      = require('./$.def')
  , toIObject = require('./$.to-iobject')
  , toLength  = require('./$.to-length');

$def($def.S, 'String', {
  // 21.1.2.4 String.raw(callSite, ...substitutions)
  raw: function raw(callSite){
    var tpl = toIObject(callSite.raw)
      , len = toLength(tpl.length)
      , sln = arguments.length
      , res = []
      , i   = 0;
    while(len > i){
      res.push(String(tpl[i++]));
      if(i < sln)res.push(String(arguments[i]));
    } return res.join('');
  }
});
},{"./$.def":15,"./$.to-iobject":71,"./$.to-length":72}],159:[function(require,module,exports){
var $def = require('./$.def');

$def($def.P, 'String', {
  // 21.1.3.13 String.prototype.repeat(count)
  repeat: require('./$.string-repeat')
});
},{"./$.def":15,"./$.string-repeat":64}],160:[function(require,module,exports){
'use strict';
var $def     = require('./$.def')
  , toLength = require('./$.to-length')
  , context  = require('./$.string-context');

// should throw error on regex
$def($def.P + $def.F * !require('./$.fails')(function(){ 'q'.startsWith(/./); }), 'String', {
  // 21.1.3.18 String.prototype.startsWith(searchString [, position ])
  startsWith: function startsWith(searchString /*, position = 0 */){
    var that   = context(this, searchString, 'startsWith')
      , index  = toLength(Math.min(arguments[1], that.length))
      , search = String(searchString);
    return that.slice(index, index + search.length) === search;
  }
});
},{"./$.def":15,"./$.fails":20,"./$.string-context":62,"./$.to-length":72}],161:[function(require,module,exports){
'use strict';
// 21.1.3.25 String.prototype.trim()
require('./$.string-trim')('trim', function($trim){
  return function trim(){
    return $trim(this, 3);
  };
});
},{"./$.string-trim":65}],162:[function(require,module,exports){
'use strict';
// ECMAScript 6 symbols shim
var $              = require('./$')
  , global         = require('./$.global')
  , has            = require('./$.has')
  , SUPPORT_DESC   = require('./$.support-desc')
  , $def           = require('./$.def')
  , $redef         = require('./$.redef')
  , shared         = require('./$.shared')
  , setTag         = require('./$.tag')
  , uid            = require('./$.uid')
  , wks            = require('./$.wks')
  , keyOf          = require('./$.keyof')
  , $names         = require('./$.get-names')
  , enumKeys       = require('./$.enum-keys')
  , anObject       = require('./$.an-object')
  , toIObject      = require('./$.to-iobject')
  , createDesc     = require('./$.property-desc')
  , getDesc        = $.getDesc
  , setDesc        = $.setDesc
  , _create        = $.create
  , getNames       = $names.get
  , $Symbol        = global.Symbol
  , setter         = false
  , HIDDEN         = wks('_hidden')
  , isEnum         = $.isEnum
  , SymbolRegistry = shared('symbol-registry')
  , AllSymbols     = shared('symbols')
  , useNative      = typeof $Symbol == 'function'
  , ObjectProto    = Object.prototype;

var setSymbolDesc = SUPPORT_DESC ? function(){ // fallback for old Android
  try {
    return _create(setDesc({}, HIDDEN, {
      get: function(){
        return setDesc(this, HIDDEN, {value: false})[HIDDEN];
      }
    }))[HIDDEN] || setDesc;
  } catch(e){
    return function(it, key, D){
      var protoDesc = getDesc(ObjectProto, key);
      if(protoDesc)delete ObjectProto[key];
      setDesc(it, key, D);
      if(protoDesc && it !== ObjectProto)setDesc(ObjectProto, key, protoDesc);
    };
  }
}() : setDesc;

var wrap = function(tag){
  var sym = AllSymbols[tag] = _create($Symbol.prototype);
  sym._k = tag;
  SUPPORT_DESC && setter && setSymbolDesc(ObjectProto, tag, {
    configurable: true,
    set: function(value){
      if(has(this, HIDDEN) && has(this[HIDDEN], tag))this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    }
  });
  return sym;
};

var $defineProperty = function defineProperty(it, key, D){
  if(D && has(AllSymbols, key)){
    if(!D.enumerable){
      if(!has(it, HIDDEN))setDesc(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if(has(it, HIDDEN) && it[HIDDEN][key])it[HIDDEN][key] = false;
      D = _create(D, {enumerable: createDesc(0, false)});
    } return setSymbolDesc(it, key, D);
  } return setDesc(it, key, D);
};
var $defineProperties = function defineProperties(it, P){
  anObject(it);
  var keys = enumKeys(P = toIObject(P))
    , i    = 0
    , l = keys.length
    , key;
  while(l > i)$defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P){
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key){
  var E = isEnum.call(this, key);
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key]
    ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key){
  var D = getDesc(it = toIObject(it), key);
  if(D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key]))D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it){
  var names  = getNames(toIObject(it))
    , result = []
    , i      = 0
    , key;
  while(names.length > i)if(!has(AllSymbols, key = names[i++]) && key != HIDDEN)result.push(key);
  return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it){
  var names  = getNames(toIObject(it))
    , result = []
    , i      = 0
    , key;
  while(names.length > i)if(has(AllSymbols, key = names[i++]))result.push(AllSymbols[key]);
  return result;
};

// 19.4.1.1 Symbol([description])
if(!useNative){
  $Symbol = function Symbol(){
    if(this instanceof $Symbol)throw TypeError('Symbol is not a constructor');
    return wrap(uid(arguments[0]));
  };
  $redef($Symbol.prototype, 'toString', function toString(){
    return this._k;
  });

  $.create     = $create;
  $.isEnum     = $propertyIsEnumerable;
  $.getDesc    = $getOwnPropertyDescriptor;
  $.setDesc    = $defineProperty;
  $.setDescs   = $defineProperties;
  $.getNames   = $names.get = $getOwnPropertyNames;
  $.getSymbols = $getOwnPropertySymbols;

  if(SUPPORT_DESC && !require('./$.library')){
    $redef(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }
}

// MS Edge converts symbols to JSON as '{}'
if(!useNative || require('./$.fails')(function(){
  return JSON.stringify([$Symbol()]) != '[null]';
}))$redef($Symbol.prototype, 'toJSON', function toJSON(){ /* return undefined */ });

var symbolStatics = {
  // 19.4.2.1 Symbol.for(key)
  'for': function(key){
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(key){
    return keyOf(SymbolRegistry, key);
  },
  useSetter: function(){ setter = true; },
  useSimple: function(){ setter = false; }
};
// 19.4.2.2 Symbol.hasInstance
// 19.4.2.3 Symbol.isConcatSpreadable
// 19.4.2.4 Symbol.iterator
// 19.4.2.6 Symbol.match
// 19.4.2.8 Symbol.replace
// 19.4.2.9 Symbol.search
// 19.4.2.10 Symbol.species
// 19.4.2.11 Symbol.split
// 19.4.2.12 Symbol.toPrimitive
// 19.4.2.13 Symbol.toStringTag
// 19.4.2.14 Symbol.unscopables
$.each.call((
    'hasInstance,isConcatSpreadable,iterator,match,replace,search,' +
    'species,split,toPrimitive,toStringTag,unscopables'
  ).split(','), function(it){
    var sym = wks(it);
    symbolStatics[it] = useNative ? sym : wrap(sym);
  }
);

setter = true;

$def($def.G + $def.W, {Symbol: $Symbol});

$def($def.S, 'Symbol', symbolStatics);

$def($def.S + $def.F * !useNative, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 19.4.3.5 Symbol.prototype[@@toStringTag]
setTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setTag(global.JSON, 'JSON', true);
},{"./$":41,"./$.an-object":3,"./$.def":15,"./$.enum-keys":18,"./$.fails":20,"./$.get-names":24,"./$.global":25,"./$.has":26,"./$.keyof":42,"./$.library":43,"./$.property-desc":52,"./$.redef":53,"./$.shared":57,"./$.support-desc":66,"./$.tag":67,"./$.to-iobject":71,"./$.uid":74,"./$.wks":76}],163:[function(require,module,exports){
'use strict';
var $            = require('./$')
  , weak         = require('./$.collection-weak')
  , isObject     = require('./$.is-object')
  , has          = require('./$.has')
  , frozenStore  = weak.frozenStore
  , WEAK         = weak.WEAK
  , isExtensible = Object.isExtensible || isObject
  , tmp          = {};

// 23.3 WeakMap Objects
var $WeakMap = require('./$.collection')('WeakMap', function(get){
  return function WeakMap(){ return get(this, arguments[0]); };
}, {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key){
    if(isObject(key)){
      if(!isExtensible(key))return frozenStore(this).get(key);
      if(has(key, WEAK))return key[WEAK][this._i];
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value){
    return weak.def(this, key, value);
  }
}, weak, true, true);

// IE11 WeakMap frozen keys fix
if(new $WeakMap().set((Object.freeze || Object)(tmp), 7).get(tmp) != 7){
  $.each.call(['delete', 'has', 'get', 'set'], function(key){
    var proto  = $WeakMap.prototype
      , method = proto[key];
    require('./$.redef')(proto, key, function(a, b){
      // store frozen objects on leaky map
      if(isObject(a) && !isExtensible(a)){
        var result = frozenStore(this)[key](a, b);
        return key == 'set' ? this : result;
      // store all the rest on native weakmap
      } return method.call(this, a, b);
    });
  });
}
},{"./$":41,"./$.collection":12,"./$.collection-weak":11,"./$.has":26,"./$.is-object":33,"./$.redef":53}],164:[function(require,module,exports){
'use strict';
var weak = require('./$.collection-weak');

// 23.4 WeakSet Objects
require('./$.collection')('WeakSet', function(get){
  return function WeakSet(){ return get(this, arguments[0]); };
}, {
  // 23.4.3.1 WeakSet.prototype.add(value)
  add: function add(value){
    return weak.def(this, value, true);
  }
}, weak, false, true);
},{"./$.collection":12,"./$.collection-weak":11}],165:[function(require,module,exports){
'use strict';
var $def      = require('./$.def')
  , $includes = require('./$.array-includes')(true);
$def($def.P, 'Array', {
  // https://github.com/domenic/Array.prototype.includes
  includes: function includes(el /*, fromIndex = 0 */){
    return $includes(this, el, arguments[1]);
  }
});
require('./$.unscope')('includes');
},{"./$.array-includes":4,"./$.def":15,"./$.unscope":75}],166:[function(require,module,exports){
// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $def  = require('./$.def');

$def($def.P, 'Map', {toJSON: require('./$.collection-to-json')('Map')});
},{"./$.collection-to-json":10,"./$.def":15}],167:[function(require,module,exports){
// http://goo.gl/XkBrjD
var $def     = require('./$.def')
  , $entries = require('./$.object-to-array')(true);

$def($def.S, 'Object', {
  entries: function entries(it){
    return $entries(it);
  }
});
},{"./$.def":15,"./$.object-to-array":48}],168:[function(require,module,exports){
// https://gist.github.com/WebReflection/9353781
var $          = require('./$')
  , $def       = require('./$.def')
  , ownKeys    = require('./$.own-keys')
  , toIObject  = require('./$.to-iobject')
  , createDesc = require('./$.property-desc');

$def($def.S, 'Object', {
  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object){
    var O       = toIObject(object)
      , setDesc = $.setDesc
      , getDesc = $.getDesc
      , keys    = ownKeys(O)
      , result  = {}
      , i       = 0
      , key, D;
    while(keys.length > i){
      D = getDesc(O, key = keys[i++]);
      if(key in result)setDesc(result, key, createDesc(0, D));
      else result[key] = D;
    } return result;
  }
});
},{"./$":41,"./$.def":15,"./$.own-keys":49,"./$.property-desc":52,"./$.to-iobject":71}],169:[function(require,module,exports){
// http://goo.gl/XkBrjD
var $def    = require('./$.def')
  , $values = require('./$.object-to-array')(false);

$def($def.S, 'Object', {
  values: function values(it){
    return $values(it);
  }
});
},{"./$.def":15,"./$.object-to-array":48}],170:[function(require,module,exports){
// https://github.com/benjamingr/RexExp.escape
var $def = require('./$.def')
  , $re  = require('./$.replacer')(/[\\^$*+?.()|[\]{}]/g, '\\$&');
$def($def.S, 'RegExp', {escape: function escape(it){ return $re(it); }});

},{"./$.def":15,"./$.replacer":54}],171:[function(require,module,exports){
// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $def  = require('./$.def');

$def($def.P, 'Set', {toJSON: require('./$.collection-to-json')('Set')});
},{"./$.collection-to-json":10,"./$.def":15}],172:[function(require,module,exports){
// https://github.com/mathiasbynens/String.prototype.at
'use strict';
var $def = require('./$.def')
  , $at  = require('./$.string-at')(true);
$def($def.P, 'String', {
  at: function at(pos){
    return $at(this, pos);
  }
});
},{"./$.def":15,"./$.string-at":61}],173:[function(require,module,exports){
'use strict';
var $def = require('./$.def')
  , $pad = require('./$.string-pad');
$def($def.P, 'String', {
  padLeft: function padLeft(maxLength /*, fillString = ' ' */){
    return $pad(this, maxLength, arguments[1], true);
  }
});
},{"./$.def":15,"./$.string-pad":63}],174:[function(require,module,exports){
'use strict';
var $def = require('./$.def')
  , $pad = require('./$.string-pad');
$def($def.P, 'String', {
  padRight: function padRight(maxLength /*, fillString = ' ' */){
    return $pad(this, maxLength, arguments[1], false);
  }
});
},{"./$.def":15,"./$.string-pad":63}],175:[function(require,module,exports){
'use strict';
// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
require('./$.string-trim')('trimLeft', function($trim){
  return function trimLeft(){
    return $trim(this, 1);
  };
});
},{"./$.string-trim":65}],176:[function(require,module,exports){
'use strict';
// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
require('./$.string-trim')('trimRight', function($trim){
  return function trimRight(){
    return $trim(this, 2);
  };
});
},{"./$.string-trim":65}],177:[function(require,module,exports){
// JavaScript 1.6 / Strawman array statics shim
var $       = require('./$')
  , $def    = require('./$.def')
  , $Array  = require('./$.core').Array || Array
  , statics = {};
var setStatics = function(keys, length){
  $.each.call(keys.split(','), function(key){
    if(length == undefined && key in $Array)statics[key] = $Array[key];
    else if(key in [])statics[key] = require('./$.ctx')(Function.call, [][key], length);
  });
};
setStatics('pop,reverse,shift,keys,values,entries', 1);
setStatics('indexOf,every,some,forEach,map,filter,find,findIndex,includes', 3);
setStatics('join,slice,concat,push,splice,unshift,sort,lastIndexOf,' +
           'reduce,reduceRight,copyWithin,fill');
$def($def.S, 'Array', statics);
},{"./$":41,"./$.core":13,"./$.ctx":14,"./$.def":15}],178:[function(require,module,exports){
require('./es6.array.iterator');
var global      = require('./$.global')
  , hide        = require('./$.hide')
  , Iterators   = require('./$.iterators')
  , ITERATOR    = require('./$.wks')('iterator')
  , NL          = global.NodeList
  , HTC         = global.HTMLCollection
  , NLProto     = NL && NL.prototype
  , HTCProto    = HTC && HTC.prototype
  , ArrayValues = Iterators.NodeList = Iterators.HTMLCollection = Iterators.Array;
if(NL && !(ITERATOR in NLProto))hide(NLProto, ITERATOR, ArrayValues);
if(HTC && !(ITERATOR in HTCProto))hide(HTCProto, ITERATOR, ArrayValues);
},{"./$.global":25,"./$.hide":27,"./$.iterators":40,"./$.wks":76,"./es6.array.iterator":84}],179:[function(require,module,exports){
var $def  = require('./$.def')
  , $task = require('./$.task');
$def($def.G + $def.B, {
  setImmediate:   $task.set,
  clearImmediate: $task.clear
});
},{"./$.def":15,"./$.task":68}],180:[function(require,module,exports){
// ie9- setTimeout & setInterval additional parameters fix
var global     = require('./$.global')
  , $def       = require('./$.def')
  , invoke     = require('./$.invoke')
  , partial    = require('./$.partial')
  , navigator  = global.navigator
  , MSIE       = !!navigator && /MSIE .\./.test(navigator.userAgent); // <- dirty ie9- check
var wrap = function(set){
  return MSIE ? function(fn, time /*, ...args */){
    return set(invoke(
      partial,
      [].slice.call(arguments, 2),
      typeof fn == 'function' ? fn : Function(fn)
    ), time);
  } : set;
};
$def($def.G + $def.B + $def.F * MSIE, {
  setTimeout:  wrap(global.setTimeout),
  setInterval: wrap(global.setInterval)
});
},{"./$.def":15,"./$.global":25,"./$.invoke":29,"./$.partial":50}],181:[function(require,module,exports){
require('./modules/es5');
require('./modules/es6.symbol');
require('./modules/es6.object.assign');
require('./modules/es6.object.is');
require('./modules/es6.object.set-prototype-of');
require('./modules/es6.object.to-string');
require('./modules/es6.object.freeze');
require('./modules/es6.object.seal');
require('./modules/es6.object.prevent-extensions');
require('./modules/es6.object.is-frozen');
require('./modules/es6.object.is-sealed');
require('./modules/es6.object.is-extensible');
require('./modules/es6.object.get-own-property-descriptor');
require('./modules/es6.object.get-prototype-of');
require('./modules/es6.object.keys');
require('./modules/es6.object.get-own-property-names');
require('./modules/es6.function.name');
require('./modules/es6.function.has-instance');
require('./modules/es6.number.constructor');
require('./modules/es6.number.epsilon');
require('./modules/es6.number.is-finite');
require('./modules/es6.number.is-integer');
require('./modules/es6.number.is-nan');
require('./modules/es6.number.is-safe-integer');
require('./modules/es6.number.max-safe-integer');
require('./modules/es6.number.min-safe-integer');
require('./modules/es6.number.parse-float');
require('./modules/es6.number.parse-int');
require('./modules/es6.math.acosh');
require('./modules/es6.math.asinh');
require('./modules/es6.math.atanh');
require('./modules/es6.math.cbrt');
require('./modules/es6.math.clz32');
require('./modules/es6.math.cosh');
require('./modules/es6.math.expm1');
require('./modules/es6.math.fround');
require('./modules/es6.math.hypot');
require('./modules/es6.math.imul');
require('./modules/es6.math.log10');
require('./modules/es6.math.log1p');
require('./modules/es6.math.log2');
require('./modules/es6.math.sign');
require('./modules/es6.math.sinh');
require('./modules/es6.math.tanh');
require('./modules/es6.math.trunc');
require('./modules/es6.string.from-code-point');
require('./modules/es6.string.raw');
require('./modules/es6.string.trim');
require('./modules/es6.string.iterator');
require('./modules/es6.string.code-point-at');
require('./modules/es6.string.ends-with');
require('./modules/es6.string.includes');
require('./modules/es6.string.repeat');
require('./modules/es6.string.starts-with');
require('./modules/es6.array.from');
require('./modules/es6.array.of');
require('./modules/es6.array.iterator');
require('./modules/es6.array.species');
require('./modules/es6.array.copy-within');
require('./modules/es6.array.fill');
require('./modules/es6.array.find');
require('./modules/es6.array.find-index');
require('./modules/es6.regexp.constructor');
require('./modules/es6.regexp.flags');
require('./modules/es6.regexp.match');
require('./modules/es6.regexp.replace');
require('./modules/es6.regexp.search');
require('./modules/es6.regexp.split');
require('./modules/es6.promise');
require('./modules/es6.map');
require('./modules/es6.set');
require('./modules/es6.weak-map');
require('./modules/es6.weak-set');
require('./modules/es6.reflect.apply');
require('./modules/es6.reflect.construct');
require('./modules/es6.reflect.define-property');
require('./modules/es6.reflect.delete-property');
require('./modules/es6.reflect.enumerate');
require('./modules/es6.reflect.get');
require('./modules/es6.reflect.get-own-property-descriptor');
require('./modules/es6.reflect.get-prototype-of');
require('./modules/es6.reflect.has');
require('./modules/es6.reflect.is-extensible');
require('./modules/es6.reflect.own-keys');
require('./modules/es6.reflect.prevent-extensions');
require('./modules/es6.reflect.set');
require('./modules/es6.reflect.set-prototype-of');
require('./modules/es7.array.includes');
require('./modules/es7.string.at');
require('./modules/es7.string.pad-left');
require('./modules/es7.string.pad-right');
require('./modules/es7.string.trim-left');
require('./modules/es7.string.trim-right');
require('./modules/es7.regexp.escape');
require('./modules/es7.object.get-own-property-descriptors');
require('./modules/es7.object.values');
require('./modules/es7.object.entries');
require('./modules/es7.map.to-json');
require('./modules/es7.set.to-json');
require('./modules/js.array.statics');
require('./modules/web.timers');
require('./modules/web.immediate');
require('./modules/web.dom.iterable');
module.exports = require('./modules/$.core');
},{"./modules/$.core":13,"./modules/es5":78,"./modules/es6.array.copy-within":79,"./modules/es6.array.fill":80,"./modules/es6.array.find":82,"./modules/es6.array.find-index":81,"./modules/es6.array.from":83,"./modules/es6.array.iterator":84,"./modules/es6.array.of":85,"./modules/es6.array.species":86,"./modules/es6.function.has-instance":87,"./modules/es6.function.name":88,"./modules/es6.map":89,"./modules/es6.math.acosh":90,"./modules/es6.math.asinh":91,"./modules/es6.math.atanh":92,"./modules/es6.math.cbrt":93,"./modules/es6.math.clz32":94,"./modules/es6.math.cosh":95,"./modules/es6.math.expm1":96,"./modules/es6.math.fround":97,"./modules/es6.math.hypot":98,"./modules/es6.math.imul":99,"./modules/es6.math.log10":100,"./modules/es6.math.log1p":101,"./modules/es6.math.log2":102,"./modules/es6.math.sign":103,"./modules/es6.math.sinh":104,"./modules/es6.math.tanh":105,"./modules/es6.math.trunc":106,"./modules/es6.number.constructor":107,"./modules/es6.number.epsilon":108,"./modules/es6.number.is-finite":109,"./modules/es6.number.is-integer":110,"./modules/es6.number.is-nan":111,"./modules/es6.number.is-safe-integer":112,"./modules/es6.number.max-safe-integer":113,"./modules/es6.number.min-safe-integer":114,"./modules/es6.number.parse-float":115,"./modules/es6.number.parse-int":116,"./modules/es6.object.assign":117,"./modules/es6.object.freeze":118,"./modules/es6.object.get-own-property-descriptor":119,"./modules/es6.object.get-own-property-names":120,"./modules/es6.object.get-prototype-of":121,"./modules/es6.object.is":125,"./modules/es6.object.is-extensible":122,"./modules/es6.object.is-frozen":123,"./modules/es6.object.is-sealed":124,"./modules/es6.object.keys":126,"./modules/es6.object.prevent-extensions":127,"./modules/es6.object.seal":128,"./modules/es6.object.set-prototype-of":129,"./modules/es6.object.to-string":130,"./modules/es6.promise":131,"./modules/es6.reflect.apply":132,"./modules/es6.reflect.construct":133,"./modules/es6.reflect.define-property":134,"./modules/es6.reflect.delete-property":135,"./modules/es6.reflect.enumerate":136,"./modules/es6.reflect.get":139,"./modules/es6.reflect.get-own-property-descriptor":137,"./modules/es6.reflect.get-prototype-of":138,"./modules/es6.reflect.has":140,"./modules/es6.reflect.is-extensible":141,"./modules/es6.reflect.own-keys":142,"./modules/es6.reflect.prevent-extensions":143,"./modules/es6.reflect.set":145,"./modules/es6.reflect.set-prototype-of":144,"./modules/es6.regexp.constructor":146,"./modules/es6.regexp.flags":147,"./modules/es6.regexp.match":148,"./modules/es6.regexp.replace":149,"./modules/es6.regexp.search":150,"./modules/es6.regexp.split":151,"./modules/es6.set":152,"./modules/es6.string.code-point-at":153,"./modules/es6.string.ends-with":154,"./modules/es6.string.from-code-point":155,"./modules/es6.string.includes":156,"./modules/es6.string.iterator":157,"./modules/es6.string.raw":158,"./modules/es6.string.repeat":159,"./modules/es6.string.starts-with":160,"./modules/es6.string.trim":161,"./modules/es6.symbol":162,"./modules/es6.weak-map":163,"./modules/es6.weak-set":164,"./modules/es7.array.includes":165,"./modules/es7.map.to-json":166,"./modules/es7.object.entries":167,"./modules/es7.object.get-own-property-descriptors":168,"./modules/es7.object.values":169,"./modules/es7.regexp.escape":170,"./modules/es7.set.to-json":171,"./modules/es7.string.at":172,"./modules/es7.string.pad-left":173,"./modules/es7.string.pad-right":174,"./modules/es7.string.trim-left":175,"./modules/es7.string.trim-right":176,"./modules/js.array.statics":177,"./modules/web.dom.iterable":178,"./modules/web.immediate":179,"./modules/web.timers":180}],182:[function(require,module,exports){
(function (process,global){
/**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
 * additional grant of patent rights can be found in the PATENTS file in
 * the same directory.
 */

!(function(global) {
  "use strict";

  var hasOwn = Object.prototype.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var iteratorSymbol =
    typeof Symbol === "function" && Symbol.iterator || "@@iterator";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided, then outerFn.prototype instanceof Generator.
    var generator = Object.create((outerFn || Generator).prototype);

    generator._invoke = makeInvokeMethod(
      innerFn, self || null,
      new Context(tryLocsList || [])
    );

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype;
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    genFun.__proto__ = GeneratorFunctionPrototype;
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `value instanceof AwaitArgument` to determine if the yielded value is
  // meant to be awaited. Some may consider the name of this method too
  // cutesy, but they are curmudgeons.
  runtime.awrap = function(arg) {
    return new AwaitArgument(arg);
  };

  function AwaitArgument(arg) {
    this.arg = arg;
  }

  function AsyncIterator(generator) {
    // This invoke function is written in a style that assumes some
    // calling function (or Promise) will handle exceptions.
    function invoke(method, arg) {
      var result = generator[method](arg);
      var value = result.value;
      return value instanceof AwaitArgument
        ? Promise.resolve(value.arg).then(invokeNext, invokeThrow)
        : Promise.resolve(value).then(function(unwrapped) {
            // When a yielded Promise is resolved, its final value becomes
            // the .value of the Promise<{value,done}> result for the
            // current iteration. If the Promise is rejected, however, the
            // result for this iteration will be rejected with the same
            // reason. Note that rejections of yielded Promises are not
            // thrown back into the generator function, as is the case
            // when an awaited Promise is rejected. This difference in
            // behavior between yield and await is important, because it
            // allows the consumer to decide what to do with the yielded
            // rejection (swallow it and continue, manually .throw it back
            // into the generator, abandon iteration, whatever). With
            // await, by contrast, there is no opportunity to examine the
            // rejection reason outside the generator function, so the
            // only option is to throw it from the await expression, and
            // let the generator function handle the exception.
            result.value = unwrapped;
            return result;
          });
    }

    if (typeof process === "object" && process.domain) {
      invoke = process.domain.bind(invoke);
    }

    var invokeNext = invoke.bind(generator, "next");
    var invokeThrow = invoke.bind(generator, "throw");
    var invokeReturn = invoke.bind(generator, "return");
    var previousPromise;

    function enqueue(method, arg) {
      var enqueueResult =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(function() {
          return invoke(method, arg);
        }) : new Promise(function(resolve) {
          resolve(invoke(method, arg));
        });

      // Avoid propagating enqueueResult failures to Promises returned by
      // later invocations of the iterator.
      previousPromise = enqueueResult["catch"](function(ignored){});

      return enqueueResult;
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          if (method === "return" ||
              (method === "throw" && delegate.iterator[method] === undefined)) {
            // A return or throw (when the delegate iterator has no throw
            // method) always terminates the yield* loop.
            context.delegate = null;

            // If the delegate iterator has a return method, give it a
            // chance to clean up.
            var returnMethod = delegate.iterator["return"];
            if (returnMethod) {
              var record = tryCatch(returnMethod, delegate.iterator, arg);
              if (record.type === "throw") {
                // If the return method threw an exception, let that
                // exception prevail over the original return or throw.
                method = "throw";
                arg = record.arg;
                continue;
              }
            }

            if (method === "return") {
              // Continue with the outer return, now that the delegate
              // iterator has been terminated.
              continue;
            }
          }

          var record = tryCatch(
            delegate.iterator[method],
            delegate.iterator,
            arg
          );

          if (record.type === "throw") {
            context.delegate = null;

            // Like returning generator.throw(uncaught), but without the
            // overhead of an extra function call.
            method = "throw";
            arg = record.arg;
            continue;
          }

          // Delegate generator ran and handled its own exceptions so
          // regardless of what the method was, we continue as if it is
          // "next" with an undefined arg.
          method = "next";
          arg = undefined;

          var info = record.arg;
          if (info.done) {
            context[delegate.resultName] = info.value;
            context.next = delegate.nextLoc;
          } else {
            state = GenStateSuspendedYield;
            return info;
          }

          context.delegate = null;
        }

        if (method === "next") {
          if (state === GenStateSuspendedYield) {
            context.sent = arg;
          } else {
            context.sent = undefined;
          }

        } else if (method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw arg;
          }

          if (context.dispatchException(arg)) {
            // If the dispatched exception was caught by a catch block,
            // then let that catch block handle the exception normally.
            method = "next";
            arg = undefined;
          }

        } else if (method === "return") {
          context.abrupt("return", arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          var info = {
            value: record.arg,
            done: context.done
          };

          if (record.arg === ContinueSentinel) {
            if (context.delegate && method === "next") {
              // Deliberately forget the last sent value so that we don't
              // accidentally pass it on to the delegate.
              arg = undefined;
            }
          } else {
            return info;
          }

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(arg) call above.
          method = "throw";
          arg = record.arg;
        }
      }
    };
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      this.sent = undefined;
      this.done = false;
      this.delegate = null;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;
        return !!caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.next = finallyEntry.finallyLoc;
      } else {
        this.complete(record);
      }

      return ContinueSentinel;
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = record.arg;
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      return ContinueSentinel;
    }
  };
})(
  // Among the various tricks for obtaining a reference to the global
  // object, this seems to be the most reliable technique that does not
  // use indirect eval (which violates Content Security Policy).
  typeof global === "object" ? global :
  typeof window === "object" ? window :
  typeof self === "object" ? self : this
);

}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"_process":185}],183:[function(require,module,exports){
module.exports = require("./lib/polyfill");

},{"./lib/polyfill":1}],184:[function(require,module,exports){
module.exports = require("babel-core/polyfill");

},{"babel-core/polyfill":183}],185:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = setTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            currentQueue[queueIndex].run();
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    clearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        setTimeout(drainQueue, 0);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

// TODO(shtylman)
process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],186:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _util = require('./util');

var scheme_prefix = 'miui-music';

exports.scheme_prefix = scheme_prefix;
var domain = {
  music: 'http://v2.fm.duokanbox.com',
  api: 'http://v2.fm.duokanbox.com',
  search: 'http://music.search.xiaomi.net'
};

exports.domain = domain;
var default_cover = {
  album: 'img/album_default.png',
  artist: 'img/avatar_default.png',
  avatar: 'img/avatar_default.png',
  radio: 'img/radio_default.png'
};

exports.default_cover = default_cover;
var locale_list = ['bn-in', 'de', 'en-gb', 'en-in', 'en', 'es', 'fr', 'hi', 'in', 'it', 'kn-in', 'ml-in', 'mr-in', 'ms-my', 'pt-br', 'ro', 'ru', 'ta-in', 'te-in', 'th', 'tr', 'sk', 'vi', 'zh-cn', 'zh-tw'];

exports.locale_list = locale_list;
var download = {
  none: 0,
  pending: 1,
  running: 2,
  paused: 4,
  successful: 8,
  failed: 16
};

exports.download = download;
var playlist = {
  all: '9223372036854775807',
  local: '9223372036854775800',
  favorite: '99',
  type: {
    preset: -2, // 预置音乐
    normal: 0, // 用户自定义
    fm: 101, // 在线电台
    billboard: 102, // 在线榜单
    recommend: 103, // 在线推荐
    artist: 104, // 在线歌手
    album: 105, // 在线歌手的某个专辑
    all: 1008,

    search: 1001, // 输入确定
    instant: 1002, // 输入框提示
    suggest: 1005, // 搜索推荐
    personal_radio: 1006, // 私人电台

    hot_song: 1012
  },
  uri: {
    'private': 'content://com.miui.player.private/playlists',
    from_id: function from_id(id) {
      return 'content://com.miui.player.private/playlists_audio_map/' + id;
    }
  },
  helper: {
    is_local: function is_local(type) {
      return ~[playlist.type.normal, playlist.type.preset].indexOf(type);
    },

    getTypeNameById: function getTypeNameById(id) {
      if (id === 0) {
        return (0, _util._)('my_playlist');
      }

      if (id === -2) {
        return (0, _util._)('preset_music_playlist');
      }

      if (id === 105) {
        return (0, _util._)('fragment_title_artist_album');
      }

      var dict = Object.keys(playlist.type).reduce(function (ret, d) {
        ret[playlist.type[d]] = d;
        return ret;
      }, {});
      if (!dict[id]) {
        return '';
      }
      if (id > 100 && id < 106) {
        return (0, _util._)('title_online_' + dict[id]);
      }
      return '';
    },

    get_display_name: function get_display_name(name, type) {
      return type === playlist.type.preset ? (0, _util._)('preset_music_playlist') : name;
    },

    component: function component() {
      return [{
        url: '/category/mobile/recommend?size=6',
        target: '#recommend',
        type: playlist.type.recommend,
        klass: ['box', 'normal'],
        title: (0, _util._)('title_online_recommend'),
        more: {
          title: (0, _util._)('more_online_recommend'),
          href: '/more/category/mobile/recommend?size=10'
        },
        img: { w: 300, h: 300 },
        extra: function extra(x) {
          return '<div class="title">' + x.name + '</div>';
        }
      }, {
        url: '/category/mobile/newest?size=6',
        target: '#release',
        type: playlist.type.album,
        klass: ['box', 'normal'],
        title: (0, _util._)('title_online_release'),
        more: {
          title: (0, _util._)('more_online_release'),
          href: '/more/category/mobile/newest?size=10'
        },
        img: { w: 300, h: 300 },
        extra: function extra(x) {
          return '<div class="title">' + x.name + '</div>\n          <div class="desc">' + x.artist + '</div>';
        }
      }, {
        url: '/category/mobile/fm?size=4',
        target: '#fm',
        type: playlist.type.fm,
        klass: ['box', 'single'],
        title: (0, _util._)('title_online_fm'),
        more: {
          title: (0, _util._)('more_online_fm'),
          href: '/more/category/mobile/fm?size=10'
        },
        img: { w: 172, h: 172 },
        extra: function extra(x) {
          return '<div class="title">' + x.name + '</div>\n            <div class="desc">' + x.intro + '</div>\n          </div><div class="row"><i class="icon icon-play"></i>';
        }
      }, {
        url: 'http://music.search.xiaomi.net/recommend/v6.1/homeartists?size=4',
        target: '#artist',
        type: playlist.type.artist,
        klass: ['box', 'single'],
        title: (0, _util._)('title_online_artist'),
        more: {
          title: (0, _util._)('more_online_artist'),
          href: '/artist'
        },
        img: { w: 160, h: 160 },
        extra: function extra(x) {
          return '<div class="title">' + x.artist_name + '</div>\n          <div class="desc">' + x.introduce + '</div>';
        }
      }];
    }
  }
};
exports.playlist = playlist;

},{"./util":192}],187:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _util = require('./util');

var _config = require('./config');

//<https://github.com/steelbrain/dQuery>
//<http://www.ericponto.com/blog/2014/10/05/es6-dom-library/>

function d(q) {
  var target = arguments.length <= 1 || arguments[1] === undefined ? document : arguments[1];

  return target.querySelector(q);
}

d.all = function (q) {
  var target = arguments.length <= 1 || arguments[1] === undefined ? document : arguments[1];
  return [].slice.call(target.querySelectorAll(q));
};

d.on = function (q, event, matcher, callback) {
  var root = d(q);
  root.addEventListener(event, function (e) {
    var target = e.target;
    if (target.correspondingUseElement) {
      //Fix for svg <use> element
      target = target.correspondingUseElement.parentNode;
    }
    var hits = d.all(matcher, root).filter(function (parent) {
      return parent.contains(target);
    });
    if (hits.length && callback) {
      e.preventDefault();
      callback(hits[0], e);
    }
  }, false);
};

//<https://github.com/madrobby/zepto/blob/master/src/touch.js>
d.press = function (el, fn) {
  var delay = 500; //ViewConfiguration.getLongPressTimeout
  var delta = 2;
  var start = undefined;
  var timer = undefined;
  function clear(e) {
    var touch = e.touches[0];

    if (Date.now() - start.t < delay / 2 || timer && touch && (Math.abs(touch.pageX - start.x) > delta || Math.abs(touch.pageY - start.y) > delta)) {
      clearTimeout(timer);
    }
  }
  el.addEventListener('touchstart', function (e) {
    //console.log('start', e.currentTarget);
    start = {
      x: e.touches[0].pageX,
      y: e.touches[0].pageY,
      t: Date.now()
    };
    timer = setTimeout(fn, delay);
  }, false);
  el.addEventListener('touchmove', clear, false);
  el.addEventListener('touchend', clear, false);
};

d.update = function (selector, val) {
  var target = arguments.length <= 2 || arguments[2] === undefined ? document : arguments[2];

  var el = d(selector, target);
  if (!el || !val) {
    return;
  }
  var attr = 'textContent';
  if (el.nodeName.toLowerCase() === 'img') {
    if (val === _config.default_cover.avatar || ~val.indexOf('base64')) {
      el.src = val;
    } else {
      el.dataset.src = val;
      el.classList.add('lazy');
      (0, _util.load_image)(el);
    }
    return;
  } else if (el.nodeName.toLowerCase() === 'a') {
    attr = 'href';
  }
  if (el[attr] !== val) {
    el[attr] = val;
  }
};

d.remove = function (el) {
  el.parentNode.removeChild(el);
};

d.shadow = function (el) {
  return el.createShadowRoot ? el.createShadowRoot() : el.webkitCreateShadowRoot();
};

exports['default'] = d;
module.exports = exports['default'];

},{"./config":186,"./util":192}],188:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('./util');

var _dom = require('./dom');

var _dom2 = _interopRequireDefault(_dom);

var _viewPageOnline = require('./view/page.online');

var _viewPageOnline2 = _interopRequireDefault(_viewPageOnline);

var _viewPageLocal = require('./view/page.local');

var _viewPageLocal2 = _interopRequireDefault(_viewPageLocal);

var _viewPageDetail = require('./view/page.detail');

var _viewPageDetail2 = _interopRequireDefault(_viewPageDetail);

var _viewPageArtist = require('./view/page.artist');

var _viewPageArtist2 = _interopRequireDefault(_viewPageArtist);

var _viewPageSearch = require('./view/page.search');

var _viewPageSearch2 = _interopRequireDefault(_viewPageSearch);

var _viewPageMore = require('./view/page.more');

var _viewPageMore2 = _interopRequireDefault(_viewPageMore);

var _viewPagePayment = require('./view/page.payment');

var _viewPagePayment2 = _interopRequireDefault(_viewPagePayment);

var proxy = {
  local: _viewPageLocal2['default'],
  online: _viewPageOnline2['default']
};

exports['default'] = {
  home: function home() {
    var t = (0, _util.parse_hash_query)().page !== 'online' ? 'local' : 'online';
    var root = (0, _dom2['default'])('#app');
    root.classList.add('page_home_' + t);
    proxy[t]();
  },

  more: _viewPageMore2['default'],
  artist: _viewPageArtist2['default'],
  detail: _viewPageDetail2['default'],
  search: _viewPageSearch2['default'],
  payment: _viewPagePayment2['default'],

  no_network: function no_network() {
    (0, _util.reset)('#app').innerHTML = '<div class="box no_network"><img src=\'img/wifi.png\' /><p>' + (0, _util._)('network_settings_error') + '</p><a id="js_reload" onclick="location.reload()" href="">' + (0, _util._)('retry') + '</a></div>';
    //dom('#js_reload').addEventListener('click', location.reload, false);
  },

  not_found: function not_found() {
    console.error('404 HANDLER NOT FOUND');
    //redirect to home_local
  }
};
module.exports = exports['default'];

},{"./dom":187,"./util":192,"./view/page.artist":195,"./view/page.detail":196,"./view/page.local":197,"./view/page.more":198,"./view/page.online":199,"./view/page.payment":200,"./view/page.search":201}],189:[function(require,module,exports){
'use strict';

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

require('babelify/polyfill');

var _router = require('./router');

var _router2 = _interopRequireDefault(_router);

_router2['default'].init();

},{"./router":191,"babelify/polyfill":184}],190:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _util = require('./util');

var _config = require('./config');

var miui = undefined;
var feature = {
  prefix: 'com.miui.player.hybrid.feature.',
  getter: function getter(name) {
    //[feature_list]: res/xml/music_hybrid_config.xml
    return ~name.indexOf('.') ? name : feature.prefix + name;
  }
};

//<http://byronsalau.com/blog/how-to-create-a-guid-uuid-in-javascript/>
function uuid() {
  return 'cb_' + 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0,
        v = c === 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}

function mi() {
  var _miui;

  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var name = args[0];
  var param = args[2];
  var callback = args[3];

  // console.log([name, JSON.stringify(param), callback].join(' === '), decodeURIComponent(location.hash));

  if (!miui) {
    miui = window.MiuiJsBridge || {
      invoke: function invoke() {
        for (var _len2 = arguments.length, kargs = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          kargs[_key2] = arguments[_key2];
        }

        return console.log('Error: miui is undefined; args: ' + kargs.join(', '));
      }
    };
  }

  args[0] = feature.getter(name);
  if (param && typeof param !== 'string') {
    args[2] = JSON.stringify(param);
  }

  args[3] = callback || 'notify';
  if (callback && typeof callback === 'function') {
    (function () {
      var method = uuid();
      window[method] = function (d) {
        var obj = JSON.parse(d);
        callback(obj.content);
        if (obj.code !== 10000) {
          //multiple callback from native
          setTimeout(function () {
            window[method] = undefined;
          }, 3000);
        }
      };
      args[3] = method;
    })();
  }
  //console.log(args);
  var res = (_miui = miui).invoke.apply(_miui, args);
  //网络请求的返回值可能不是 json
  return name === 'RequestNetwork' ? res : JSON.parse(res);
}

//mi('RegisterForegroundObserver', 'callback', null, (res)=> {
//console.log('on_rfo_callback: ', res);
//});

var count_dict = {
  all: 'QueryAllTrackCount',
  artist: 'QueryFavoriteArtistCount',
  favorite: 'QueryFavoriteTrackCount',
  local: 'QueryLocalTrackCount'
};

exports['default'] = {

  mi: mi,

  request: function request(param) {
    return new Promise(function (resolve, reject) {
      var raw = mi('RequestNetwork', 'sync', param, null);
      if (raw) {
        var res = JSON.parse(raw);
        if (res && res.content) {
          return resolve(JSON.parse(res.content));
        }
      }
      console.error('request error: ', param);
      reject({});
    });
  },

  count: Object.keys(count_dict).reduce(function (ret, k) {
    ret[k] = function (fn) {
      return mi(count_dict[k], 'callback', null, fn);
    };
    return ret;
  }, {}),

  control: function control(param) {
    return mi('ControlService', 'sync', param, null);
  },

  playback: function playback() {
    var id = arguments.length <= 0 || arguments[0] === undefined ? _config.playlist.all : arguments[0];
    var type = arguments.length <= 1 || arguments[1] === undefined ? _config.playlist.type.all : arguments[1];
    var name = arguments.length <= 2 || arguments[2] === undefined ? '全部歌曲' : arguments[2];
    var song_list = arguments.length <= 3 || arguments[3] === undefined ? [] : arguments[3];
    var start = arguments.length <= 4 || arguments[4] === undefined ? 0 : arguments[4];
    var enter_nowplaying = arguments.length <= 5 || arguments[5] === undefined ? false : arguments[5];

    var ub = new _util.URLBuilder('service').append({
      id: id,
      start: start,
      enter_nowplaying: enter_nowplaying,
      type: encodeURIComponent(type),
      name: encodeURIComponent(name),
      songs: encodeURIComponent(JSON.stringify(song_list))
    }).done();
    return mi('HandleUri', 'sync', ub, null);
  },

  play_radio: function play_radio() {
    var _this = this;

    var login = arguments.length <= 0 || arguments[0] === undefined ? false : arguments[0];

    mi('QueryUserInfo', 'callback', null, function (res) {
      if (res.userId) {
        _this.playback(null, _config.playlist.type.personal_radio, 'PERSONAL_RADIO', null, 0, true);
      } else {
        if (login) {
          mi('LoginAccount', 'callback', null, function () {
            return _this.play_radio(false);
          });
        }
      }
    });
  },

  toast: function toast(msg) {
    mi('ToastFeature', 'sync', { content: msg }, null);
  },

  close: function close() {
    mi('FinishFragment', 'sync', null, null);
  },

  open: function open(url) {
    //XXX http for all env
    if (window.location.protocol === 'http:') {
      window.location.hash = url;
    } else {
      var ub = new _util.URLBuilder(url).replace('///', '//').append({ anim: 'slide' }).done();
      mi('HandleUri', 'sync', ub, null);
    }
  },

  playlist: {
    favorite_state: function favorite_state(song) {
      if (!song.globalId) {
        song.globalId = '3$' + song.sid;
      }
      var state = mi('QueryFavoriteStates', 'sync', {
        list: [song]
      }, null);
      return state.content[song.globalId] === 'true';
    },

    track: function track(id, fn) {
      return mi('QueryPlaylistTracks', 'callback', {
        playlistId: id
      }, fn);
    },

    mine: function mine(id_list, fn) {
      if (id_list === undefined) id_list = null;

      var param = id_list ? { playlistIds: id_list } : null;
      return mi('QueryPlaylistList', 'callback', param, function (res) {
        res.list = res.list.filter(function (x) {
          return ! ~[99, 98, 96].indexOf(x._id);
        });
        fn(res);
      });
    },

    manage: function manage(d) {
      var param = {
        playlistName: _config.playlist.helper.get_display_name(d.name, d.list_type),
        playlistId: d._id
      };
      return mi('PlaylistLongClickFeature', 'sync', param, null);
    },

    add_song: function add_song(id) {
      var uri = new _util.URLBuilder('track_picker').append({ dest_playlist_id: id }).done();
      mi('HandleUri', 'sync', uri, null);
    },

    single_song: function single_song(song, ref) {
      var param = {
        source: song.global_id ? song.global_id.split('$')[0] : 3,
        globalId: song.global_id || '',
        song: song,
        ref: ref
      };
      mi('TrackItemLongClickFeature', 'sync', param, null);
    },

    create: function create() {
      return mi('AlertCreatePlaylistDialog', 'sync', null, null);
    },

    favorite: function favorite(res, id, type) {
      var intro = res.intro;
      var name = res.name;
      var pic_large_url = res.pic_large_url;
      var list = res.list;

      //let listGlobalId = '3$' + (playlist.type.artist === type ? res.artist_id : res.nid);
      return mi('CreatePlaylist', 'sync', {
        type: type,
        name: name,
        listGlobalId: '3$' + res.nid,
        songs: list,
        descript: intro,
        iconUrl: pic_large_url
      }, null);
    },

    remove_with_alert: function remove_with_alert(playlistId, playlistName, callback) {
      mi('AlertConfirm', 'callback', {
        title: (0, _util._)('delete'),
        message: (0, _util._)('message_delete_playlist', playlistName),
        positiveText: (0, _util._)('ok'),
        negativeText: (0, _util._)('cancel'),
        cancelable: true
      }, function (res) {
        if (res.action === 'positive') {
          mi('DeletePlaylist', 'sync', { playlistId: playlistId }, null);
          if (callback) {
            callback();
          }
        }
      });
    },

    remove: function remove(playlistId) {
      return mi('DeletePlaylist', 'sync', { playlistId: playlistId }, null);
    },

    toggle_favorite_song: function toggle_favorite_song(song, state) {
      if (state) {
        mi('AlertConfirm', 'callback', {
          title: (0, _util._)('action_item_remove_from_favorite'),
          checkhint: (0, _util._)('delete_file_as_well'),
          positiveText: (0, _util._)('ok'),
          negativeText: (0, _util._)('cancel'),
          cancelable: true
        }, function (res) {
          if (res.action === 'positive') {
            mi('RemoveFromPlaylist', 'sync', {
              playlistId: _config.playlist.favorite,
              globalIds: [song.globalId],
              deleteFile: res.checked
            }, null);
          }
        });
      } else {
        mi('AddToPlaylist', 'sync', {
          playlistId: _config.playlist.favorite,
          songs: [song]
        }, null);
      }
    }
  },

  search: {
    input: function input(_input) {
      return mi('UpdateSearchInput', 'callback', { input: _input }, null);
    },
    history: function history(param) {
      if (param) {
        return mi('UpdateSearchHistory', 'sync', param, null);
      } else {
        return mi('GetSearchHistory', 'sync', null, null);
      }
    }
  },

  nowplay: function nowplay(fn) {
    return mi('QueryNowplayingInfo', 'callback', null, fn);
  },

  download: function download(param) {
    return mi('DownloadSong', 'sync', param, null);
  },

  share: function share(str) {
    mi('ShareFeature', 'sync', str, null);
  },

  filename: function filename(song) {
    var name = song.name || song.title || '';
    var artist_name = song.artist_name || song.artist || '';
    var album_name = song.album_name || song.album || '';
    return mi('GetMp3FileName', 'sync', { name: name, artist_name: artist_name, album_name: album_name }, null).content;
  },

  stat: function stat(statinfo) {
    mi('StatEvent', 'sync', statinfo, null);
  },

  env: {
    /*
    [ref]: common/music_core/src/com/miui/player/hybrid/feature/ConfigStatics.java
    private static final int TYPE_SUPPORTED_ONLINE = 1;
    private static final int TYPE_NETWORK_ALLOW = 2;
    private static final int TYPE_NETWORK_ACTIVE = 3;
    private static final int TYPE_METERED_NETWORK_ACTIVE = 4;
     private static final int TYPE_FONT_SIZE_TYPE = 5;
      * 类型参数，请参考MiuiConfiguration下的
      UI_MODE_TYPE_NORMAL = 1
      UI_MODE_TYPE_SCALE_SMALL = 0x0c = 12
      UI_MODE_TYPE_SCALE_MEDIUM = 0x0d = 13
      UI_MODE_TYPE_SCALE_LARGE = 0x0e = 14
      UI_MODE_TYPE_SCALE_HUGE = 0x0f =15
      UI_MODE_TYPE_SCALE_GODZILLA = 0x0b = 11
     private static final int TYPE_SCREEN_SIZE = 6;
      * 为了避免把float转成string，这里用100个dp做标准，得到结果后需要除以100
     private static final int TYPE_100_DP_TO_PIX = 7;
    private static final int TYPE_BOTTOM_BAR_HEIGHT = 8;
    public static final int TYPE_APK_VERSION_NAME = 9;
    public static final int TYPE_APK_API_LEVEL = 10;
    public static final int TYPE_NEED_BASE64 = 11;
    */
    _base: 1080,
    _query: function _query(t) {
      return mi('ConfigStatics', 'sync', { type: t }, null).content;
    },
    support_online: function support_online() {
      return this._query(1) === 'true';
    },
    network_enable: function network_enable() {
      return this._query(3) === 'true';
    },
    fontScale: function fontScale() {
      return this._query(5);
    },
    screenSize: function screenSize() {
      return this._query(6);
    },
    dp_to_px: function dp_to_px() {
      return this._query(7);
    },
    bottom_bar_height: function bottom_bar_height() {
      return this._query(8) * this._base / this.screenSize().width;
    },
    base64_enable: function base64_enable() {
      return this._query(11) === 'true';
    }
  }
};
module.exports = exports['default'];

},{"./config":186,"./util":192}],191:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

var _util = require('./util');

var _config = require('./config');

var _handler = require('./handler');

var _handler2 = _interopRequireDefault(_handler);

var _miui = require('./miui');

var _miui2 = _interopRequireDefault(_miui);

var _dom = require('./dom');

var _dom2 = _interopRequireDefault(_dom);

var impl = {
  root: (0, _dom2['default'])('#app'),
  prepare: function prepare(v) {
    var q = (0, _util.parse_hash_query)();
    var local = v === 'home' && q.page === 'local' || v === 'detail' && _config.playlist.helper.is_local(parseInt(q.type, 10));
    if (!_miui2['default'].env.network_enable() && !local) {
      v = 'no_network';
    }
    impl.root.dataset.fontScale = _miui2['default'].env.fontScale();
    (0, _util.style)('#app::after { height: ' + _miui2['default'].env.bottom_bar_height() + 'px; }');
    return _handler2['default'][v] || _handler2['default'].not_found;
  },
  dispatch: function dispatch() {
    (0, _util.splash)();
    var args = (0, _util.parse_hash_url)().split('?')[0].split('/');
    impl.root.className = args.reduce(function (ret, arg, idx) {
      ret.push('page_' + args.slice(0, idx + 1).join('_'));
      return ret;
    }, ['lang_' + impl.get_locale()]).join(' ');
    impl.prepare(args[0]).apply(undefined, _toConsumableArray(args.slice(1)));
  },
  load: function load() {
    impl.anchor();
    impl.dispatch();
  },
  anchor: function anchor() {
    _dom2['default'].on('#app', 'click', 'a', (0, _util.debounce)(function (el) {
      _miui2['default'].open(el.getAttribute('href')); //el.href 会补全scheme://host/path
      (0, _util.stat_info)(el, 'click');
    }));
  },
  get_locale: function get_locale() {
    var lang = arguments.length <= 0 || arguments[0] === undefined ? window.navigator.language.toLowerCase() : arguments[0];

    return _config.locale_list.filter(function (d) {
      return ~lang.indexOf(d);
    })[0] || 'en';
  },
  update_lang: function update_lang(res) {
    //TODO: save to localstroage
    window._ = function (k, v) {
      var obj = res[k];
      if (!obj) {
        console.error('locale key "' + k + '" not found');
        return k;
      }
      var ret = '';
      if (typeof obj === 'string') {
        ret = res[k].replace('${v}', v);
      } else {
        var key = parseInt(v, 10) === 1 && obj.one ? 'one' : 'other';
        ret = obj[key].replace('${v}', v);
      }
      //console.log(ret, ret[0] + ret[ret.length - 1]);
      return ret[0] + ret[ret.length - 1] === '""' ? ret.slice(1, -1) : ret;
    };
  }
};

exports['default'] = {
  notify: function notify() {
    window.addEventListener('msg', function (e) {
      var msg = JSON.parse(e.body);
      console.log('on notify: ', msg, location.href);
    });
    window.notify = function (json_str) {
      var ev = document.createEvent('HTMLEvents');
      ev.initEvent('msg', true, true);
      ev.body = json_str;
      window.dispatchEvent(ev);
    };
  },
  setup: function setup() {
    ['font_size', 'dp_to_px', 'bottom_bar_height'].map(function (method) {
      var res = _miui2['default'].env[method]();
      console.log(method, res);
    });
  },
  init: function init() {
    var _this = this;

    //console.log(location.href);
    (0, _util.request)('lang/lang.' + impl.get_locale() + '.js').then(function (res) {
      _this.notify();
      //this.setup();
      impl.update_lang(res);
      impl.load();
      window.addEventListener('hashchange', impl.dispatch, false);
    });
  }
};
module.exports = exports['default'];

},{"./config":186,"./dom":187,"./handler":188,"./miui":190,"./util":192}],192:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _slicedToArray = (function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i['return']) _i['return'](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError('Invalid attempt to destructure non-iterable instance'); } }; })();

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

exports._ = _;
exports.reset = reset;
exports.splash = splash;
exports.url_base64 = url_base64;
exports.request = request;
exports.render = render;
exports.stat_info = stat_info;
exports.load_image = load_image;
exports.lazy_image = lazy_image;
exports.parse_hash_url = parse_hash_url;
exports.parse_hash_query = parse_hash_query;
exports.load_all_track = load_all_track;
exports.escape = escape;
exports.style = style;
exports.random = random;
exports.shuffle = shuffle;
exports.debounce = debounce;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _config = require('./config');

var _dom = require('./dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('./miui');

var _miui2 = _interopRequireDefault(_miui);

function _() {
  return window._.apply(window, arguments) || console.error.apply(console, arguments);
}

function reset(selector) {
  var scroll = arguments.length <= 1 || arguments[1] === undefined ? true : arguments[1];

  var node = (0, _dom2['default'])(selector);
  while (node.firstChild) {
    node.removeChild(node.firstChild);
  }
  if (scroll) {
    window.scrollTo(0, 0);
  }
  return node;
}

function splash() {
  var target = arguments.length <= 0 || arguments[0] === undefined ? '#app' : arguments[0];

  var loader = document.createElement('div');
  loader.classList.add('loader');
  loader.innerHTML = '<img src="img/loading.png" />';
  reset(target).appendChild(loader);
  return loader;
}

function url_base64(url) {
  var b64 = _miui2['default'].env.base64_enable();
  var prefix = 'content://com.miui.player.hybrid/';
  if (b64 && ~url.indexOf(prefix)) {
    var path = url.substr(prefix.length);
    return prefix + 'base64/' + btoa(path);
  }
  return url;
}

function url_transform(url) {
  if (~url.indexOf('lang')) {
    return url;
  }
  var _url = url.replace('/detail/', '/channel/');
  if (! ~url.indexOf('://')) {
    _url = _config.domain.api + _url;
  }
  _url = 'content://com.miui.player.hybrid/http/' + encodeURIComponent(_url);
  return url_base64(_url);
}

function request(url) {
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.open('get', url_transform(url));
    xhr.onerror = function () {
      return reject({});
    };
    xhr.onload = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          var res = JSON.parse(xhr.responseText);
          res.ref_url = url;
          resolve(res);
        }
      }
    };
    xhr.send();
  });
}

var URLBuilder = (function () {
  function URLBuilder(str) {
    _classCallCheck(this, URLBuilder);

    this.url = ~str.indexOf('://') ? str : 'miui-music://' + str;
  }

  _createClass(URLBuilder, [{
    key: 'replace',
    value: function replace() {
      var _url2;

      this.url = (_url2 = this.url).replace.apply(_url2, arguments);
      return this;
    }
  }, {
    key: 'append',
    value: function append(obj) {
      this.url = Object.keys(obj).reduce(function (ret, k) {
        var pipe = ~ret.indexOf('?') ? '&' : '?';
        ret += pipe + k + '=' + obj[k];
        return ret;
      }, this.url);
      return this;
    }
  }, {
    key: 'done',
    value: function done() {
      return url_base64(this.url);
    }
  }]);

  return URLBuilder;
})();

exports.URLBuilder = URLBuilder;

function _render(opt, res) {
  if (!res.list) {
    return null;
  }
  var wrap = document.createElement('div');
  if (opt.klass) {
    var _wrap$classList;

    (_wrap$classList = wrap.classList).add.apply(_wrap$classList, _toConsumableArray(opt.klass));
  }
  if (opt.target) {
    wrap.classList.add('component-' + opt.target.substr(1));
  }
  var cover_cls = 'cover lazy stat';
  var cover_src = _config.default_cover.album;
  if (_config.playlist.type.artist === opt.type) {
    cover_cls += ' artist';
    cover_src = _config.default_cover.artist;
  }
  var img_conf = '';
  if (opt.img) {
    img_conf = 'data-conf=' + JSON.stringify(opt.img);
  }
  var html = res.list.map(function (x, idx) {
    var id = x.nid || x._id || x.artist_id || x.sid;
    var def_src = id === 'personal_radio' ? _config.default_cover.radio : cover_src;
    var type = opt.type || x.list_type;
    var src = x.url || x.avatar_url || x.icon_url || x.cover_url;
    var img = '<img class="' + cover_cls + '" src="' + def_src + '" data-src="' + src + '" ' + img_conf + ' />';
    var rows = wrap.classList.contains('single') ? '<div class="row">' + img + '</div><div class="row">' + opt.extra(x, idx) + '</div>' : '' + img + opt.extra(x, idx);
    return '<a class="item" href="/detail/' + id + '?type=' + type + '" data-id="' + id + '">' + rows + '</a>';
  }).join('');
  if (opt.compact) {
    return html;
  }

  wrap.innerHTML = (opt.title ? '<div class="hd">' + opt.title + '</div>' : '') + ('<div class="bd">' + html + '</div>');

  if (opt.more) {
    var config = { type: opt.type };
    if (opt.title) {
      config.config = encodeURIComponent(JSON.stringify({ title: opt.title }));
    }
    var url = new URLBuilder(opt.more.href).append(config).done();
    wrap.innerHTML += '<a class="ft more" href="' + url + '">' + opt.more.title + '</a>';
  }
  if (opt.target && (0, _dom2['default'])(opt.target)) {
    (0, _dom2['default'])(opt.target).appendChild(wrap);
  }
  return wrap;
}

function render(opt, res) {
  if (opt.url) {
    return request(opt.url).then(function (o) {
      return _render(opt, o);
    });
  } else {
    return _render(opt, res);
  }
}

// 判断是否是歌曲的item
function is_song_item(el) {
  return el.classList.contains('song');
}

// 判断需要打点到哪里
function getStatTo(type) {
  var statToFeedBack = 1 << 0;
  var statToAdvertisement = 1 << 1;
  //var statToMiStat = 1 << 2;
  var statTo;
  if (type === 'click') {
    // click事件需要打点到广告和feedback
    statTo |= statToAdvertisement;
    statTo |= statToFeedBack;
  } else if (type === 'view') {
    // view事件只需要打点到广告
    statTo |= statToAdvertisement;
  }
  return statTo;
}

function stat_info(el, type) {
  // 寻找父节点中的matcher项
  var parent = function parent(item, matcher) {
    var hits = _dom2['default'].all(matcher).filter(function (p) {
      return p.contains(item);
    });
    return hits.length ? hits[0] : null;
  };

  // 获得一些统计项
  var itemNode = parent(el, '.item');
  var classList = (0, _dom2['default'])('#app').classList;
  var title = (0, _dom2['default'])('.title', itemNode);
  var name;
  if (title !== null) {
    name = title.textContent;
  }
  if (name.length <= 0) {
    name = itemNode.textContent;
  }
  var id = itemNode.dataset.id;
  var isSongItem = is_song_item(itemNode);
  if (isSongItem) {
    id = itemNode.dataset.globalId;
    id = id.substring(id.indexOf('$') + 1);
  }
  var hd = (0, _dom2['default'])('.hd', parent(itemNode, '.box'));

  var statInfo = {
    stat_to: getStatTo(type),
    type: isSongItem ? 'song' : 'album',
    id: id,
    songId: isSongItem ? id : null,
    albumId: isSongItem ? null : id,
    name: name,
    track_name: isSongItem ? name : null,
    album_name: isSongItem ? null : name,
    position: _dom2['default'].all('a', itemNode.parentNode).indexOf(itemNode),
    groupName: hd ? hd.textContent : '',
    event_id: type,
    page: classList[classList.length - 1]
  };

  console.log(statInfo);
  _miui2['default'].stat(statInfo);
  el.classList.remove('stat');
}

function is_visible(el) {
  var rect = el.getBoundingClientRect();
  return rect.top >= 0 && rect.left >= 0 && rect.top <= (window.innerHeight || document.documentElement.clientHeight);
}

function is_all_visible(el) {
  var rect = el.getBoundingClientRect();
  return is_visible(el) && rect.bottom + 180 <= (window.innerHeight || document.documentElement.clientHeight);
}

function load_image_when_visible(el) {
  if (is_visible(el)) {
    load_image(el);
  } else {
    return true;
  }
}

function stat_when_all_visible(el) {
  if (is_all_visible(el)) {
    stat_info(el, 'view');
  } else {
    return true;
  }
}

function load_image(el) {
  var src = el.dataset.src;
  if (!src || src === 'undefined') {
    el.classList.remove('lazy');
    el.classList.add('loaded', 'empty');
    return;
  }
  if (window.location.protocol !== 'http:') {
    var conf = el.dataset.conf;
    conf = conf ? JSON.parse(conf) : {};
    conf.type = 'img';
    if (src.substr(0, 'content'.length) === 'content') {
      src = new URLBuilder(src).append(conf).done();
    } else {
      src = new URLBuilder('content://com.miui.player.hybrid/http/' + encodeURIComponent(src)).append(conf).done();
    }
  }
  var img = new Image();
  img.onload = function () {
    el.src = src;
    el.classList.remove('lazy');
    el.classList.add('loaded');
  };
  img.src = src;
}

//<https://gist.github.com/aliem/2171438>

function lazy_image() {
  function reduce() {
    var imageList = _dom2['default'].all('.lazy').filter(load_image_when_visible);
    var statList = _dom2['default'].all('.stat').filter(stat_when_all_visible);

    if (imageList.length === 0 && statList.length === 0) {
      window.removeEventListener('scroll', reduce, false);
    }
  }

  setTimeout(reduce, 750);
  window.addEventListener('scroll', reduce, false);
}

function parse_hash_url() {
  var hash = arguments.length <= 0 || arguments[0] === undefined ? window.location.hash : arguments[0];

  //let hash =  test_url || window.location.hash;
  var scheme = '#' + _config.scheme_prefix + '://';
  var url = ~hash.indexOf(_config.scheme_prefix) ? decodeURIComponent(hash).substr(scheme.length) : hash.substr(2);
  //return 'home';
  return url || scheme + 'home';
}

//<https://github.com/sindresorhus/query-string>

function parse_hash_query() {
  var url = arguments.length <= 0 || arguments[0] === undefined ? parse_hash_url() : arguments[0];
  var def_page = arguments.length <= 1 || arguments[1] === undefined ? 'online' : arguments[1];

  //let url = parse_hash_url(hash);
  var str = url.split('?')[1] || '';
  return str.trim().split('&').reduce(function (ret, param) {
    var _param$split = param.split('=');

    var _param$split2 = _slicedToArray(_param$split, 2);

    var k = _param$split2[0];
    var v = _param$split2[1];

    if (v) {
      ret[k] = decodeURIComponent(v);
      if (ret[k].indexOf('{') === 0 || ret[k].indexOf('[') === 0) {
        ret[k] = JSON.parse(ret[k]) || null;
      }
    }
    return ret;
  }, { page: def_page });
}

var Swip = (function () {
  function Swip(node) {
    var _this = this;

    _classCallCheck(this, Swip);

    //console.log(node);
    this.limit = {
      x: 150,
      y: 100,
      t: 300
    };
    ['touchstart', 'touchmove', 'touchend'].map(function (ev) {
      return node.addEventListener(ev, _this, false);
    });
  }

  _createClass(Swip, [{
    key: 'handleEvent',
    value: function handleEvent(e) {
      e.preventDefault();
      console.log(e.type);
      this[e.type](e.changedTouches[0]);
    }
  }, {
    key: 'touchstart',
    value: function touchstart(o) {
      console.log('t-start', o);
      _miui2['default'].mi('setPagerDragsEnabled', 'sync', { enable: false }, null);
      this.pos = {
        x: o.pageX,
        y: o.pageY,
        t: new Date().getTime()
      };
    }
  }, {
    key: 'touchend',
    value: function touchend(o) {
      console.log('t-end', o);
      _miui2['default'].mi('setPagerDragsEnabled', 'sync', { enable: true }, null);
      var pos = this.pos;
      var limit = this.limit;
      var callback = this.callback;

      var mx = o.pageX - pos.x;
      //if (((new Date().getTime() - pos.t) >= limit.t)
      if (Math.abs(o.pageY - pos.y) >= limit.y || Math.abs(mx) >= limit.x) {
        var dir = mx < 0 ? 'left' : 'right';
        //console.log(mx, dir, callback);
        callback(dir);
      }
    }
  }, {
    key: 'touchmove',
    value: function touchmove(o) {
      console.log('t-move', o);
      //TODO move with finger
    }
  }, {
    key: 'move',
    value: function move(callback) {
      this.callback = callback;
    }
  }]);

  return Swip;
})();

exports.Swip = Swip;

function load_all_track(url, count, size) {
  var max_pn = Math.ceil(count / size);
  return Promise.all([].concat(_toConsumableArray(Array(max_pn))).map(function (d, i) {
    return request(url + '&pn=' + (i + 1));
  })).then(function (list) {
    return list.reduce(function (ret, d) {
      d.list.map(function (o) {
        return ret.push(o);
      });
      return ret;
    }, []);
  }, function (err) {
    console.error(err);
    _miui2['default'].toast(_('network_request_error'));
    return [];
  });
}

function escape(str) {
  // 考虑重用
  var div = document.createElement('div');
  div.appendChild(document.createTextNode(str));
  return div.innerHTML;
}

function style(str) {
  var node = document.createElement('style');
  node.appendChild(document.createTextNode(str));
  document.head.appendChild(node);
}

var formatter = {
  song: {
    localToOnline: function localToOnline(song) {
      return [['name', 'title'], ['artist_name', 'artist'], ['album_name', 'album'], ['all_rate', 'bitrates']].reduce(function (ret, _ref) {
        var _ref2 = _slicedToArray(_ref, 2);

        var k = _ref2[0];
        var o = _ref2[1];

        if (song[o]) {
          ret[k] = song[o];
        }
        return ret;
      }, { global_id: song.global_id });
    }
  }
};

exports.formatter = formatter;

function random(min, max) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

//<http://underscorejs.org/docs/underscore.html#section-39>

function shuffle(list) {
  return list.reduce(function (ret, d, i) {
    var r = random(0, i);
    if (i !== r) {
      ret[i] = ret[r];
    }
    ret[r] = d;
    return ret;
  }, []);
}

//<http://underscorejs.org/docs/underscore.html#section-83>

function debounce(fn) {
  var delay = arguments.length <= 1 || arguments[1] === undefined ? 750 : arguments[1];
  var immediate = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];

  var timer = undefined,
      ts = undefined,
      args = undefined,
      res = undefined;

  var later = function later() {
    var last = Date.now() - ts;
    if (last < delay && last > 0) {
      timer = setTimeout(later, delay - last);
    } else {
      timer = null;
      if (!immediate) {
        res = fn.apply(undefined, _toConsumableArray(args));
      }
    }
  };

  return function () {
    for (var _len = arguments.length, kargs = Array(_len), _key = 0; _key < _len; _key++) {
      kargs[_key] = arguments[_key];
    }

    args = kargs;
    ts = Date.now();
    var runable = immediate && !timer;
    if (!timer) {
      timer = setTimeout(later, delay);
    }
    if (runable) {
      res = fn.apply(undefined, _toConsumableArray(args));
      args = null;
    }
    return res;
  };
}

//console.js = (o)=> console.log(JSON.stringify(o, null, '  '));

//import 'object.observe';
//var object = { foo: null, list: [1, 2, 3] };
//Object.observe(object, function(changes) {
//console.log(changes);
//});

//object.foo = 'bar';
//object.list = [1, 9];
//setTimeout(()=> {
//object.foo = 'bar';
//object.list = [1, 2];
//}, 1000);

},{"./config":186,"./dom":187,"./miui":190}],193:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

function event(node, id, title, type, res) {
  var fav_id = res.fav_id || 0;
  node.addEventListener('click', (0, _util.debounce)(function (e) {
    var el = e.target;
    if (el.tagName.toLowerCase() === 'i') {
      el = el.parentNode;
    }
    var klass = el.classList;

    if (klass.contains('play_all')) {
      _miui2['default'].playback(id, type, res.name, res.list);
    } else if (klass.contains('favorite')) {
      var detail = _config.playlist.type.artist === type ? {
        intro: res.introduce,
        name: res.artist_name,
        nid: res.artist_id,
        pic_large_url: res.avatar_big,
        list: res.list
      } : res;
      var r = _miui2['default'].playlist.favorite(detail, id, type);
      if (r.code === 0 && r.content) {
        fav_id = r.content.playlistId;
        klass.remove('favorite');
        klass.add('cancel');
        el.innerHTML = '<i class="icon icon-cancel-thin"></i>' + (0, _util._)('action_item_cancel');
      }
    } else if (klass.contains('cancel')) {
      if (_config.playlist.type.normal === type) {
        _miui2['default'].playlist.remove_with_alert(id, title, _miui2['default'].close);
      } else {
        var r = _miui2['default'].playlist.remove(fav_id);
        if (r.code === 0) {
          klass.remove('delete');
          klass.add('favorite');
          var text = _config.playlist.type.artist === type ? 'follow' : 'favorite';
          el.innerHTML = '<i class="icon icon-favorite-thin"></i>' + (0, _util._)('action_item_' + text);
        }
      }
    } else if (klass.contains('multiple')) {
      _miui2['default'].mi('HandleUri', 'sync', new _util.URLBuilder('track_multichoice').append({
        id: id,
        type: type,
        name: encodeURIComponent(title)
      }).done(), null);
    } else if (klass.contains('share')) {
      var shareInfo = {
        id: id,
        title: title,
        type: type,
        imageUrl: res.url || res.avatar_url || '',
        shareType: 1
      };
      _miui2['default'].share(shareInfo);
    } else if (klass.contains('download')) {
      var list = _config.playlist.helper.is_local(type) ? res.list.map(_util.formatter.song.localToOnline) : res.list;
      _miui2['default'].download({
        list: list,
        ref: {
          id: id,
          type: type,
          name: title
        }
      });
    } else if (klass.contains('add_song')) {
      _miui2['default'].playlist.add_song(id);
    }
  }), false);
}

function render(id, title, type, res) {
  //console.log(id, title, type);
  var node = document.createElement('div');
  var list = [res.fav_id ? 'cancel' : 'favorite', 'download', 'share', 'play_all', 'multiple'];
  if (_config.playlist.type.normal === type) {
    list[2] = 'add_song';
  }
  var html = list.map(function (d) {
    if (d === 'download' && (!_miui2['default'].env.support_online() || _config.playlist.type.preset === type)) {
      return '<span hide></span>';
    }
    var text = _config.playlist.type.artist === type && d === 'favorite' ? 'follow' : d;
    return '<span class="' + d + '"><i class="icon icon-' + d + '-thin"></i>' + (0, _util._)('action_item_' + text) + '</span>';
  }).join('');
  node.innerHTML = html;
  event(node, id, title, type, res);
  return node;
}

exports['default'] = render;
module.exports = exports['default'];

},{"../config":186,"../miui":190,"../util":192}],194:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

var _util = require('../util');

var _config = require('../config');

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

function redirect(url) {
  var type = url.hash ? url.hash.slice(1) : '';
  if (type === 'list') {
    type = 'billboard';
  }
  if (~['recommend', 'billboard', 'fm'].indexOf(type)) {
    var id = url.pathname.split('/').slice(-1);
    return '/detail/' + id + '?type=' + _config.playlist.type[type];
  } else if (type === 'artist') {
    return url.pathname + '?type=' + _config.playlist.type.artist;
  } else if (type === 'browser') {
    var raw = url.href.split('#browser')[0];
    var index = raw.indexOf('://');
    if (index < 0) {
      console.error('no scheme, url=' + url);
      return '';
    }

    var scheme = raw.substring(0, index);
    var data = raw.substring(index + 3);
    return 'intent://' + data + '#Intent;scheme=' + scheme + ';action=android.intent.action.VIEW;end';
  } else {
    return '/web?url=' + encodeURIComponent(url.href);
  }
}

function fallbackURL(url) {
  var link = new URL(url);
  // H2W 的 webview 里 URL 对象不可用
  if (!link.pathname && !link.hash) {
    link = document.createElement('a');
    link.href = url;
  }
  return link;
}

function render() {
  (0, _util.request)('/banner').then(function (_ref) {
    var list = _ref.list;

    var banner = _dom2['default'].all('.banner');
    var limit = Math.min(banner.length, list.length);
    [].concat(_toConsumableArray(Array(limit))).map(function (d, i) {
      var item = list[i];
      if (!item.bg_url_w) {
        return;
      }
      var link = document.createElement('a');
      link.href = redirect(fallbackURL(item.redirect));
      link.classList.add('item');
      if (~link.href.indexOf('intent://')) {
        link.addEventListener('click', function (e) {
          e.stopImmediatePropagation();
          e.stopPropagation();
          e.preventDefault();
          _miui2['default'].mi('SendIntentFeature', 'sync', {
            type: 1,
            flag: 1,
            url: link.href
          }, null);
        }, false);
      }
      var img = new _util.URLBuilder('content://com.miui.player.hybrid/http/' + encodeURIComponent(item.bg_url_w)).append({
        w: document.body.offsetWidth,
        type: 'img'
      }).done();
      link.innerHTML = '<img src="' + img + '" />';
      banner[i].appendChild(link);
    });
  });
}

exports['default'] = render;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192}],195:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _util = require('../util');

var _config = require('../config');

function output() {
  var node = document.createElement('div');
  var idx = ['chinese', 'japanese_korean', 'europa_america'].indexOf((0, _util.parse_hash_query)().page);
  var area = idx !== -1 ? idx + 1 : 1;

  var url = new _util.URLBuilder('http://music.search.xiaomi.net/recommend/v6.1/areaArtist').append({
    area: area,
    count: 3
  }).done();

  Promise.all(['/artists/' + area, url].map(_util.request)).then(function (res) {
    var html = res[0].list.map(function (d, i) {
      var k = d.gender.toLowerCase();
      var desc = k === 'group' ? 'Ngroups_count' : 'Nartists_count';
      return '<a href="artist_list?type=106&id=' + ((area - 1) * 3 + i + 1) + '" class="item">\n        <div class="row"><img src="img/artist_' + k + '.png" class="cover artist" /></div>\n        <div class="row">\n          <div class="title">' + (0, _util._)(k + '_artist') + '</div>\n          <div class="desc">' + (0, _util._)(desc, d.count) + '</div>\n        </div>\n      </a>';
    }).join('');
    node.innerHTML = '<div class="box single">' + html + '</div>';

    node.appendChild((0, _util.render)({
      klass: ['box', 'single'],
      title: (0, _util._)('title_online_artist'),
      type: _config.playlist.type.artist,
      extra: function extra(x) {
        return '<div class="title">' + x.artist_name + '</div>';
      }
    }, res[1]));

    (0, _util.reset)('#app').appendChild(node);
    (0, _util.lazy_image)();
  });
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../util":192}],196:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _action = require('./action');

var _action2 = _interopRequireDefault(_action);

var _songlist = require('./songlist');

var _songlist2 = _interopRequireDefault(_songlist);

function get_base_url(id, type, res) {
  var src = res.url || res.avatar_url || '';
  var base = '';
  if (_config.playlist.helper.is_local(type)) {
    base = 'content://com.miui.player.hybrid/playlist_icon/' + id;
  } else if (src) {
    base = 'content://com.miui.player.hybrid/http/' + encodeURIComponent(src);
  }
  return base;
}

function get_bg(base) {
  var bg_url = '';
  if (base) {
    var d = 15;
    bg_url = new _util.URLBuilder(base).append({
      type: 'img',
      blurRadius: d,
      w: d,
      h: d
    }).done();
    if (!get_bg.once) {
      (0, _util.style)('.bg { position: fixed; z-index: -1; opacity: 0;\n            width: 100%; height: 750px;\n            -webkit-transition: opacity .5s ease-in-out; }\n            .bg.loaded { opacity: 1; }');
      get_bg.once = true;
    }
  }
  return bg_url;
}

function update_bg() {
  var bg = (0, _dom2['default'])('.bg');
  if (bg && !bg.classList.contains('loaded')) {
    bg.classList.add('loaded');
  }
}

function set_bg(root, bg_url) {
  if (!root || !bg_url || set_bg.url === bg_url) {
    update_bg();
    return;
  }
  var set_topbar = function set_topbar() {
    (0, _util.style)('.topbar { background: 50% 0 / 100% 750px url(' + bg_url + ') no-repeat; }');
    window.removeEventListener('scroll', set_topbar, false);
  };

  var img = new Image();
  img.onload = function () {
    set_bg.url = bg_url;
    (0, _util.style)('.bg { background: 50% 0 / 100% 750px url(' + bg_url + ') no-repeat; }');
    window.addEventListener('scroll', set_topbar, false);
    update_bg();
  };
  img.src = bg_url;
}

function set_cover(url) {
  var cover = new Image();
  cover.onerror = function () {
    cover.src = _config.default_cover.album;
  };
  cover.onload = function () {
    cover.classList.add('cover');
    var row = (0, _dom2['default'])('.detail .row');
    row.innerHTML = '';
    row.appendChild(cover);
  };
  cover.src = url;
}

function _render(id, type, res) {
  var base = get_base_url(id, type, res);
  var cover_url = new _util.URLBuilder(base).append({
    w: 300,
    h: 300,
    type: 'img'
  }).done();

  var title = res.name || res.artist_name || '';
  title = _config.playlist.helper.get_display_name(title, type);
  //TODO list_detail_title for artist/ablum/normal
  var root = (0, _util.reset)('#app');
  var showSearch = _miui2['default'].env.support_online() ? '' : 'hide';
  root.innerHTML += '<div class="cover bg"></div>\n  <div class="topbar">\n    <div class="row">\n      <span class="back"><svg class="icon"><use xlink:href="index.svg#arrow-left"></use></svg>' + (0, _util._)('list_detail_title') + '</span>\n    </div>\n    <div class="row" ' + showSearch + '>\n      <a href="/search" class="search"><svg class="icon"><use xlink:href="index.svg#search"></use></svg></a>\n    </div>\n  </div>\n  <div class="box detail">\n    <div class="row"></div>\n    <div class="row">\n      <div class="title">' + (0, _util.escape)(title) + '</div>\n      <div class="desc">' + (0, _util._)('Ntracks_count', res.count || res.total || res.list.length) + '</div>\n    </div>\n    <div class="row" hide><img class="cover" src="' + cover_url + '" /></div>\n  </div>\n  <div class="box action"></div>\n  <ol class="box single playlist"></ol>';

  //<div id="similar"></div>`;
  set_bg(root, get_bg(base));
  set_cover(cover_url);

  (0, _dom2['default'])('.action').appendChild((0, _action2['default'])(id, title, type, res));
  (0, _dom2['default'])('.playlist').appendChild((0, _songlist2['default'])(id, type, res));
  (0, _dom2['default'])('.back').addEventListener('click', _miui2['default'].close, false);

  //TODO with suggest
  //render({
  //url: '/category/13?size=6',
  //target: '#similar',
  //klass: ['box', 'normal'],
  //title: _('fragment_title_recommend'),
  //extra: (x)=> `<div class="title">${x.name || x.artist_name}</div>`
  //}).then(lazy_image);
}

function set_fav_id(type, ret, fn) {
  _miui2['default'].playlist.mine(null, function (_ref) {
    var list = _ref.list;

    var gid = '3$' + (_config.playlist.type.artist === type ? ret.artist_id : ret.nid);
    var tmp = list.filter(function (d) {
      return d.list_type === type && d.globalId === gid;
    });
    ret.fav_id = tmp.length ? tmp[0]._id : 0;
    fn(ret);
  });
}

var updater = {
  local: function local(id, type) {
    _miui2['default'].playlist.track(id, function (res) {
      _miui2['default'].playlist.mine([id], function (d) {
        res.name = d.list[0].name;
        res.fav_id = id;
        _render(id, type, res);
      });
    });
  },

  online: function online(id, type, res) {
    set_fav_id(type, res, function (d) {
      _render(id, type, d);
    });
  }
};

function output(id) {
  var size = 10;
  var query = (0, _util.parse_hash_query)();
  var type = parseInt(query.type || 103, 10);

  (0, _util.style)('body { background: linear-gradient(180deg, #ccc 15%, #fff 40%); }');
  if (_config.playlist.helper.is_local(type)) {
    var on_change = function on_change() {
      updater.local(id, type);
    };
    _miui2['default'].mi('RegisterForegroundObserver', 'callback', null, on_change);
    var uri = _config.playlist.uri['private'] + '/' + id;
    _miui2['default'].mi('RegisterUriObserver', 'callback', { uri: uri }, on_change);
    updater.local(id, type);
  } else if (_config.playlist.type.artist === type) {
    (function () {
      var url = '/artist/' + id + '/music?size=' + size;
      Promise.all(['/artist/' + id, url + '&pn=1'].map(_util.request)).then(function (res) {
        return (0, _util.load_all_track)(url, res[1].total, size).then(function (list) {
          res[0].list = list;
          res[0].count = list.length; //XXX count 有时候不等于 list.length, 这里使用 length
          return res[0];
        });
      }).then(function (res) {
        updater.online(id, type, res);
      });
    })();
  } else {
    (function () {
      var url = '/detail/' + id + '?size=' + size;
      (0, _util.request)(url + '&pn=1').then(function (res) {
        if (res && res.code === -1) {
          if (res.data && res.data.msg === 'not found') {
            _miui2['default'].toast((0, _util._)('playlist_unavailable'));
          } else {
            _miui2['default'].toast((0, _util._)('network_request_error'));
          }
          setTimeout(_miui2['default'].close, 1000);
          return null;
        }

        return (0, _util.load_all_track)(url, res.count, size).then(function (list) {
          res.list = list;
          res.count = list.length;
          return res;
        });
      }).then(function (res) {
        if (res) {
          updater.online(id, type, res);
        }
      });
    })();
  }
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192,"./action":193,"./songlist":202}],197:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _userinfo = require('./userinfo');

var _userinfo2 = _interopRequireDefault(_userinfo);

var impl = {

  navigator: function navigator() {
    var nav = _miui2['default'].env.support_online() ? ['local', 'all', 'favorite', 'artist'] : ['local', 'favorite'];
    return nav.map(function (d) {
      var uri = d === 'artist' ? 'artist_list?type=106&id=0' : d + '_music';
      var tr = d === 'local' ? 'song' : d;
      return '<a class="item" href="' + uri + '">\n        <div class="row">\n          <svg class="icon"><use xlink:href="index.svg#local-' + tr + '"></use></svg>\n        </div>\n        <div class="row">\n          <div class="title">' + (0, _util._)('nav_local_' + tr) + '</div>\n          <div class="desc" id="js_count_' + d + '"></div>\n        </div>\n      </a>';
    }).join('');
  },

  list: function list() {
    _miui2['default'].playlist.mine(null, function (res) {
      var img_conf = JSON.stringify({
        type: 'img',
        w: 172,
        h: 172
      });
      var html = res.list.map(function (x) {
        var is_local_playlist = _config.playlist.helper.is_local(x.list_type);
        var id = is_local_playlist ? x._id : x.globalId.split('$')[1];
        var src = is_local_playlist ? 'content://com.miui.player.hybrid/playlist_icon/' + id : x.icon_url;
        var title = (0, _util.escape)(_config.playlist.helper.get_display_name(x.name, x.list_type));
        return '<a class="item" href="/detail/' + id + '?type=' + x.list_type + '" data-id="' + x._id + '" data-type="' + x.list_type + '" data-name="' + title + '">\n          <div class="row"><img src="' + _config.default_cover.album + '" class="cover lazy" data-src="' + src + '" data-conf=' + img_conf + ' /></div>\n          <div class="row">\n            <div class="title">' + title + '</div>\n            <div class="desc">' + [_config.playlist.helper.getTypeNameById(x.list_type), (0, _util._)('Ntracks_count', x.member_count)].join(' | ') + '</div>\n          </div>\n        </a>';
      }).join('');
      (0, _dom2['default'])('#mine').innerHTML = '<div class="box single">\n        <div class="hd">' + (0, _util._)('my_playlist') + '</div>\n        <div class="bd">' + html + '</div>\n      </div>';

      (0, _util.lazy_image)();
      _dom2['default'].on('#mine', 'click', '.item', function (el) {
        setTimeout(function () {
          var ref = {
            id: el.dataset.id,
            type: el.dataset.type,
            name: el.dataset.name
          };
          _miui2['default'].mi('UpdateOnlineList', 'sync', { ref: ref }, null);
        }, 500);
      });
      //dom.all('#mine .item').forEach((el, idx)=> {
      //dom.press(el, ()=> {
      //miui.playlist.manage(res.list[idx]);
      //});
      //});
    });
  },

  radio: function radio() {
    if (!_miui2['default'].env.support_online()) {
      return;
    }
    var list = [{
      nid: 'personal_radio',
      name: (0, _util._)('name_online_personal_radio'),
      intro: (0, _util._)('desc_online_personal_radio')
    }];
    var node = (0, _util.render)({
      target: '#suggest',
      type: _config.playlist.type.recommend,
      klass: ['box', 'single'],
      title: (0, _util._)('title_online_suggest'),
      img: { w: 172, h: 172 },
      extra: function extra(x) {
        return '<div class="title">' + x.name + '</div>\n          <div class="desc">' + x.intro + '</div>\n        </div><div class="row"><i class="icon icon-play"></i>';
      }
    }, { list: list });

    (0, _dom2['default'])('.item', node).addEventListener('click', (0, _util.debounce)(function (e) {
      e.stopPropagation();
      e.preventDefault();
      _miui2['default'].play_radio(true);
    }));
  },

  count: function count() {
    Object.keys(_miui2['default'].count).forEach(function (k) {
      _miui2['default'].count[k](function (res) {
        //try shadow dom?
        var text = k === 'artist' ? 'Nartists_count' : 'Ntracks_count';
        var count = (0, _dom2['default'])('#js_count_' + k);
        if (count) {
          count.textContent = (0, _util._)(text, res.count);
        }
      });
    });
  }

};

var on_change = (0, _util.debounce)(function () {
  impl.count();
  impl.list();
}, 500, false);

function register() {
  _miui2['default'].mi('RegisterDataCacheObserver', 'callback', { type: 'playlists_member_count' }, on_change);
  _miui2['default'].mi('RegisterDataCacheObserver', 'callback', { type: 'playlist_favorite_count' }, on_change);
  _miui2['default'].mi('RegisterUriObserver', 'callback', { uri: _config.playlist.uri['private'] }, on_change);
}

function output() {
  (0, _util.reset)('#app').innerHTML = '\n    <div id="userinfo"></div>\n    <div class="box navigator local">\n      <nav>' + impl.navigator() + '</nav>\n    </div>\n    <div id="suggest"></div>\n    <div id="mine"></div>\n    <div class="create"><img src="img/local_plus.png" />' + (0, _util._)('create_playlist') + '</div>';

  (0, _dom2['default'])('#userinfo').appendChild((0, _userinfo2['default'])());

  register();
  impl.count();
  impl.list();
  impl.radio();

  (0, _util.lazy_image)();
  (0, _dom2['default'])('.create').addEventListener('click', (0, _util.debounce)(function () {
    _miui2['default'].playlist.create();
  }), false);
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192,"./userinfo":203}],198:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

function event(query) {
  if (_config.playlist.type.fm === parseInt(query.type, 10)) {
    _dom2['default'].on('.bd', 'click', '.item', function (el, e) {
      e.stopImmediatePropagation();
      e.stopPropagation();
      var size = 10;
      var id = el.dataset.id;
      var url = '/detail/' + id + '?size=' + size;
      (0, _util.request)(url + '&pn=1').then(function (res) {
        (0, _util.load_all_track)(url, res.count, size).then(function (list) {
          _miui2['default'].playback(id, _config.playlist.type.fm, res.name, (0, _util.shuffle)(list), 0, true);
        });
      });
    });
  }
}

function output() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var node = (0, _util.reset)('#app');
  var query = (0, _util.parse_hash_query)();
  var opt = {
    type: query.type,
    klass: ['box', 'single'],
    extra: function extra(x) {
      return '<div class="title">' + x.name + '</div>\n      <div class="desc">' + (x.description || x.intro || '') + '</div>';
    }
  };
  if (!query.sso) {
    var component = _config.playlist.helper.component().filter(function (d) {
      return d.type === parseInt(query.type, 10);
    });
    if (component.length) {
      opt = component[0];
      ['title', 'url', 'more'].forEach(function (k) {
        return opt[k] = null;
      });
    }
  } else {
    opt = {
      target: '#suggest',
      type: _config.playlist.type.recommend,
      klass: ['box', 'single'],
      img: { w: 172, h: 172 },
      extra: function extra(x) {
        return '<div class="title">' + (x.name || '') + '</div>\n        <div class="desc">' + (x.intro || '') + '</div>';
      }
    };
  }

  var loader = {
    pn: 1,
    size: 10,
    method: function method(el) {
      //首次加载全部节点
      node.appendChild(el);
      opt.compact = true;
      //重载为只插入 .item 到 .bd
      loader.method = function (html) {
        (0, _dom2['default'])('.bd', node).insertAdjacentHTML('beforeend', html);
      };
    },
    sso: function sso() {
      if (this.pn > 100 / this.size) {
        return;
      }
      query.sso.body = '{start: ' + 20 * (this.pn - 1) + ', count: ' + this.size + '}';
      _miui2['default'].request(query.sso).then(function (res) {
        return (0, _util.render)(opt, res);
      }).then(this.method).then(_util.lazy_image);
      this.pn++;
    },
    normal: function normal() {
      opt.url = (query.url || '/' + args.join('/')) + '?size=' + this.size + '&pn=' + this.pn;
      (0, _util.render)(opt).then(this.method).then(function () {
        (0, _util.lazy_image)();
        event(query);
      });
      this.pn++;
    },
    onScroll: function onScroll() {
      // body, #app 被设置为 height:100% 了，通过 .box 获取高度，#app:after height: 180px
      var top = (0, _dom2['default'])('#app .box').clientHeight - window.innerHeight - window.pageYOffset + 180 * 2;
      if (top > 0 && this.fn) {
        this.fn();
      }
    },
    init: function init() {
      var _this = this;

      var fn = query.sso ? 'sso' : 'normal';
      this.fn = this[fn];
      this.fn();
      //FIXME removeEvent if result.page_end
      window.addEventListener('scroll', (0, _util.debounce)(function (e) {
        return _this.onScroll(e);
      }), false);
    }
  };

  loader.init();
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192}],199:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _banner = require('./banner');

var _banner2 = _interopRequireDefault(_banner);

var _songlist = require('./songlist');

var _songlist2 = _interopRequireDefault(_songlist);

function get_href(src) {
  var display = src[2];
  if (!display) {
    return src[1];
  }

  return new _util.URLBuilder(src[1]).append({
    config: encodeURIComponent(JSON.stringify({
      title: (0, _util._)(display)
    }))
  }).done();
}

function nav(target) {
  var node = (0, _dom2['default'])(target);
  if (target === '#header') {
    node.innerHTML = '<a href="/search" class="search"><svg class="icon"><use xlink:href="index.svg#search-inner"></use></svg>' + (0, _util._)('search_hint') + '</a><div class="banner"></div>';
  }

  var wrap = document.createElement('div');
  wrap.classList.add('box', 'navigator', 'online');
  var el = document.createElement('nav');
  el.innerHTML = [['billboard', '/more/category/mobile/list?size=10&type=' + _config.playlist.type.billboard, 'title_online_billboard'], ['artist', '/artist'], ['playlist', '/more/category/mobile/recommend?size=10&type=' + _config.playlist.type.recommend, 'title_online_recommend'], ['fm', '/more/category/mobile/fm?size=10&type=' + _config.playlist.type.fm, 'title_online_fm']].map(function (d) {
    return '<a href="' + get_href(d) + '"><svg class="icon"><use xlink:href="index.svg#' + d[0] + '"></use></svg>' + (0, _util._)('nav_online_' + d[0]) + '</a>';
  }).join('') + '';
  wrap.appendChild(el);
  node.appendChild(wrap);
}

function more_suggest(url) {
  var login = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];

  _miui2['default'].mi('QueryUserInfo', 'callback', null, function (res) {
    if (res.userId) {
      _miui2['default'].open(url);
    } else {
      if (login) {
        _miui2['default'].mi('LoginAccount', 'callback', null, function () {
          return more_suggest(url, false);
        });
      }
    }
  });
}

function suggest() {
  var req = {
    url: 'http://music.search.xiaomi.net/recommend/v6.1/sso/personallist',
    scheme: 'sso',
    method: 'get',
    body: '{count:3}',
    serviceId: 'miuimusic_search'
  };
  var list = [{
    nid: 'personal_radio',
    name: (0, _util._)('name_online_personal_radio'),
    intro: (0, _util._)('desc_online_personal_radio')
  }];
  var method = function method(res) {
    _miui2['default'].mi('QueryUserInfo', 'callback', null, function (d) {
      if (d.userId && res && res.list) {
        list = list.concat(res.list);
      }
      (0, _util.reset)('#suggest', false);
      var node = (0, _util.render)({
        target: '#suggest',
        type: _config.playlist.type.recommend,
        klass: ['box', 'single'],
        title: (0, _util._)('title_online_suggest'),
        more: {
          title: (0, _util._)('more_online_suggest'),
          href: '/more/?sso=' + encodeURIComponent(JSON.stringify(req))
        },
        img: { w: 172, h: 172 },
        extra: function extra(x, i) {
          var icon = i ? '' : '</div><div class="row"><i class="icon icon-play"></i>';
          return '<div class="title">' + x.name + '</div>\n            <div class="desc">' + x.intro + '</div>' + icon;
        }
      }, { list: list });

      (0, _dom2['default'])('.item', node).addEventListener('click', (0, _util.debounce)(function (e) {
        e.stopPropagation();
        e.preventDefault();
        _miui2['default'].play_radio(true);
      }));

      (0, _dom2['default'])('.more', node).addEventListener('click', (0, _util.debounce)(function (e) {
        e.stopPropagation();
        e.preventDefault();
        more_suggest(e.currentTarget.href, true);
      }));
    });
  };
  _miui2['default'].request(req).then(method, method);
}

function output() {
  var loader = (0, _util.splash)('#app');
  //let wrap = document.createElement('div');
  var wrap = document.createDocumentFragment();
  //wrap.setAttribute('hide', '1');
  //TODO 去掉 loader, 优先显示 placeholder
  ['header', 'recommend', 'suggest', '.banner', 'release', 'hot_song', 'billboard', '.banner', 'fm', 'artist', 'footer', '.banner'].map(function (name) {
    var el = document.createElement('div');
    if (name === '.banner') {
      el.classList.add('banner');
    } else {
      el.id = name;
    }
    wrap.appendChild(el);
  });
  (0, _dom2['default'])('#app').appendChild(wrap);
  ['#header', '#footer'].map(nav);
  (0, _banner2['default'])();
  //dom.remove(loader);
  //wrap.removeAttribute('hide');
  /* */suggest();

  var task = _config.playlist.helper.component().map(function (d) {
    //保持缓存一致性, 默认请求size=10, 只显示部分
    if (~d.url.indexOf('http://')) {
      return (0, _util.render)(d);
    } else {
      var _ret = (function () {
        var size = (0, _util.parse_hash_query)(d.url).size || 10;
        return {
          v: (0, _util.request)(d.url.replace('size=' + size, 'size=10&pn=1')).then(function (res) {
            d.url = undefined;
            res.list = res.list.slice(0, size);
            (0, _util.render)(d, res);
          })
        };
      })();

      if (typeof _ret === 'object') return _ret.v;
    }
  });

  task.push((0, _util.request)('/detail/newest').then(function (res) {
    if (!res.list) {
      return console.error('[empty list]: ' + res.ref_url);
    }
    var img_conf = JSON.stringify({
      type: 'img',
      w: 172,
      h: 172
    });
    var hot_song = document.createElement('div');
    hot_song.classList.add('box', 'single', 'component-hot_song');
    hot_song.innerHTML = '<div class="hd">' + (0, _util._)('title_online_song') + '</div>\n      <div class="bd song_list"></div>';
    //<a class="ft more" href="/more/detail/newest?size=10">${_('more_online_song')}</a>`; //TODO 更多单曲页
    (0, _dom2['default'])('#hot_song').appendChild(hot_song);
    (0, _dom2['default'])('.song_list').appendChild((0, _songlist2['default'])(null, _config.playlist.type.hot_song, res, img_conf));
  }));

  task.push(Promise.all(['http://music.search.xiaomi.net/recommend/v6.1/newsongrank?size=3', 'http://music.search.xiaomi.net/recommend/v6.1/topsongrank?size=3', 'http://music.search.xiaomi.net/recommend/v6.1/risesongrank?size=3'].map(_util.request)).then(function (list) {
    (0, _util.render)({
      target: '#billboard',
      type: _config.playlist.type.billboard,
      klass: ['box', 'single'],
      title: (0, _util._)('title_online_billboard'),
      more: {
        title: (0, _util._)('more_online_billboard'),
        href: '/more/category/mobile/list?size=10'
      },
      img: { w: 320, h: 320 },
      extra: function extra(x) {
        return '<div class="title">' + x.name + '</div>\n        <ul class="desc">\n          ' + x.list.map(function (d, i) {
          return '<li>' + (i + 1) + ' ' + d.name + ' - ' + d.artist_name + '</li>';
        }).join('') + '\n        </ul>';
      }
    }, { list: list });
  }));

  Promise.all(task).then(function () {
    (0, _util.lazy_image)();
    _dom2['default'].remove(loader);
    wrap.removeAttribute('hide');
  });

  //FIXME registerBroadastObserver 只能注册一次，如果需要标记当前播放状态
  //      需要先重置掉 songlist 内的 register，统一派发
  _dom2['default'].on('#fm', 'click', '.item', function (el, e) {
    e.stopImmediatePropagation();
    e.stopPropagation();
    var size = 10;
    var id = el.dataset.id;
    var url = '/detail/' + id + '?size=' + size;
    (0, _util.request)(url + '&pn=1').then(function (res) {
      (0, _util.load_all_track)(url, res.count, size).then(function (list) {
        _miui2['default'].playback(id, _config.playlist.type.fm, res.name, (0, _util.shuffle)(list), 0, true);
      });
    });
  });
  _miui2['default'].mi('RegisterForegroundObserver', 'callback', null, suggest);
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192,"./banner":194,"./songlist":202}],200:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _util = require('../util');

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _config = require('../config');

//window.miui = miui;

var MusicPay = (function () {
  _createClass(MusicPay, null, [{
    key: 'formatDate',
    value: function formatDate(date) {
      var y = date.getFullYear(),
          m = date.getMonth() + 1,
          d = date.getDate();
      if (m < 10) {
        m = '0' + m;
      }
      if (d < 10) {
        d = '0' + d;
      }
      return [y, m, d].join('-');
    }
  }]);

  function MusicPay() {
    var _this = this;

    _classCallCheck(this, MusicPay);

    this.btnPay = (0, _dom2['default'])('footer .pay');
    this.txtAction = (0, _dom2['default'])('footer .pay .action');
    this.txtPayNumber = (0, _dom2['default'])('footer .pay .number');
    this.boxOut = (0, _dom2['default'])('#out');
    this.boxMask = (0, _dom2['default'])('#mask');
    this.boxApp = (0, _dom2['default'])('#app');
    this.rendered = false;
    _miui2['default'].mi('QueryUserInfo', 'callback', null, function (res) {
      _this.userId = res.userId;
      if (_this.userId) {
        _this.userHash = _miui2['default'].mi('DigestUtilFeature', 'sync', {
          content: _this.userId,
          algorithm: 'MD5'
        }, null).content.message;
      } else {
        _this.userHash = '';
      }
      _this.render();
    });
    this.products = {};
    this.productList = [];
    this.maxPrice = 0;
  }

  _createClass(MusicPay, [{
    key: 'hideMask',
    value: function hideMask() {
      var _this2 = this;

      setTimeout(function () {
        _this2.boxMask.setAttribute('hide', '');
      }, 2500);
    }
  }, {
    key: 'render',
    value: function render() {
      var _this3 = this;

      /*
        setTimeout(() => {
          this.hideMask();
        }, 5000);
        */
      this.btnPay.onclick = function () {
        if (_this3.disabled) {
          return;
        }
        _this3.pay();
        /*
        this.disabled = true;
        setTimeout(()=>{
          this.disabled = false;
        }, 500);
        */
      };
      document.body.onclick = function (e) {
        var t = e.target;
        //var status = this.status;
        while (t && t !== document.body && !(t.tagName === 'LI')) {
          t = t.parentNode;
        }
        if (t.tagName === 'LI') {
          var parent = t.parentNode,
              grand = parent.parentNode,
              list = _dom2['default'].all('li');
          if (grand.classList.contains('prolong')) {
            return;
          }
          var action = '@pay';
          if (grand.classList.contains('prolong')) {
            action = '@prolong';
          } else if (grand.classList.contains('upgrade')) {
            action = '@upgrade';
          }
          var isCurrent = t.classList.contains('crt');
          if (isCurrent) {
            t.classList.remove('crt');
            _this3.disabled = true;
            _this3.amount = 0;
            _this3.productId = 0;
            _this3.crt = null;
            //this.action = '@' + status;
          } else {
              for (var i = 0, len = list.length; i < len; i++) {
                var item = list[i];
                if (item === t) {
                  item.classList.add('crt');
                  _this3.disabled = false;
                  _this3.amount = +item.dataset.price;
                  _this3.productId = item.dataset.id;
                  _this3.crt = item;
                  //this.action = action;
                } else {
                    item.classList.remove('crt');
                    //this.action = '@' + status;
                  }
              }
            }
          _this3.action = action;
          /*
          if (e.target.classList.contains('prl')) {
            this.btnPay.click();
          }
          */
          return;
        }
      };
      this.init();
      this.rendered = true;
    }
  }, {
    key: 'recommend',
    value: function recommend() {
      /*
        var existing = dom('.status > ul > li.crt');
        if (existing) {
          return;
        }
        */
      var item;
      if (this.status === 'pay') {
        item = (0, _dom2['default'])('.status.pay > ul > li:last-child:not(.template)');
      } else if (this.status === 'upgrade') {
        item = (0, _dom2['default'])('.status.upgrade > ul > li:last-child:not(.template)');
      }
      if (item) {
        item.click();
      }
    }
  }, {
    key: 'init',
    value: function init() {
      var _this4 = this;

      (0, _util.request)(_config.domain.api + '/product' + '?_=' + +new Date()).then(function (data) {
        _this4.productList = data.list;
        var parent = (0, _dom2['default'])('.status.pay > ul');
        var tmpl = parent.firstElementChild;
        _this4.productList.forEach(function (item) {
          if (!isNaN(item.p_price)) {
            _this4.maxPrice = Math.max(_this4.maxPrice, item.p_price);
          }
          _this4.products[item.p_id] = item;
          if (item.p_type === 1) {
            var node = tmpl.cloneNode(true);
            (0, _dom2['default'])('.name', node).textContent = item.p_name || item.p_desc;
            (0, _dom2['default'])('.desc', node).textContent = item.p_desc;
            (0, _dom2['default'])('.price > .number', node).textContent = node.dataset.price = Math.round(item.p_price / 100);
            node.dataset.id = item.p_id;
            node.dataset.period = item.p_detail.period;
            node.classList.remove('hide');
            node.classList.remove('template');
            parent.appendChild(node);
          }
        });
        if (!_this4.userHash) {
          _this4.status = 'pay';
          _this4.recommend();
          _this4.hideMask();
          return;
        }
        (0, _util.request)(_config.domain.api + '/user?u=' + _this4.userHash + '&_=' + +new Date()).then(function (data1) {
          if (!data1.p_id || data1.count === '') {
            _this4.status = 'pay';
            _this4.recommend();
            _this4.hideMask();
            return;
          }
          if (typeof data1.p_id === 'number') {
            data1.p_id = [data1.p_id];
          }
          var parent1 = (0, _dom2['default'])('.status.prolong > ul');
          var tmpl1 = parent1.firstElementChild;
          var canUpgrade = false,
              crtPrice = 0;
          data1.p_id.forEach(function (p_id) {
            var item = _this4.products[p_id];
            if (item) {
              var node = tmpl1.cloneNode(true);
              crtPrice = item.p_price;
              if (crtPrice < _this4.maxPrice) {
                canUpgrade = true;
              }
              node.dataset.price = Math.round(item.p_price / 100);
              node.dataset.id = p_id;
              node.dataset.period = item.p_detail.period;
              (0, _dom2['default'])('.name', node).textContent = item.p_name || item.p_desc;
              (0, _dom2['default'])('.balance > .number', node).textContent = data1.count;
              var endTime = data1.end_time;
              var endTimeSpaceIndex = endTime.indexOf(' ');
              if (endTimeSpaceIndex > -1) {
                endTime = endTime.substring(0, endTimeSpaceIndex);
              }
              (0, _dom2['default'])('.expires time', node).textContent = endTime;
              node.classList.remove('hide');
              node.classList.remove('template');
              parent1.appendChild(node);
            }
          });
          if (canUpgrade) {
            var par = (0, _dom2['default'])('.status.upgrade > ul');
            var tmp = parent.firstElementChild;
            _this4.productList.forEach(function (item) {
              if (item.p_type !== 2) {
                return;
              }
              _this4.products[item.p_id] = item;
              var node = tmp.cloneNode(true);
              (0, _dom2['default'])('.name', node).textContent = item.p_name || item.p_desc;
              (0, _dom2['default'])('.desc', node).textContent = item.p_desc;
              var price = Math.floor(item.p_price / 100);
              (0, _dom2['default'])('.price > .number', node).textContent = '+' + price;
              node.dataset.price = price;
              node.dataset.id = item.p_id;
              var crtItem = (0, _dom2['default'])('.status.prolong > ul li:not(:first-child)');
              if (crtItem) {
                node.dataset.period = crtItem.dataset.period;
                var expBox = (0, _dom2['default'])('.expires', crtItem).cloneNode(true);
                //expBox.style.display = 'none';
                expBox.setAttribute('hide', '');
                node.appendChild(expBox);
              }
              node.classList.remove('hide');
              node.classList.remove('template');
              par.appendChild(node);
              if (item.p_info) {
                var infoNode = document.createElement('div');
                infoNode.className = 'info';
                infoNode.textContent = item.p_info;
                par.appendChild(infoNode);
              }
            });
            _this4.status = 'upgrade';
            _this4.recommend();
          } else {
            _this4.status = 'prolong';
          }
        });
        _this4.hideMask();
      });
      /*
      var isPending = () => {
        return miui.mi('QueryPaymentState', 'sync', null, null).content.isOrderProcessing;
      };
      var pending = isPending();
      //console.log('pending: ', pending);
      this.pending = pending;
      if (pending) {
        setTimeout(() => {
          var p = isPending();
          //console.log(pending);
          if (!p) {
            location.reload(true);
            //this.pending = p;
          }
        }, 6000);
      }
      */
    }
  }, {
    key: 'pay',
    value: function pay() {
      var _this5 = this;

      if (this.paying) {
        return;
      }
      this.paying = true;
      setTimeout(function () {
        _this5.paying = false;
      }, 600);
      if (!this.userId) {
        _miui2['default'].mi('LoginAccount', 'callback', null, function () {
          //console.log(data);
          location.reload(true);
        });
        return;
      }
      var message = '';
      if (this.crt) {
        var timeItem = (0, _dom2['default'])('.expires > time', this.crt),
            exp;
        if (timeItem) {
          var dateString = timeItem.textContent;
          var arr = dateString.split(/[\-\s]/g);
          var y = +arr[0],
              m = +arr[1],
              d = +arr[2];
          exp = new Date(y, m - 1, d);
          var expBox = (0, _dom2['default'])('.expires', this.crt);
          //if (expBox.style.display !== 'none') {
          if (expBox.hasAttribute('hide')) {
            exp.setSeconds(exp.getSeconds());
          } else {
            exp.setSeconds(exp.getSeconds() + +this.crt.dataset.period);
          }
        } else {
          exp = new Date();
          exp.setDate(exp.getDate() + 30);
        }
        if (this.status === 'pay') {
          message += (0, _dom2['default'])('.name', this.crt).textContent + '\n';
        } else if (this.status === 'prolong') {
          message += (0, _util._)('renew_period') + ' ' + (0, _util._)('one_month') + '\n';
        } else if (this.status === 'upgrade') {
          message += (0, _util._)('upgrade_to') + (0, _dom2['default'])('.name', this.crt).textContent + '\n';
        }
        message += (0, _util._)('expires') + ' ' + MusicPay.formatDate(exp) + '\n';
        message += (0, _util._)('price') + ' ' + this.crt.dataset.price + (0, _util._)('monthly_price');
      }
      _miui2['default'].mi('AlertConfirm', 'callback', {
        title: (0, _util._)('really_pay'),
        message: message,
        //checkhint: _('auto_payment'),
        checkDefaultValue: true,
        positiveText: (0, _util._)('ok'),
        negativeText: (0, _util._)('cancel'),
        cancelable: true
      }, function (res) {
        console.log(res);
        if (res.action === 'positive') {
          //get service token
          _miui2['default'].mi('QueryServiceToken', 'callback', {
            serviceId: 'music'
          }, function (data) {
            //console.log(data);
            //this.serviceToken = data.authToken;
            //get order string
            var xhr = new XMLHttpRequest();
            xhr.open('POST', _config.domain.api + '/order/ct' + '?_=' + +new Date(), true);
            xhr.onreadystatechange = function () {
              if (xhr.readyState === 4 && xhr.status === 200) {
                var text = xhr.responseText;
                try {
                  var json = JSON.parse(text);
                  //console.log('response: ', json);
                  if (json.status === 1) {
                    var decrypted = _miui2['default'].mi('DigestUtilFeature', 'sync', {
                      content: json.order,
                      algorithm: 'AES',
                      serviceId: 'payment',
                      mode: 2
                    }, null);
                    //console.log(decrypted);
                    _miui2['default'].mi('PaymentFeature', 'callback', {
                      productId: _this5.productId,
                      order: decrypted.content.message /*,
                                                       autoPayment: res.checked*/
                    }, function (result) {
                      if (result) {
                        //payment success
                        _miui2['default'].mi('ToastFeature', 'sync', {
                          content: (0, _util._)('payment_success')
                        }, null);
                      } else {
                        //payment failure
                        _miui2['default'].mi('ToastFeature', 'sync', {
                          content: (0, _util._)('payment_fail')
                        }, null);
                      }
                      setTimeout(function () {
                        location.reload(true);
                      }, 600);
                      //console.log(state);
                    });
                  } else if (json.status === 3) {
                      //operation too much
                      _miui2['default'].mi('ToastFeature', 'sync', {
                        content: (0, _util._)('too_freq')
                      }, null);
                    }
                } catch (ex) {
                  //console.log(ex);
                }
              } //if
            };
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            var postData = JSON.stringify({
              tk: +new Date(),
              xiaomi_id: _this5.userId,
              product_id: _this5.productId,
              service_token: data.authToken
            });
            //console.log(this.serviceToken);
            //console.log(postData);
            var encrypted = _miui2['default'].mi('DigestUtilFeature', 'sync', {
              content: postData,
              algorithm: 'AES',
              serviceId: 'payment',
              mode: 1
            }, null);
            //console.log(encrypted);
            var postString = encrypted.content.message;
            xhr.send('arg=' + encodeURIComponent(postString));
          });
        } //if 'positive'
      });
    }
  }, {
    key: 'pending',
    get: function get() {
      return this.btnPay.classList.contains('pending');
    },
    set: function set(value) {
      if (value) {
        this.btnPay.classList.add('pending');
        this.disabled = true;
      } else {
        this.btnPay.classList.remove('pending');
      }
    }
  }, {
    key: 'action',
    get: function get() {
      return this.txtAction.textCoutent;
    },
    set: function set(value) {
      if (value.charAt(0) === '@') {
        value = this.btnPay.dataset[value.substring(1)] || '';
      }
      this.txtAction.textContent = value;
    }
  }, {
    key: 'amount',
    get: function get() {
      return +this.txtPayNumber.textContent || 0;
    },
    set: function set(value) {
      this.txtPayNumber.textContent = value;
    }
  }, {
    key: 'status',
    set: function set(value) {
      var clsList = this.boxOut.classList;
      if (clsList.contains(value)) {
        return;
      }
      clsList.remove('pay');
      clsList.remove('upgrade');
      clsList.remove('prolong');
      clsList.add(value);
      var action = this.btnPay.dataset[value];
      if (action) {
        this.action = action;
      }
      this.disabled = true;
      if (value === 'prolong') {
        this.boxApp.classList.add('_prolong');
      } else {
        this.boxApp.classList.remove('_prolong');
      }
    },
    get: function get() {
      var clsList = this.boxOut.classList;
      if (clsList.contains('pay')) {
        return 'pay';
      } else if (clsList.contains('upgrade')) {
        return 'upgrade';
      } else if (clsList.contains('prolong')) {
        return 'prolong';
      }
      return '';
    }
  }, {
    key: 'disabled',
    set: function set(value) {
      if (!value) {
        if (!this.pending) {
          this.btnPay.removeAttribute('disabled');
        }
      } else {
        this.btnPay.setAttribute('disabled', '');
      }
    },
    get: function get() {
      return this.btnPay.hasAttribute('disabled');
    }
  }]);

  return MusicPay;
})();

function output() {
  var html = {
    main: '\n       <section id="out" class="">\n         <div class="pay status">\n           <div class="capt">' + (0, _util._)('avail_services') + '</div>\n           <ul>\n             <li class="hide template" data-price="0" data-id="0">\n               <div class="price"><span class="number"></span><span>' + (0, _util._)('monthly_price') + '</span></div>\n               <div class="name"></div>\n               <div class="desc"></div>\n             </li>\n           </ul>\n         </div>\n         <div class="prolong status">\n           <div class="capt">' + (0, _util._)('current_services') + '</div>\n           <ul>\n             <li class="hide template" data-price="0" data-id="0">\n               <div class="name"></div>\n               <div class="balance">' + (0, _util._)('remaining') + ' <span class="number"></span> ' + (0, _util._)('song_unit') + '</div>\n               <div class="expires">' + (0, _util._)('expires') + ' <time></time></div>\n               <div class="prl">' + (0, _util._)('renew_1') + '</div>\n             </li>\n           </ul>\n         </div>\n         <div class="upgrade status">\n           <div class="capt">' + (0, _util._)('upgrade_services') + '</div>\n           <ul>\n             <li class="hide template" data-price="0" data-id="0">\n               <div class="price"><span class="number"></span><span>' + (0, _util._)('monthly_price') + '</span></div>\n               <div class="name"></div>\n               <div class="desc"></div>\n             </li>\n           </ul>\n         </div>\n       </section>\n       <div id="mask">\n        <div class="tip loader"><img src="img/loading.png" /></div>\n       </div>',
    footer: '<footer class="pay">\n         <div class="desc"><a target="_blank" href="' + _config.domain.api + '/product/tos">' + (0, _util._)('tos') + '</a></div>\n         <div disabled class="pay" data-pay="' + (0, _util._)('pay') + '" data-upgrade="' + (0, _util._)('upgrade') + '" data-prolong="' + (0, _util._)('renew') + '">\n           <div class="ns"><span class="action">' + (0, _util._)('pay') + '</span> <span class="number">0</span> <span class="unit">' + (0, _util._)('monthly_price') + '</span></div>\n           <div class="ds">' + (0, _util._)('sel_svc') + '</div>\n           <div class="ps">' + (0, _util._)('order_pending') + '</div>\n         </div>\n       </footer>'
  };
  document.body.style.height = 'auto';
  var node = (0, _util.reset)('#app');
  node.innerHTML = html.main;
  document.body.insertAdjacentHTML('beforeend', html.footer);
  node.classList.remove('page_home');
  node.classList.add('page_payment');
  var pay = new MusicPay();
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192}],201:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _songlist = require('./songlist');

var _songlist2 = _interopRequireDefault(_songlist);

var colorize = {
  spec: [],
  fill: function fill() {
    this.spec = ['red', 'yellow', 'blue', 'green'];
  },
  get: function get() {
    if (!this.spec.length) {
      this.fill();
    }
    return this.spec.splice(Math.floor(Math.random() * this.spec.length), 1);
  }
};

function tag() {
  (0, _util.request)('http://music.search.xiaomi.net/v61/topQueries?count=16').then(function (res) {
    (0, _dom2['default'])('.hot_tag .bd').innerHTML = res.result.map(function (_ref) {
      var name = _ref.name;

      return '<span class="query tag tag-' + colorize.get() + '">' + name + '</span>';
    }).join('');
  });
}

function history() {
  var res = _miui2['default'].search.history();
  (0, _dom2['default'])('.history .bd').innerHTML = res.content.list.map(function (name) {
    return '<div class="query">' + (0, _util.escape)(decodeURIComponent(name)) + '</div>';
  }).join('');
}

function abortIfQueryChanged(query) {
  if (abortIfQueryChanged._query !== query) {
    throw new Error();
  }
}

function search(query) {
  var t = arguments.length <= 1 || arguments[1] === undefined ? 'instant' : arguments[1];

  abortIfQueryChanged._query = query;
  if (!query) {
    (0, _util.reset)('#app').innerHTML = '\n      <div class="box navigator search" hide>\n        <a href="">_(\'all_artist\')</a>\n        <a href="">_(\'听歌试曲\')</a>\n      </div>\n      <div class="box hot_tag">\n        <div class="hd">' + (0, _util._)('title_search_hot') + '</div>\n        <div class="bd"></div>\n      </div>\n      <div  class="box history">\n        <div class="hd">' + (0, _util._)('title_search_history') + '</div>\n        <div class="bd"></div>\n      </div>';

    tag();
    history();
    return;
  }
  if (! ~['instant', 'search', 'suggest'].indexOf(t)) {
    t = 'instant';
  }
  var url = 'http://music.search.xiaomi.net/v61';
  if (t === 'suggest') {
    url += '/0';
  }
  (0, _util.request)(url + '/' + t + '?q=' + query).then(function (res) {
    abortIfQueryChanged(query);
    return res.list.reduce(function (ret, d) {
      ret[d.type] = ret[d.type] || [];
      ret[d.type].push(d);
      return ret;
    }, {});
  }).then(function (group) {
    abortIfQueryChanged(query);
    (0, _util.reset)('#app');
    ['artist', 'album'].map(function (type) {
      abortIfQueryChanged(query);
      if (!group[type]) {
        return;
      }
      (0, _dom2['default'])('#app').appendChild((0, _util.render)({
        title: (0, _util._)(type + '_search_title'),
        type: _config.playlist.type[type],
        klass: ['box', 'single', 'result'],
        img: { w: 160, h: 160 },
        extra: function extra(x) {
          var ret = '<div class="title">' + (x.name || x.artist_name) + '</div>';
          if (type !== 'artist') {
            ret += '<div class="desc">' + (x.artist_name || '') + '</div>';
          }
          return ret;
        }
      }, { list: group[type] }));
    });
    return group.song;
  }).then(function (list) {
    abortIfQueryChanged(query);
    var img_conf = JSON.stringify({
      type: 'img',
      w: 160,
      h: 160
    });
    var song_list = document.createElement('div');
    song_list.classList.add('box', 'single', 'result');
    song_list.innerHTML = '<div class="hd">' + (0, _util._)('track_search_title') + '</div>\n        <div class="bd song_list"></div>';
    (0, _dom2['default'])('#app').appendChild(song_list);
    (0, _dom2['default'])('.song_list').appendChild((0, _songlist2['default'])(null, _config.playlist.type[t], { list: list }, img_conf));
  }).then(_util.lazy_image);
}

function event() {
  _dom2['default'].on('#app', 'click', '.item', function (el) {
    _miui2['default'].search.history({
      data: (0, _dom2['default'])('.title', el).textContent.trim(),
      type: 'add'
    });
  });
  _dom2['default'].on('#app', 'click', '.query', function (el) {
    var text = el.textContent.trim();
    _miui2['default'].search.input(text);
    _miui2['default'].search.history({
      data: text,
      type: 'add'
    });
  });
}

//FIXME with debounce
function on_change(res) {
  //console.log(JSON.stringify(res));
  var args = [];
  if (res && res.data) {
    args.push(res.data.text);
    if (res.data.type === 'submit') {
      _miui2['default'].search.history({
        data: res.data.text,
        type: 'add'
      });
      args.push('search');
    }
  }
  search.apply(undefined, args);
}

function register() {
  _miui2['default'].mi('RegisterSearchInput', 'callback', null, on_change);
}

function output() {
  var query = (0, _util.parse_hash_query)();
  var text = query.q;
  if (text) {
    _miui2['default'].search.input(text);
  }
  search(text);
  register();
  event();
}

exports['default'] = output;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192,"./songlist":202}],202:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

var _util = require('../util');

var _config = require('../config');

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var node = document.createElement('div');

var provider = {
  // 搜索结果页更新 result 数据后还被保持在委托事件内
  // 这里使用单例保证返回正确的 item
  // <http://jira.n.xiaomi.com/browse/MIUI-76162>
  init: function init(id, type, res) {
    this.id = id;
    this.res = res;
    this.type = type;
  },
  get_ref: function get_ref() {
    return {
      id: this.id,
      type: this.type,
      name: this.res.name
    };
  },
  get_song_by_idx: function get_song_by_idx(idx) {
    var song = this.res.list[idx];
    if (_config.playlist.helper.is_local(provider.type)) {
      return _util.formatter.song.localToOnline(song);
    }
    return song;
  }
};

function set_highlight(el) {
  var highlight = 'highlight';
  var hl = (0, _dom2['default'])('.' + highlight, node);
  if (el === hl) {
    return;
  }
  if (hl) {
    hl.classList.remove(highlight);
  }
  if (el) {
    el.classList.add(highlight);
  }
}

var on_playback_change = (0, _util.debounce)(function () {
  _miui2['default'].nowplay(function (song) {
    var el = (0, _dom2['default'])('[data-global-id="' + song.globalId + '"]', node);
    set_highlight(el);
  });
}, 500);

function event() {
  _dom2['default'].all('.song', node).forEach(function (el, idx) {
    _dom2['default'].press(el, function () {
      _miui2['default'].playlist.single_song(provider.res.list[idx], provider.get_ref());
    });
  });

  var wrapper = (0, _util.debounce)(_miui2['default'].download);
  _dom2['default'].on('#app', 'click', '.icon-download', function (el, e) {
    //el.setAttribute('state', 'active');
    e.stopImmediatePropagation();
    e.stopPropagation();
    wrapper({
      ref: provider.get_ref(),
      list: [provider.get_song_by_idx(el.parentNode.parentNode.dataset.idx - 1)]
    });
  });

  _dom2['default'].on('#app', 'click', '.song', function (el, e) {
    //不用阻止连续点击
    e.stopImmediatePropagation();
    e.stopPropagation();
    if (el.classList.contains('highlight')) {
      _miui2['default'].nowplay(function (d) {
        var name = d.isPlaying ? 'pause' : 'play';
        _miui2['default'].control({ name: name });
      });
    } else {
      set_highlight(el);
      _miui2['default'].playback(provider.id, provider.type, provider.res.name, provider.res.list, el.dataset.idx - 1);
    }
    (0, _util.stat_info)(el, 'click');
  });
}

function active_filter(d) {
  return ~['running', 'pending', 'paused'].map(function (k) {
    return _config.download[k];
  }).indexOf(d);
}

function register() {
  var list = provider.res.list.map(function (d) {
    if (_config.playlist.helper.is_local(provider.type)) {
      var b = _util.formatter.song.localToOnline(d);
      b._data = d._data;
      return b;
    }
    if (!d.global_id) {
      d.global_id = '3$' + d.sid;
    }
    return d;
  });
  _miui2['default'].mi('RegisterDownloadStateObserver', 'callback', { list: list }, function (res) {
    Object.keys(res.data).map(function (k) {
      var nodeList = _dom2['default'].all('[data-global-id="' + k + '"] .icon-download', node);
      if (!nodeList.length) {
        return;
      }
      var state_list = Object.keys(res.data[k]).map(function (state) {
        return ~state.indexOf('state') ? res.data[k][state] : 0;
      });
      var active_list = state_list.filter(active_filter);
      if (active_list.length) {
        state_list = active_list;
      }
      var code = Math.max.apply(Math, _toConsumableArray(state_list));
      if (code === _config.download.none) {
        nodeList.forEach(function (el) {
          return el.removeAttribute('state');
        });
      } else if (code === _config.download.successful) {
        nodeList.forEach(function (el) {
          return el.setAttribute('state', 'disable');
        });
      } else if (active_filter(code)) {
        nodeList.forEach(function (el) {
          return el.setAttribute('state', 'active');
        });
      }
    });
  });

  ['com.miui.player.metachanged', 'com.miui.player.playbackcomplete', 'com.miui.player.playstatechanged', 'com.miui.player.queuechanged'].map(function (action) {
    _miui2['default'].mi('RegisterBroadcastObserver', 'callback', { action: action }, on_playback_change);
  });
  on_playback_change();

  //歌曲收藏状态需要监听才会更新playlistcache
  _miui2['default'].mi('RegisterDataCacheObserver', 'callback', { type: 'playlist_favorite_count' }, null);
}

function render(id, type, res) {
  var img_conf = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];

  provider.init(id, type, res);
  node.innerHTML = res.list.map(function (song, idx) {
    idx++;
    var global_id = song.global_id || '3$' + song.sid;
    var rate = _config.playlist.helper.is_local(type) ? 'bitrates' : 'all_rate';
    var hq = song[rate] && ~song[rate].indexOf('320') ? '<img src="img/hq.png" class="hq" />' : '';
    var first_row = '<div class="row order">' + (idx < 10 ? '0' + idx : idx) + '</div>';
    var download_enable = _config.playlist.type.preset === type || !_miui2['default'].env.support_online() ? 'hide' : '';
    var desc = [song.artist_name || song.artist || (0, _util._)('unknown_artist_name'), song.album_name || song.album || (0, _util._)('unknown_album_name')].filter(function (d, i) {
      return !(_config.playlist.type.artist === type && i === 0);
    }).join(' | ');
    if (img_conf) {
      first_row = '<div class="row"><img class="cover lazy stat" src="' + _config.default_cover.album + '" data-src="' + song.cover_url + '" data-conf=' + img_conf + ' /></div>';
    }
    return '<li class="item song" data-idx="' + idx + '" data-global-id="' + global_id + '">\n      ' + first_row + '\n      <div class="row">\n        <div class="title">' + (song.name || song.title) + ' ' + hq + '</div>\n        <div class="desc">' + desc + '</div>\n      </div>\n      <div class="row" ' + download_enable + '><i class="icon icon-download"></i></div>\n    </li>';
  }).join('');

  register();
  event();
  return node;
}

exports['default'] = render;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192}],203:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('../util');

var _config = require('../config');

var _miui = require('../miui');

var _miui2 = _interopRequireDefault(_miui);

var _dom = require('../dom');

var _dom2 = _interopRequireDefault(_dom);

var user = undefined;
var node = document.createElement('div');

function bind(name) {
  return 'bid="js_userinfo_' + name + '"';
}

function fetch() {
  _miui2['default'].mi('QueryUserInfo', 'callback', { onlyId: false }, function (res) {
    user = res; // used in event
    _dom2['default'].update('[' + bind('userName') + ']', res.userName || res.userId || (0, _util._)('not_login'), node);
    _dom2['default'].update('[' + bind('userAvatarUrl') + ']', res.userAvatarBase64 || res.userAvatarUrl || _config.default_cover.avatar, node);
  });
}

function register() {
  _miui2['default'].mi('RegisterBroadcastReceiver', 'callback', 'android.accounts.LOGIN_ACCOUNTS_PRE_CHANGED', fetch);
  _miui2['default'].mi('RegisterForegroundObserver', 'callback', null, function (res) {
    if (res && res.data && res.data.msg === 'resume') {
      fetch();
    }
  });
}

function event() {
  // 最后一栏点击直接跳 settings
  _dom2['default'].all('.row', node).slice(0, -1).forEach(function (d) {
    d.addEventListener('click', function () {
      if (user.userId) {
        _miui2['default'].mi('HandleUri', 'sync', 'miui-music://settings?anim=slide', null);
      } else {
        _miui2['default'].mi('LoginAccount', 'callback', null, fetch);
      }
    }, false);
  });
}

function render() {
  node.classList.add('box', 'user_info');
  node.innerHTML = '<div class="row"><img class="cover avatar" src="' + _config.default_cover.avatar + '" ' + bind('userAvatarUrl') + ' /></div>\n    <div class="row">\n      <div class="title" ' + bind('userName') + '>' + (0, _util._)('not_login') + '<span class="hq" ' + bind('level') + ' hide></span></div>\n      <div class="desc" ' + bind('title') + '></div>\n    </div>\n    <div class="row"><a href="settings">' + (0, _util._)('page_local_setting') + '</a></div>';

  register();
  event();
  return node;
}

exports['default'] = render;
module.exports = exports['default'];

},{"../config":186,"../dom":187,"../miui":190,"../util":192}]},{},[189]);
